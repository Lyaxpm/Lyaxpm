const { parseCommand, isAdmin } = require('../utils/helper');
const db = require('../models/db');
const userCmds  = require('../commands/userCommands');
const adminCmds = require('../commands/adminCommands');

const PREFIXES = ['!', '.', '#'];

async function handleMessage(sock, msg) {
  try {
    const jid = msg.key.remoteJid;
    if (!jid || msg.key.fromMe) return;

    const buyerJid = msg.key.participant || jid;

    const msgText =
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption || '';
    if (!msgText?.trim()) return;

    // Maintenance mode
    const settings = db.getSettings();
    if (settings.maintenanceMode && !isAdmin(buyerJid)) {
      if (PREFIXES.some(p => msgText.startsWith(p))) {
        await sock.sendMessage(jid, { text: '🔧 Bot sedang maintenance. Coba lagi nanti.' }, { quoted: msg });
      }
      return;
    }

    // Banned
    if (db.isBanned(buyerJid)) {
      await sock.sendMessage(jid, { text: '🚫 Akunmu dibanned. Hubungi admin.' }, { quoted: msg });
      return;
    }

    // Daftarkan user
    db.getUser(buyerJid);

    // Cek state pembelian multi-step
    const handled = await userCmds.handleBuyState(sock, msg, msgText);
    if (handled) return;

    // Parse command
    const parsed = parseCommand(msgText, PREFIXES);
    if (!parsed) return;

    const { cmd, args } = parsed;

    // ── User commands ─────────────────────────────────────────────────────
    switch (cmd) {
      case 'menu': case 'start': case 'help':
        return await userCmds.handleMenu(sock, msg, args);

      case 'pricelist': case 'harga': case 'produk': case 'daftar':
        return await userCmds.handlePricelist(sock, msg, args);

      case 'cari': case 'search':
        return await userCmds.handleSearch(sock, msg, args);

      case 'beli': case 'buy': case 'order':
        return await userCmds.handleBuy(sock, msg, args);

      // Tetap support !belimanual sebagai alias, arahkan ke handleBuy
      case 'belimanual': case 'buymanual':
        return await userCmds.handleBuy(sock, msg, args);

      case 'pesanan': case 'riwayat': case 'myorder':
        return await userCmds.handleOrderHistory(sock, msg, args);

      case 'cekpesanan': case 'cekorder': case 'status':
        return await userCmds.handleCheckOrder(sock, msg, args);

      case 'komplain': case 'complaint':
        return await userCmds.handleKomplain(sock, msg, args);

      case 'bantuan':
        return await sock.sendMessage(jid, {
          text: `📞 *BANTUAN*\n\nHubungi admin:\nwa.me/${process.env.OWNER_NUMBER || 'admin'}\n\nAtau: *#komplain <id_order> <pesan>*`
        }, { quoted: msg });
    }

    // ── Admin only ────────────────────────────────────────────────────────
    if (!isAdmin(buyerJid)) {
      // Diam saja kalau bukan command yang dikenal, agar tidak spam
      return;
    }

    switch (cmd) {
      case 'admin': case 'adminmenu':
        return await adminCmds.handleAdminMenu(sock, msg, args);

      case 'addproduk': case 'tambahproduk':
        return await adminCmds.handleAddProduct(sock, msg, args);

      case 'editproduk':
        return await adminCmds.handleEditProduct(sock, msg, args);

      case 'hapusproduk': case 'deleteproduk':
        return await adminCmds.handleDeleteProduct(sock, msg, args);

      case 'listproduk': case 'daftarproduk':
        return await adminCmds.handleListProducts(sock, msg, args);

      case 'pesananadmin': case 'allorder':
        return await adminCmds.handleAdminOrders(sock, msg, args);

      case 'selesai': case 'sukses':
        return await adminCmds.handleConfirmOrder(sock, msg, args);

      case 'gagal': case 'tolak':
        return await adminCmds.handleFailOrder(sock, msg, args);

      case 'ban':
        return await adminCmds.handleBanUser(sock, msg, args);

      case 'unban':
        return await adminCmds.handleUnbanUser(sock, msg, args);

      case 'listuser': case 'daftaruser':
        return await adminCmds.handleListUsers(sock, msg, args);

      case 'setting': case 'settings':
        return await adminCmds.handleSettings(sock, msg, args);

      case 'refreshpricelist': case 'updateharga':
        return await adminCmds.handleRefreshPricelist(sock, msg, args);

      case 'saldo': case 'balance':
        return await adminCmds.handleBalance(sock, msg, args);

      case 'broadcast':
        return await adminCmds.handleBroadcast(sock, msg, args);

      case 'getservice':
        return await adminCmds.handleGetService(sock, msg, args);

      case 'editdigi':
        return await adminCmds.handleEditDigiProduct(sock, msg, args);

      default:
        await sock.sendMessage(jid, {
          text: `❌ Perintah tidak dikenal: *${cmd}*\nKetik *!adminmenu* untuk daftar perintah admin.`
        }, { quoted: msg });
    }

  } catch (e) {
    console.error('handleMessage error:', e);
  }
}

module.exports = { handleMessage };
