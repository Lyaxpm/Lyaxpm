const { parseCommand, isAdmin } = require('../utils/helper');
const db = require('../models/db');
const userCmds = require('../commands/userCommands');
const adminCmds = require('../commands/adminCommands');

const PREFIXES = ['!', '.', '#'];

async function handleMessage(sock, msg) {
  try {
    const jid = msg.key.remoteJid;
    if (!jid || msg.key.fromMe) return;

    const buyerJid = msg.key.participant || jid;

    // Get message text
    const msgText = msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption ||
      '';
    if (!msgText?.trim()) return;

    // Check maintenance mode
    const settings = db.getSettings();
    if (settings.maintenanceMode && !isAdmin(buyerJid)) {
      if (msgText.startsWith('!') || msgText.startsWith('.') || msgText.startsWith('#')) {
        await sock.sendMessage(jid, { text: '🔧 Bot sedang dalam mode maintenance. Mohon coba lagi nanti.' }, { quoted: msg });
      }
      return;
    }

    // Check if user is banned
    if (db.isBanned(buyerJid)) {
      await sock.sendMessage(jid, { text: '🚫 Akun kamu telah dibanned. Hubungi admin untuk informasi lebih lanjut.' }, { quoted: msg });
      return;
    }

    // Register user
    db.getUser(buyerJid);

    // Check buy state (multi-step flow)
    const handled = await userCmds.handleBuyState(sock, msg, msgText);
    if (handled) return;

    // Parse command
    const parsed = parseCommand(msgText, PREFIXES);
    if (!parsed) return;

    const { cmd, args } = parsed;

    // User commands (all users)
    switch (cmd) {
      case 'menu':
      case 'start':
      case 'help':
        return await userCmds.handleMenu(sock, msg, args);
      
      case 'pricelist':
      case 'harga':
      case 'produk':
        return await userCmds.handlePricelist(sock, msg, args);
      
      case 'cari':
      case 'search':
        return await userCmds.handleSearch(sock, msg, args);
      
      case 'beli':
      case 'buy':
      case 'order':
        return await userCmds.handleBuy(sock, msg, args, false);
      
      case 'belimanual':
      case 'buymanual':
        return await userCmds.handleBuy(sock, msg, args, true);
      
      case 'pesanan':
      case 'riwayat':
      case 'myorder':
        return await userCmds.handleOrderHistory(sock, msg, args);
      
      case 'cekpesanan':
      case 'cekorder':
      case 'status':
        return await userCmds.handleCheckOrder(sock, msg, args);
      
      case 'komplain':
      case 'complaint':
        return await userCmds.handleKomplain(sock, msg, args);
      
      case 'bantuan':
        await sock.sendMessage(jid, {
          text: `📞 *BANTUAN*\n\nHubungi admin kami:\n${process.env.OWNER_NUMBER || 'Admin'}\n\nAtau gunakan !komplain <id_order> <pesan> untuk komplain pesanan`
        }, { quoted: msg });
        return;
    }

    // Admin only commands
    if (!isAdmin(buyerJid)) {
      await sock.sendMessage(jid, { text: '❌ Perintah tidak dikenal. Ketik !menu untuk melihat daftar perintah.' }, { quoted: msg });
      return;
    }

    switch (cmd) {
      case 'admin':
      case 'adminmenu':
        return await adminCmds.handleAdminMenu(sock, msg, args);
      
      case 'addproduk':
      case 'tambahproduk':
        return await adminCmds.handleAddProduct(sock, msg, args);
      
      case 'editproduk':
        return await adminCmds.handleEditProduct(sock, msg, args);
      
      case 'hapusproduk':
      case 'deleteproduk':
        return await adminCmds.handleDeleteProduct(sock, msg, args);
      
      case 'listproduk':
      case 'daftarproduk':
        return await adminCmds.handleListProducts(sock, msg, args);
      
      case 'pesananadmin':
      case 'allorder':
        return await adminCmds.handleAdminOrders(sock, msg, args);
      
      case 'selesai':
      case 'sukses':
        return await adminCmds.handleConfirmOrder(sock, msg, args);
      
      case 'gagal':
      case 'tolak':
        return await adminCmds.handleFailOrder(sock, msg, args);
      
      case 'ban':
        return await adminCmds.handleBanUser(sock, msg, args);
      
      case 'unban':
        return await adminCmds.handleUnbanUser(sock, msg, args);
      
      case 'listuser':
      case 'daftaruser':
        return await adminCmds.handleListUsers(sock, msg, args);
      
      case 'setting':
      case 'settings':
        return await adminCmds.handleSettings(sock, msg, args);
      
      case 'refreshpricelist':
      case 'updateharga':
        return await adminCmds.handleRefreshPricelist(sock, msg, args);
      
      case 'saldo':
      case 'balance':
        return await adminCmds.handleBalance(sock, msg, args);
      
      case 'broadcast':
        return await adminCmds.handleBroadcast(sock, msg, args);
      
      case 'getservice':
        return await adminCmds.handleGetService(sock, msg, args);
      
      case 'editdigi':
        return await adminCmds.handleEditDigiProduct(sock, msg, args);

      default:
        await sock.sendMessage(jid, { text: `❌ Perintah tidak dikenal: !${cmd}\nKetik !adminmenu untuk daftar perintah admin` }, { quoted: msg });
    }
  } catch (e) {
    console.error('handleMessage error:', e);
  }
}

module.exports = { handleMessage };
