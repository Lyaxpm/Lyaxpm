const express = require('express');
const crypto = require('crypto');
const orderService = require('../services/orderService');
const tripay = require('../services/tripay');
const db = require('../models/db');
const { formatRupiah } = require('../utils/helper');


const app = express();
app.use(express.json({ verify: (req, res, buf) => { req.rawBody = buf; } }));
app.use(express.urlencoded({ extended: true }));

// =====================
// TRIPAY CALLBACK
// =====================
app.post('/webhook/tripay', async (req, res) => {
  try {
    const signature = req.headers['x-callback-signature'];
    const body = req.body;

    console.log('Tripay callback received:', JSON.stringify(body));

    // Verify signature
    if (!tripay.verifyCallback(body, signature)) {
      console.error('Invalid Tripay signature');
      return res.status(400).json({ success: false, message: 'Invalid signature' });
    }

    const { merchant_ref, status, reference } = body;

    if (status === 'PAID') {
      console.log(`Payment confirmed: ${merchant_ref} (${reference})`);
      await orderService.onPaymentSuccess(reference);
    } else if (status === 'FAILED' || status === 'EXPIRED') {
      // Find order and mark as cancelled
      const orders = db.getOrders();
      const order = Object.values(orders).find(o => o.tripayReference === reference);
      if (order && order.status === 'pending_payment') {
        db.updateOrder(order.id, { status: 'cancelled', cancelReason: `Pembayaran ${status.toLowerCase()}` });
        console.log(`Order ${order.id} cancelled: ${status}`);
      }
    }

    res.json({ success: true });
  } catch (e) {
    console.error('Tripay webhook error:', e);
    res.status(500).json({ success: false, message: e.message });
  }
});

// =====================
// DIGIFLAZZ CALLBACK
// =====================
app.post('/webhook/digiflazz', async (req, res) => {
  try {
    const body = req.body;
    const signature = req.headers['x-hub-signature'];
    console.log('Digiflazz callback received:', JSON.stringify(body));

    const data = body.data;
    if (!data) return res.json({ success: true });

    const order = db.getOrder(data.ref_id);
    if (!order) {
      console.log('Order not found for ref_id:', data.ref_id);
      return res.json({ success: true });
    }

    if (data.status === 'Sukses') {
      db.updateOrder(order.id, {
        status: 'success',
        digiflazzSn: data.sn,
        digiflazzMessage: data.message,
        processedAt: Date.now()
      });
      
      const updatedOrder = db.getOrder(order.id);
      await sendText(order.buyerJid,
        `✅ *PESANAN BERHASIL*\n\n` +
        `📦 Order ID: ${order.id}\n` +
        `🛒 Produk: ${order.productName}\n` +
        `📱 No Tujuan: ${order.customerNo}\n` +
        `🔑 SN/Token: ${data.sn || '-'}\n` +
        `💰 Total: ${formatRupiah(order.amount)}\n\n` +
        `Terima kasih telah berbelanja! 🙏`
      );
    } else if (data.status === 'Gagal') {
      db.updateOrder(order.id, { status: 'failed', digiflazzMessage: data.message });
      
      await sendText(order.buyerJid,
        `❌ *PESANAN GAGAL*\n\n` +
        `📦 Order ID: ${order.id}\n` +
        `🛒 Produk: ${order.productName}\n` +
        `📝 Alasan: ${data.message}\n\n` +
        `Ketik *#komplain ${order.id}* untuk komplain`
      );
    }

    res.json({ success: true });
  } catch (e) {
    console.error('Digiflazz webhook error:', e);
    res.status(500).json({ success: false });
  }
});

// Status check endpoint
app.get('/order/:orderId', (req, res) => {
  const order = db.getOrder(req.params.orderId.toUpperCase());
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json({ orderId: order.id, status: order.status, productName: order.productName, amount: order.amount });
});

app.get('/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime() }));

function startWebhookServer() {
  const PORT = process.env.WEBHOOK_PORT || 3000;
  app.listen(PORT, () => {
    console.log(`✅ Webhook server running on port ${PORT}`);
  });
}

module.exports = { startWebhookServer, app };
