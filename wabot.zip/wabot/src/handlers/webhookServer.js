require('dotenv').config();
const express      = require('express');
const crypto       = require('crypto');
const orderService = require('../services/orderService');
const db           = require('../models/db');
const { formatRupiah } = require('../utils/helper');

const app = express();

// Raw body parser — dibutuhkan untuk verifikasi signature
app.use(express.json({
  verify: (req, res, buf) => { req.rawBody = buf.toString(); }
}));
app.use(express.urlencoded({ extended: true }));

// ═══════════════════════════════════════════════════════════════════════════
// TRIPAY CALLBACK
// ═══════════════════════════════════════════════════════════════════════════
app.post('/webhook/tripay', async (req, res) => {
  try {
    const signature = req.headers['x-callback-signature'] || '';
    const body      = req.body;

    console.log('[Webhook/Tripay] Received:', body?.merchant_ref, body?.status);

    // Verifikasi signature
    const PRIVATE_KEY = process.env.TRIPAY_PRIVATE_KEY || '';
    const hash = crypto.createHmac('sha256', PRIVATE_KEY)
      .update(req.rawBody)
      .digest('hex');

    if (signature && hash !== signature) {
      console.warn('[Webhook/Tripay] ⚠️  Signature tidak cocok — request diabaikan');
      return res.status(400).json({ success: false, message: 'Invalid signature' });
    }

    const { merchant_ref, status, reference } = body;

    if (status === 'PAID') {
      console.log('[Webhook/Tripay] ✅ PAID:', merchant_ref);
      await orderService.onPaymentSuccess(reference);
    } else if (status === 'FAILED' || status === 'EXPIRED') {
      const orders = db.getOrders();
      const order  = Object.values(orders).find(o => o.tripayReference === reference);
      if (order && order.status === 'pending_payment') {
        db.updateOrder(order.id, {
          status:       'cancelled',
          cancelReason: `Pembayaran ${status.toLowerCase()}`
        });
        console.log('[Webhook/Tripay] ❌ Cancelled:', order.id, status);
      }
    }

    return res.json({ success: true });
  } catch (e) {
    console.error('[Webhook/Tripay] Error:', e.message);
    return res.status(500).json({ success: false, message: e.message });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// DIGIFLAZZ CALLBACK
// URL: http://IP:PORT/webhook/digiflazz
// Isi di dashboard Digiflazz → Pengaturan → Callback URL
// ═══════════════════════════════════════════════════════════════════════════
app.post('/webhook/digiflazz', async (req, res) => {
  try {
    const body = req.body;
    console.log('[Webhook/Digiflazz] Received:', JSON.stringify(body));

    // Verifikasi signature Digiflazz (X-Hub-Signature: sha1=<hash>)
    const sigHeader = req.headers['x-hub-signature'] || '';
    const secret    = process.env.DIGIFLAZZ_WEBHOOK_SECRET || process.env.DIGIFLAZZ_API_KEY || '';
    if (sigHeader && secret) {
      const expected = 'sha1=' + crypto.createHmac('sha1', secret)
        .update(req.rawBody)
        .digest('hex');
      if (sigHeader !== expected) {
        console.warn('[Webhook/Digiflazz] ⚠️  Signature tidak cocok');
        // Digiflazz kadang tidak kirim signature di dev — jangan hard-reject
      }
    }

    const data = body.data;
    if (!data) {
      console.log('[Webhook/Digiflazz] Payload kosong, skip');
      return res.json({ success: true });
    }

    const order = db.getOrder(data.ref_id);
    if (!order) {
      console.log('[Webhook/Digiflazz] Order tidak ditemukan:', data.ref_id);
      return res.json({ success: true });
    }

    const { sendText } = require('../utils/sender');

    if (data.status === 'Sukses') {
      db.updateOrder(order.id, {
        status:           'success',
        digiflazzSn:      data.sn      || '',
        digiflazzMessage: data.message || '',
        processedAt:      Date.now()
      });

      // Update statistik user
      const user = db.getUser(order.buyerJid);
      db.updateUser(order.buyerJid, {
        totalOrders: (user.totalOrders || 0) + 1,
        totalSpent:  (user.totalSpent  || 0) + order.amount
      });

      console.log('[Webhook/Digiflazz] ✅ Sukses:', order.id, 'SN:', data.sn);

      await sendText(order.buyerJid,
        `✅ *PESANAN BERHASIL*\n\n` +
        `📦 Order  : ${order.id}\n` +
        `🩰 Produk : ${order.productName}\n` +
        (order.customerNo ? `📱 No/ID  : ${order.customerNo}\n` : '') +
        (data.sn ? `🔑 SN/Token: *${data.sn}*\n` : '') +
        `💰 Total  : ${formatRupiah(order.amount)}\n\n` +
        `Terima kasih sudah belanja! 🩰`
      );

    } else if (data.status === 'Gagal') {
      db.updateOrder(order.id, {
        status:           'failed',
        digiflazzMessage: data.message || 'Transaksi gagal',
        failedAt:         Date.now()
      });

      console.log('[Webhook/Digiflazz] ❌ Gagal:', order.id, data.message);

      await sendText(order.buyerJid,
        `❌ *PESANAN GAGAL*\n\n` +
        `📦 Order  : ${order.id}\n` +
        `🩰 Produk : ${order.productName}\n` +
        `📝 Alasan : ${data.message || 'Transaksi gagal'}\n\n` +
        `Ketik *#komplain ${order.id}* untuk bantuan`
      );

    } else {
      // Pending — update pesan saja
      db.updateOrder(order.id, { digiflazzMessage: data.message || '' });
      console.log('[Webhook/Digiflazz] ⏳ Pending:', order.id, data.message);
    }

    return res.json({ success: true });
  } catch (e) {
    console.error('[Webhook/Digiflazz] Error:', e.message);
    return res.status(500).json({ success: false, message: e.message });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// ENDPOINT CEK STATUS ORDER (opsional, untuk return_url Tripay)
// ═══════════════════════════════════════════════════════════════════════════
app.get('/order/:orderId', (req, res) => {
  const order = db.getOrder(req.params.orderId.toUpperCase());
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json({
    orderId:     order.id,
    status:      order.status,
    productName: order.productName,
    amount:      order.amount
  });
});

// Health check
app.get('/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime() }));

// ── Test endpoint (hapus di production) ───────────────────────────────────
app.get('/webhook/test', (req, res) => {
  res.json({
    status:      'Webhook server berjalan ✅',
    tripay_url:  `${process.env.WEBHOOK_BASE_URL}/webhook/tripay`,
    digiflazz_url: `${process.env.WEBHOOK_BASE_URL}/webhook/digiflazz`,
    port:        process.env.WEBHOOK_PORT || 3000
  });
});

function startWebhookServer() {
  const PORT = parseInt(process.env.WEBHOOK_PORT) || 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`✅ Webhook server running on port ${PORT}`);
    console.log(`   Tripay    → ${process.env.WEBHOOK_BASE_URL || 'http://IP:PORT'}/webhook/tripay`);
    console.log(`   Digiflazz → ${process.env.WEBHOOK_BASE_URL || 'http://IP:PORT'}/webhook/digiflazz`);
  });
}

module.exports = { startWebhookServer, app };
