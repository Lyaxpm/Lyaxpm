require('dotenv').config();
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require('readline');
const path = require('path');
const fs = require('fs');

const { handleMessage } = require('./handlers/messageHandler');
const { startWebhookServer } = require('./handlers/webhookServer');
const { setSock } = require('./utils/sender');
const { refreshPricelist } = require('./services/digiflazz');

const SESSION_DIR = process.env.SESSION_DIR || './session';

// Auto-refresh pricelist setiap 6 jam
async function schedulePricelistRefresh() {
  try {
    console.log('🔄 Auto-refresh pricelist Digiflazz...');
    await refreshPricelist();
    console.log('✅ Pricelist berhasil diupdate');
  } catch (e) {
    console.error('❌ Auto-refresh pricelist gagal:', e.message);
  }
  setInterval(async () => {
    try {
      await refreshPricelist();
      console.log('✅ Pricelist auto-refreshed');
    } catch (e) {
      console.error('❌ Auto-refresh error:', e.message);
    }
  }, 6 * 60 * 60 * 1000);
}

async function askPhoneNumber() {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question('📱 Masukkan nomor WhatsApp (contoh: 6281234567890): ', answer => {
      rl.close();
      resolve(answer.trim().replace(/\D/g, ''));
    });
  });
}

async function connectBot() {
  if (!fs.existsSync(SESSION_DIR)) {
    fs.mkdirSync(SESSION_DIR, { recursive: true });
  }

  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  console.log(`🤖 Starting WhatsApp Bot v1.0 | Baileys v${version.join('.')}`);

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false, // DISABLE QR - use pairing code instead
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
    },
    browser: ['Toko Digital Bot', 'Chrome', '1.0.0'],
    syncFullHistory: false
  });

  // Use pairing code if not registered
  if (!sock.authState.creds.registered) {
    let phoneNumber = process.env.BOT_PHONE_NUMBER;
    if (!phoneNumber) {
      phoneNumber = await askPhoneNumber();
    }
    if (!phoneNumber) {
      console.error('❌ Nomor telepon tidak dimasukkan!');
      process.exit(1);
    }
    console.log(`\n🔐 Meminta pairing code untuk: ${phoneNumber}`);
    await new Promise(r => setTimeout(r, 3000));
    try {
      const code = await sock.requestPairingCode(phoneNumber);
      console.log(`\n╔══════════════════════════════╗`);
      console.log(`║   PAIRING CODE: ${code.match(/.{1,4}/g).join('-')}   ║`);
      console.log(`╚══════════════════════════════╝`);
      console.log(`\n📱 Buka WhatsApp > Settings > Linked Devices > Link a Device`);
      console.log(`   Pilih "Link with phone number instead" lalu masukkan kode di atas\n`);
    } catch (e) {
      console.error('❌ Gagal mendapatkan pairing code:', e.message);
    }
  }

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (connection === 'close') {
      const reason = lastDisconnect?.error?.output?.statusCode;
      console.log(`❌ Koneksi terputus. Alasan: ${reason}`);
      
      if (reason === DisconnectReason.loggedOut) {
        console.log('🚪 Bot logout! Hapus folder session dan restart.');
        fs.rmSync(SESSION_DIR, { recursive: true, force: true });
        process.exit(1);
      } else if (reason !== DisconnectReason.loggedOut) {
        console.log('🔄 Mencoba reconnect dalam 5 detik...');
        setTimeout(connectBot, 5000);
      }
    }
    
    if (connection === 'open') {
      console.log('\n✅ WhatsApp Bot CONNECTED!');
      console.log(`📱 Nomor: ${sock.user?.id?.split(':')[0]}`);
      setSock(sock);
      await schedulePricelistRefresh();
      console.log('\n🚀 Bot siap menerima pesan!\n');
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      await handleMessage(sock, msg);
    }
  });

  return sock;
}

async function main() {
  console.log('\n========================================');
  console.log('  🛒 TOKO DIGITAL BOT - WhatsApp');
  console.log('  Powered by Baileys + Digiflazz + Tripay');
  console.log('========================================\n');

  // Start webhook server
  startWebhookServer();

  // Start bot
  await connectBot();
}

main().catch(e => {
  console.error('Fatal error:', e);
  process.exit(1);
});
