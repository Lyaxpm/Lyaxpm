require('dotenv').config();
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  isJidBroadcast
} = require('@fadzzzslebew/baileys');
const pino        = require('pino');
const readline    = require('readline');
const fs          = require('fs');

const { handleMessage }      = require('./handlers/messageHandler');
const { startWebhookServer } = require('./handlers/webhookServer');
const { setSock }            = require('./utils/sender');
const { refreshPricelist }   = require('./services/digiflazz');

const SESSION_DIR      = process.env.SESSION_DIR || './session';
let pricelistScheduled = false;

// ── Tanya nomor lewat terminal ─────────────────────────────────────────────
function askPhoneNumber() {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question('\n📱 Nomor WA bot tanpa + (cth: 6281234567890): ', ans => {
      rl.close();
      resolve(ans.trim().replace(/\D/g, ''));
    });
  });
}

// ── Auto-refresh pricelist setiap 6 jam ───────────────────────────────────
async function schedulePricelistRefresh() {
  if (pricelistScheduled) return;
  pricelistScheduled = true;
  const run = async () => {
    try {
      await refreshPricelist();
      console.log('✅ Pricelist Digiflazz diupdate');
    } catch (e) {
      console.error('⚠️  Pricelist refresh gagal:', e.message);
    }
  };
  await run();
  setInterval(run, 6 * 60 * 60 * 1000);
}

// ── Koneksi utama ──────────────────────────────────────────────────────────
async function connectBot() {
  if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version }          = await fetchLatestBaileysVersion();
  console.log(`🤖 @fadzzzslebew/baileys v${version.join('.')}`);

  const logger = pino({ level: 'silent' });

  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys:  makeCacheableSignalKeyStore(state.keys, logger)
    },
    browser:             ['Ubuntu', 'Chrome', '20.0.04'],
    syncFullHistory:     false,
    markOnlineOnConnect: false
  });

  sock.ev.on('creds.update', saveCreds);

  // ── Pairing Code ───────────────────────────────────────────────────────
  // Pada @fadzzzslebew/baileys: requestPairingCode dipanggil LANGSUNG
  // setelah makeWASocket, SEBELUM connection.update. Ini sesuai docs resminya.
  if (!sock.authState.creds.registered) {
    let phone = process.env.BOT_PHONE_NUMBER;
    if (!phone) phone = await askPhoneNumber();
    if (!phone) { console.error('❌ Nomor kosong.'); process.exit(1); }

    try {
      // Pada fork ini tidak perlu tunggu WS open — langsung request
      const code = await sock.requestPairingCode(phone);
      const fmt  = code.match(/.{1,4}/g).join('-');
      console.log('\n╔═══════════════════════════════════╗');
      console.log(`║   PAIRING CODE :  ${fmt}   ║`);
      console.log('╚═══════════════════════════════════╝');
      console.log('📱 WhatsApp > Settings > Linked Devices');
      console.log('   > Link a Device > Link with phone number');
      console.log('   Masukkan kode di atas (berlaku ±60 detik)\n');
    } catch (e) {
      console.error('❌ Gagal dapat pairing code:', e.message);
      console.error('   Hapus folder session/ lalu coba lagi\n');
      process.exit(1);
    }
  }

  // ── Connection events ──────────────────────────────────────────────────
  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      const num = sock.user?.id?.split(':')[0] || '';
      console.log(`\n✅ Bot CONNECTED (${num})`);
      setSock(sock);
      console.log('🚀 Bot siap menerima pesan!\n');
      await schedulePricelistRefresh();
    }

    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code === DisconnectReason.loggedOut) {
        console.log('🗑️  Logout — hapus session/ dan restart');
        fs.rmSync(SESSION_DIR, { recursive: true, force: true });
        process.exit(0);
      } else if (code === DisconnectReason.connectionReplaced) {
        console.log('⚠️  Sesi digantikan perangkat lain');
        process.exit(0);
      } else {
        console.log(`🔄 Reconnect 5 detik... (kode: ${code})`);
        setTimeout(connectBot, 5000);
      }
    }
  });

  // ── Terima pesan ───────────────────────────────────────────────────────
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      if (!msg.key?.remoteJid) continue;
      if (isJidBroadcast(msg.key.remoteJid)) continue;
      await handleMessage(sock, msg);
    }
  });

  return sock;
}

// ── Entry ──────────────────────────────────────────────────────────────────
async function main() {
  console.log('==========================================');
  console.log('  🛒  TOKO DIGITAL BOT  |  WhatsApp');
  console.log('  @fadzzzslebew/baileys + Digiflazz + Tripay');
  console.log('==========================================');
  startWebhookServer();
  await connectBot();
}

main().catch(e => { console.error('Fatal:', e); process.exit(1); });
