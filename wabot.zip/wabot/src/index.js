require('dotenv').config();
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  isJidBroadcast
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require('readline');
const fs = require('fs');

const { handleMessage } = require('./handlers/messageHandler');
const { startWebhookServer } = require('./handlers/webhookServer');
const { setSock } = require('./utils/sender');
const { refreshPricelist } = require('./services/digiflazz');

const SESSION_DIR = process.env.SESSION_DIR || './session';

// Simpan nomor di memori supaya tidak tanya ulang saat reconnect
let savedPhoneNumber = process.env.BOT_PHONE_NUMBER || '';
let pricelistScheduled = false;

// ── Tanya nomor sekali saja ────────────────────────────────────────────────
async function askPhoneNumber() {
  if (savedPhoneNumber) return savedPhoneNumber;
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question('\n📱 Masukkan nomor WhatsApp bot (cth: 6285155224381): ', answer => {
      rl.close();
      savedPhoneNumber = answer.trim().replace(/\D/g, '');
      resolve(savedPhoneNumber);
    });
  });
}

// ── Auto-refresh pricelist setiap 6 jam ───────────────────────────────────
function schedulePricelistRefresh() {
  if (pricelistScheduled) return;
  pricelistScheduled = true;
  const run = async () => {
    try {
      const result = await refreshPricelist();
      const count = Object.keys(result || {}).length;
      if (count > 0) console.log(`✅ Pricelist diupdate: ${count} produk`);
    } catch (e) {
      console.error('❌ Auto-refresh pricelist gagal:', e.message);
    }
  };
  run();
  setInterval(run, 6 * 60 * 60 * 1000);
}

// ── Minta pairing code dengan retry ──────────────────────────────────────
async function requestPairingCode(sock, phoneNumber) {
  const MAX_RETRIES = 3;
  for (let i = 1; i <= MAX_RETRIES; i++) {
    try {
      console.log(`🔐 Meminta pairing code untuk: ${phoneNumber} (percobaan ${i}/${MAX_RETRIES})`);
      const code = await sock.requestPairingCode(phoneNumber);
      const formatted = code.match(/.{1,4}/g)?.join('-') || code;
      console.log(`\n╔══════════════════════════════════╗`);
      console.log(`║   PAIRING CODE:  ${formatted.padEnd(13)}  ║`);
      console.log(`╚══════════════════════════════════╝`);
      console.log(`\n📱 Cara memasukkan kode di HP:`);
      console.log(`   WA > Settings > Linked Devices > Link a Device`);
      console.log(`   > Link with phone number instead`);
      console.log(`   Masukkan kode: ${formatted}`);
      console.log(`\n⏳ Menunggu kamu memasukkan kode...\n`);
      return true;
    } catch (e) {
      const errMsg = e.message || '';
      console.error(`❌ Gagal pairing code: ${errMsg}`);
      if (errMsg.includes('rate-limit') || errMsg.includes('429')) {
        console.log('⏳ Rate limited. Tunggu 30 detik...');
        await new Promise(r => setTimeout(r, 30_000));
      } else if (i < MAX_RETRIES) {
        console.log(`⏳ Coba lagi dalam 4 detik...`);
        await new Promise(r => setTimeout(r, 4000));
      } else {
        console.error('\n❌ Tidak bisa mendapat pairing code setelah 3 percobaan.');
        console.error('   → Hapus folder session/ dan coba lagi\n');
        return false;
      }
    }
  }
}

// ── Koneksi utama ──────────────────────────────────────────────────────────
async function connectBot() {
  if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  const isRegistered = !!state.creds.registered;

  // Tanya nomor SEBELUM buat socket (hanya jika belum login)
  if (!isRegistered && !savedPhoneNumber) {
    await askPhoneNumber();
    if (!savedPhoneNumber) {
      console.error('❌ Nomor tidak dimasukkan. Keluar.');
      process.exit(1);
    }
  }

  console.log(`🤖 Memulai bot... (Baileys v${version.join('.')})`);

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
    },
    browser: ['Toko Digital', 'Safari', '3.0'],
    syncFullHistory: false,
    markOnlineOnConnect: false,
    connectTimeoutMs: 60_000,
    defaultQueryTimeoutMs: 60_000,
    keepAliveIntervalMs: 25_000,
    retryRequestDelayMs: 2000,
    getMessage: async () => undefined
  });

  sock.ev.on('creds.update', saveCreds);

  // Pairing code: minta setelah socket terbuat tapi sebelum connected
  if (!isRegistered) {
    await new Promise(r => setTimeout(r, 3000)); // tunggu handshake noise
    await requestPairingCode(sock, savedPhoneNumber);
  }

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'open') {
      const num = sock.user?.id?.split(':')[0] || '';
      console.log(`\n✅ Bot CONNECTED! Nomor: ${num}`);
      setSock(sock);
      schedulePricelistRefresh();
      console.log('🚀 Bot siap menerima pesan!\n');
    }

    if (connection === 'close') {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const reasonKey = Object.keys(DisconnectReason).find(k => DisconnectReason[k] === statusCode);
      console.log(`\n⚠️  Koneksi terputus | Kode: ${statusCode} (${reasonKey || 'unknown'})`);

      // Kode 405 = terlalu banyak linked device ATAU nomor terdaftar di tempat lain
      if (statusCode === 405) {
        console.log('\n📌 Kode 405 — Kemungkinan penyebab:');
        console.log('   • WhatsApp Web / Desktop aktif di perangkat lain');
        console.log('   • Sudah ada 4 linked device (batas maksimum WhatsApp)');
        console.log('   • Pairing code sudah expired sebelum dimasukkan');
        console.log('\n✅ Solusi:');
        console.log('   1. Buka WA di HP → Settings → Linked Devices');
        console.log('   2. Logout semua perangkat yang tidak dipakai');
        console.log('   3. Hapus folder session/ : rm -rf session/');
        console.log('   4. Jalankan ulang: npm start');
        console.log('\n⏳ Mencoba reconnect dalam 20 detik...\n');
        setTimeout(() => connectBot(), 20_000);
        return;
      }

      if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
        console.log('🚪 Session tidak valid / di-logout. Hapus session/ lalu restart.\n');
        try { fs.rmSync(SESSION_DIR, { recursive: true, force: true }); } catch {}
        process.exit(1);
      }

      if (statusCode === DisconnectReason.connectionReplaced) {
        console.log('⚠️  Koneksi digantikan perangkat lain. Keluar.\n');
        process.exit(1);
      }

      // Default: reconnect biasa
      const delay = 5000;
      console.log(`🔄 Reconnect dalam ${delay / 1000} detik...`);
      setTimeout(() => connectBot(), delay);
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      try {
        if (!msg.key?.remoteJid) continue;
        if (isJidBroadcast(msg.key.remoteJid)) continue;
        await handleMessage(sock, msg);
      } catch (e) {
        console.error('❌ Message handler error:', e.message);
      }
    }
  });
}

// ── Entry point ───────────────────────────────────────────────────────────
async function main() {
  console.log('\n==========================================');
  console.log('  🛒  TOKO DIGITAL BOT  |  WhatsApp');
  console.log('  Baileys + Digiflazz + Tripay');
  console.log('==========================================\n');

  startWebhookServer();
  await connectBot();
}

main().catch(e => {
  console.error('Fatal error:', e);
  process.exit(1);
});
