require('dotenv').config();
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  isJidBroadcast
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require('readline');
const fs = require('fs');

const { handleMessage } = require('./handlers/messageHandler');
const { startWebhookServer } = require('./handlers/webhookServer');
const { setSock } = require('./utils/sender');
const { refreshPricelist } = require('./services/digiflazz');

const SESSION_DIR = process.env.SESSION_DIR || './session';
let pairCodeRequested = false;
let pricelistScheduled = false;

// ── Tanya nomor via terminal ───────────────────────────────────────────────
async function askPhoneNumber() {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question('\n📱 Masukkan nomor WhatsApp bot (cth: 6281234567890): ', answer => {
      rl.close();
      resolve(answer.trim().replace(/\D/g, ''));
    });
  });
}

// ── Auto-refresh pricelist setiap 6 jam ───────────────────────────────────
async function schedulePricelistRefresh() {
  if (pricelistScheduled) return;
  pricelistScheduled = true;
  const run = async () => {
    try {
      console.log('🔄 Auto-refresh pricelist Digiflazz...');
      await refreshPricelist();
      console.log('✅ Pricelist berhasil diupdate');
    } catch (e) {
      console.error('❌ Auto-refresh pricelist gagal:', e.message);
    }
  };
  await run();
  setInterval(run, 6 * 60 * 60 * 1000);
}

// ── Koneksi utama ──────────────────────────────────────────────────────────
async function connectBot() {
  if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();
  console.log(`🤖 Starting WhatsApp Bot v1.0 | Baileys v${version.join('.')}`);

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,       // ← nonaktifkan QR, pakai pairing code
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
    },
    browser: ['Ubuntu', 'Chrome', '20.0.04'],
    syncFullHistory: false,
    markOnlineOnConnect: false
  });

  sock.ev.on('creds.update', saveCreds);

  // ── Pairing code: minta SETELAH socket connecting (bukan open) ───────────
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, isNewLogin } = update;

    // Saat pertama kali "connecting" dan belum terdaftar → minta pairing code
    if (
      connection === 'connecting' &&
      !pairCodeRequested &&
      !sock.authState.creds.registered
    ) {
      pairCodeRequested = true;

      let phoneNumber = process.env.BOT_PHONE_NUMBER;
      if (!phoneNumber) phoneNumber = await askPhoneNumber();
      if (!phoneNumber) { console.error('❌ Nomor tidak dimasukkan, keluar.'); process.exit(1); }

      // Tunggu sebentar agar socket handshake selesai
      await new Promise(r => setTimeout(r, 2000));

      let retries = 3;
      while (retries > 0) {
        try {
          console.log(`\n🔐 Meminta pairing code untuk: ${phoneNumber} ...`);
          const code = await sock.requestPairingCode(phoneNumber);
          const formatted = code.match(/.{1,4}/g).join('-');
          console.log(`\n╔══════════════════════════════════╗`);
          console.log(`║  PAIRING CODE:  ${formatted.padEnd(14)}  ║`);
          console.log(`╚══════════════════════════════════╝`);
          console.log(`\n📱 WhatsApp > Settings > Linked Devices`);
          console.log(`   > Link a Device > Link with phone number`);
          console.log(`   Masukkan kode di atas\n`);
          break;
        } catch (e) {
          retries--;
          console.error(`❌ Gagal pairing code (sisa ${retries} percobaan): ${e.message}`);
          if (retries > 0) {
            console.log('⏳ Coba lagi dalam 3 detik...');
            await new Promise(r => setTimeout(r, 3000));
          } else {
            console.error('❌ Tidak bisa mendapat pairing code.');
            console.error('   → Pastikan nomor BENAR dan belum terhubung di perangkat lain');
            console.error('   → Hapus folder session/ lalu jalankan ulang\n');
          }
        }
      }
    }

    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      const reason = DisconnectReason[code] || code;
      console.log(`❌ Koneksi terputus | Kode: ${reason}`);

      if (code === DisconnectReason.loggedOut) {
        console.log('🚪 Session logout! Menghapus session dan keluar...');
        fs.rmSync(SESSION_DIR, { recursive: true, force: true });
        process.exit(0);
      } else if (code === DisconnectReason.connectionReplaced) {
        console.log('⚠️  Koneksi digantikan perangkat lain.');
        process.exit(0);
      } else {
        pairCodeRequested = false; // reset supaya bisa request ulang jika perlu
        const delay = 5000;
        console.log(`🔄 Reconnect dalam ${delay / 1000} detik...`);
        setTimeout(() => connectBot(), delay);
      }
    }

    if (connection === 'open') {
      const num = sock.user?.id?.split(':')[0] || '';
      console.log(`\n✅ WhatsApp Bot CONNECTED! (${num})`);
      setSock(sock);
      console.log('🚀 Bot siap menerima pesan!\n');
      await schedulePricelistRefresh();
    }
  });

  // ── Terima pesan masuk ────────────────────────────────────────────────────
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      // Abaikan broadcast & status
      if (isJidBroadcast(msg.key.remoteJid)) continue;
      await handleMessage(sock, msg);
    }
  });

  return sock;
}

// ── Entry point ───────────────────────────────────────────────────────────
async function main() {
  console.log('\n==========================================');
  console.log('  🛒  TOKO DIGITAL BOT  |  WhatsApp');
  console.log('  Baileys + Digiflazz + Tripay');
  console.log('==========================================\n');

  startWebhookServer();
  await connectBot();
}

main().catch(e => {
  console.error('Fatal error:', e);
  process.exit(1);
});
