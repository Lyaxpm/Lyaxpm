const db = require('../models/db');
const { formatRupiah, formatDate, orderStatusEmoji, orderStatusText, chunkArray, isAdmin } = require('../utils/helper');
const orderService = require('../services/orderService');
const digiflazz = require('../services/digiflazz');
const { sendToAdmin } = require('../utils/sender');

// State untuk multi-step pembelian
const buyState = {};

async function handleMenu(sock, msg, args) {
  const text = `🛒 *MENU UTAMA - TOKO DIGITAL*\n\n` +
    `📦 *Produk*\n` +
    `  !pricelist - Lihat semua produk\n` +
    `  !pricelist <kategori> - Filter produk\n` +
    `  !cari <keyword> - Cari produk\n\n` +
    `💳 *Pembelian*\n` +
    `  !beli <kode_produk> - Beli produk Digiflazz\n` +
    `  #buy <kode_produk> - (sama dengan !beli)\n` +
    `  !belimanual <id_produk> - Beli produk manual\n\n` +
    `📋 *Riwayat*\n` +
    `  !pesanan - Lihat riwayat pesanan\n` +
    `  !cekpesanan <id> - Cek status pesanan\n\n` +
    `📞 *Lainnya*\n` +
    `  !komplain <id_order> - Komplain pesanan\n` +
    `  !bantuan - Hubungi admin\n` +
    `  !menu - Menu ini\n\n` +
    `_Prefix yang tersedia: !, ., #_`;
  await sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });
}

async function handlePricelist(sock, msg, args) {
  const category = args.join(' ').trim();
  const settings = db.getSettings();
  
  // Products from Digiflazz
  const digiProducts = db.getDigiProducts();
  // Manual products
  const manualProducts = Object.values(db.getProducts()).filter(p => p.active !== false);

  let text = `📋 *PRICELIST TOKO DIGITAL*\n`;
  text += `_Profit Margin: ${settings.profitMargin}%_\n\n`;

  // Manual Products
  if (manualProducts.length > 0 && (!category || category.toLowerCase() === 'manual')) {
    text += `🏪 *PRODUK MANUAL*\n`;
    text += `━━━━━━━━━━━━━━━━\n`;
    manualProducts.forEach(p => {
      text += `🔹 *${p.name}*\n`;
      text += `   ID: \`${p.id}\`\n`;
      text += `   Harga: ${formatRupiah(p.price)}\n`;
      if (p.description) text += `   ${p.description}\n`;
      if (p.stock !== undefined) text += `   Stok: ${p.stock > 0 ? p.stock : '❌ Habis'}\n`;
      text += '\n';
    });
  }

  // Digiflazz products by category
  const categories = {};
  Object.values(digiProducts).forEach(p => {
    if (p.active === false) return;                                          // admin nonaktifkan
    if (category && !p.category?.toLowerCase().includes(category.toLowerCase()) &&
        !p.brand?.toLowerCase().includes(category.toLowerCase())) return;
    if (p.stock !== 'available') return;
    const cat = p.category || 'Lainnya';
    if (!categories[cat]) categories[cat] = [];
    categories[cat].push(p);
  });

  Object.entries(categories).forEach(([cat, products]) => {
    text += `📁 *${cat.toUpperCase()}*\n`;
    text += `━━━━━━━━━━━━━━━━\n`;
    // Group by brand
    const brands = {};
    products.forEach(p => {
      const brand = p.brand || 'Lainnya';
      if (!brands[brand]) brands[brand] = [];
      brands[brand].push(p);
    });
    Object.entries(brands).forEach(([brand, prods]) => {
      text += `  📱 *${brand}*\n`;
      prods.slice(0, 10).forEach(p => {
        text += `    • ${p.name}: ${formatRupiah(p.sellPrice)}\n`;
        text += `      SKU: \`${p.sku}\`\n`;
      });
    });
    text += '\n';
  });

  if (text.length > 60000) {
    text = text.substring(0, 60000) + '\n...\n_Gunakan !pricelist <kategori> untuk filter lebih spesifik_';
  }

  if (!Object.keys(categories).length && !manualProducts.length) {
    text += '\n❌ Tidak ada produk yang ditemukan.\n';
    if (category) text += `Coba: !pricelist (tanpa kategori)`;
  } else {
    text += `\n💡 *Cara Beli:*\n!beli <SKU> <nomor_tujuan>\nContoh: !beli XL5 08123456789\n`;
    text += `Atau: !belimanual <ID_PRODUK> untuk produk manual`;
  }

  await sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });
}

async function handleSearch(sock, msg, args) {
  if (!args.length) {
    await sock.sendMessage(msg.key.remoteJid, { text: '❌ Masukkan kata kunci pencarian\nContoh: !cari xl 5rb' }, { quoted: msg });
    return;
  }
  const keyword = args.join(' ').toLowerCase();
  const digiProducts = db.getDigiProducts();
  const manualProducts = Object.values(db.getProducts()).filter(p => p.active !== false);

  const results = [];
  // Search manual
  manualProducts.forEach(p => {
    if (p.name.toLowerCase().includes(keyword) || p.id.toLowerCase().includes(keyword)) {
      results.push({ ...p, _type: 'manual' });
    }
  });
  // Search digi
  Object.values(digiProducts).forEach(p => {
    if (p.name.toLowerCase().includes(keyword) || p.sku.toLowerCase().includes(keyword) ||
        p.brand?.toLowerCase().includes(keyword)) {
      results.push({ ...p, _type: 'digi' });
    }
  });

  if (!results.length) {
    await sock.sendMessage(msg.key.remoteJid, { text: `❌ Produk "${keyword}" tidak ditemukan` }, { quoted: msg });
    return;
  }

  let text = `🔍 *HASIL PENCARIAN: "${keyword}"*\n`;
  text += `Ditemukan ${results.length} produk\n\n`;
  results.slice(0, 20).forEach(p => {
    if (p._type === 'manual') {
      text += `🏪 *${p.name}* (Manual)\n`;
      text += `   ID: \`${p.id}\` | Harga: ${formatRupiah(p.price)}\n\n`;
    } else {
      text += `📦 *${p.name}*\n`;
      text += `   SKU: \`${p.sku}\` | Harga: ${formatRupiah(p.sellPrice)}\n\n`;
    }
  });
  await sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });
}

async function handleBuy(sock, msg, args, isManual = false) {
  const jid = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  
  if (!args[0]) {
    const text = isManual
      ? `❌ Format: !belimanual <id_produk>\nLihat !pricelist untuk ID produk manual`
      : `❌ Format: !beli <kode_sku> <nomor_tujuan>\nContoh: !beli XL5 08123456789`;
    await sock.sendMessage(jid, { text }, { quoted: msg });
    return;
  }

  const productId = args[0];
  
  if (isManual) {
    const product = db.getProduct(productId);
    if (!product || product.active === false) {
      await sock.sendMessage(jid, { text: `❌ Produk \`${productId}\` tidak ditemukan` }, { quoted: msg });
      return;
    }
    if (product.stock !== undefined && product.stock <= 0) {
      await sock.sendMessage(jid, { text: `❌ Stok produk *${product.name}* habis` }, { quoted: msg });
      return;
    }
    // Set buy state - pilih payment
    buyState[buyerJid] = { productId, productType: 'manual', productName: product.name, amount: product.price, step: 'select_payment' };
    await askPaymentMethod(sock, jid, msg, product.name, product.price);
  } else {
    if (!args[1]) {
      await sock.sendMessage(jid, { text: `❌ Format: !beli <kode_sku> <nomor_tujuan>\nContoh: !beli XL5 08123456789` }, { quoted: msg });
      return;
    }
    const customerNo = args[1];
    const digiProducts = db.getDigiProducts();
    const product = digiProducts[productId];
    if (!product) {
      await sock.sendMessage(jid, { text: `❌ SKU \`${productId}\` tidak ditemukan\nGunakan !cari untuk mencari produk` }, { quoted: msg });
      return;
    }
    if (product.stock === 'empty') {
      await sock.sendMessage(jid, { text: `❌ Produk *${product.name}* sedang kosong` }, { quoted: msg });
      return;
    }
    buyState[buyerJid] = { productId, productType: 'digiflazz', productName: product.name, amount: product.sellPrice, customerNo, step: 'select_payment' };
    await askPaymentMethod(sock, jid, msg, product.name, product.sellPrice, customerNo);
  }
}

async function askPaymentMethod(sock, jid, msg, productName, amount, customerNo = '') {
  const text = `🛒 *KONFIRMASI PEMBELIAN*\n\n` +
    `📦 Produk: ${productName}\n` +
    (customerNo ? `📱 No Tujuan: ${customerNo}\n` : '') +
    `💰 Total: ${formatRupiah(amount)}\n\n` +
    `*Pilih metode pembayaran:*\n` +
    `1️⃣ QRIS\n` +
    `2️⃣ Transfer Bank BCA\n` +
    `3️⃣ Transfer Bank BRI\n` +
    `4️⃣ Transfer Bank Mandiri\n` +
    `5️⃣ OVO\n` +
    `6️⃣ GoPay\n` +
    `7️⃣ Dana\n\n` +
    `Balas dengan angka pilihan (contoh: *1*)\natau ketik *batal* untuk membatalkan`;
  await sock.sendMessage(jid, { text }, { quoted: msg });
}

const paymentMethodMap = {
  '1': 'QRIS',
  '2': 'BRIVA',
  '3': 'BRIVA',
  '4': 'MANDIRIVA',
  '5': 'OVO',
  '6': 'GOPAY',
  '7': 'DANA',
  'qris': 'QRIS',
  'bca': 'BCAVA',
  'bri': 'BRIVA',
  'mandiri': 'MANDIRIVA',
  'ovo': 'OVO',
  'gopay': 'GOPAY',
  'dana': 'DANA'
};

async function handleBuyState(sock, msg, text) {
  const jid = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  const state = buyState[buyerJid];
  if (!state) return false;

  const input = text.trim().toLowerCase();
  if (input === 'batal') {
    delete buyState[buyerJid];
    await sock.sendMessage(jid, { text: '❌ Pembelian dibatalkan' }, { quoted: msg });
    return true;
  }

  if (state.step === 'select_payment') {
    const paymentMethod = paymentMethodMap[input];
    if (!paymentMethod) {
      await sock.sendMessage(jid, { text: '❌ Pilihan tidak valid. Masukkan angka 1-7 atau ketik *batal*' }, { quoted: msg });
      return true;
    }
    state.paymentMethod = paymentMethod;
    state.step = 'confirm';
    const payNames = { QRIS: 'QRIS', BCAVA: 'BCA Virtual Account', BRIVA: 'BRI Virtual Account', MANDIRIVA: 'Mandiri Virtual Account', OVO: 'OVO', GOPAY: 'GoPay', DANA: 'Dana' };
    const confirmText = `✅ *KONFIRMASI AKHIR*\n\n` +
      `📦 Produk: ${state.productName}\n` +
      (state.customerNo ? `📱 No Tujuan: ${state.customerNo}\n` : '') +
      `💰 Total: ${formatRupiah(state.amount)}\n` +
      `💳 Pembayaran: ${payNames[paymentMethod] || paymentMethod}\n\n` +
      `Ketik *ya* untuk lanjut atau *batal* untuk membatalkan`;
    await sock.sendMessage(jid, { text: confirmText }, { quoted: msg });
    return true;
  }

  if (state.step === 'confirm') {
    if (input !== 'ya' && input !== 'yes') {
      await sock.sendMessage(jid, { text: '❌ Ketik *ya* untuk konfirmasi atau *batal* untuk membatalkan' }, { quoted: msg });
      return true;
    }
    delete buyState[buyerJid];

    await sock.sendMessage(jid, { text: '⏳ Sedang membuat invoice pembayaran...' }, { quoted: msg });

    try {
      const user = db.getUser(buyerJid);
      const order = await orderService.createOrder({
        buyerJid,
        buyerName: user.name || buyerJid.replace('@s.whatsapp.net', ''),
        productId: state.productId,
        productType: state.productType,
        customerNo: state.customerNo,
        paymentMethod: state.paymentMethod
      });

      const expDate = new Date(order.tripayExpiredTime * 1000);
      let payText = `🧾 *INVOICE PEMBAYARAN*\n\n` +
        `📦 Order ID: ${order.id}\n` +
        `🛒 Produk: ${order.productName}\n` +
        `💰 Total: ${formatRupiah(order.amount)}\n` +
        `💳 Metode: ${order.paymentMethod}\n` +
        `⏰ Berlaku hingga: ${formatDate(expDate)}\n\n`;

      if (order.tripayPayCode) {
        payText += `🔢 *Nomor Pembayaran:*\n\`${order.tripayPayCode}\`\n\n`;
      }
      if (order.tripayPayUrl) {
        payText += `🔗 *Link Pembayaran:*\n${order.tripayPayUrl}\n\n`;
      }
      if (order.tripayQrUrl) {
        payText += `📱 Scan QR melalui link: ${order.tripayQrUrl}\n\n`;
      }
      payText += `ℹ️ Setelah pembayaran berhasil, pesanan akan diproses otomatis.\n`;
      payText += `Cek status: !cekpesanan ${order.id}`;

      await sock.sendMessage(jid, { text: payText }, { quoted: msg });
    } catch (e) {
      await sock.sendMessage(jid, { text: `❌ Gagal membuat pesanan: ${e.message}` }, { quoted: msg });
    }
    return true;
  }
  return false;
}

async function handleOrderHistory(sock, msg, args) {
  const jid = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  const orders = db.getUserOrders(buyerJid);

  if (!orders.length) {
    await sock.sendMessage(jid, { text: '📋 Kamu belum memiliki riwayat pesanan.' }, { quoted: msg });
    return;
  }

  let text = `📋 *RIWAYAT PESANAN*\n\n`;
  orders.slice(-10).reverse().forEach(o => {
    text += `${orderStatusEmoji(o.status)} *${o.id}*\n`;
    text += `   ${o.productName}\n`;
    text += `   ${formatRupiah(o.amount)} | ${orderStatusText(o.status)}\n`;
    text += `   ${formatDate(o.createdAt)}\n\n`;
  });
  text += `_Tampilkan 10 pesanan terakhir_\nDetail: !cekpesanan <ID>`;
  await sock.sendMessage(jid, { text }, { quoted: msg });
}

async function handleCheckOrder(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args[0]) {
    await sock.sendMessage(jid, { text: '❌ Format: !cekpesanan <ID_ORDER>' }, { quoted: msg });
    return;
  }
  const order = db.getOrder(args[0].toUpperCase());
  if (!order) {
    await sock.sendMessage(jid, { text: `❌ Order \`${args[0]}\` tidak ditemukan` }, { quoted: msg });
    return;
  }
  // Verify buyer
  const buyerJid = msg.key.participant || jid;
  if (order.buyerJid !== buyerJid && !isAdmin(buyerJid)) {
    await sock.sendMessage(jid, { text: `❌ Kamu tidak memiliki akses ke order ini` }, { quoted: msg });
    return;
  }

  let text = `📦 *DETAIL PESANAN*\n\n` +
    `ID: ${order.id}\n` +
    `Status: ${orderStatusEmoji(order.status)} ${orderStatusText(order.status)}\n` +
    `Produk: ${order.productName}\n` +
    `Total: ${formatRupiah(order.amount)}\n` +
    `Tanggal: ${formatDate(order.createdAt)}\n`;
  if (order.customerNo) text += `No Tujuan: ${order.customerNo}\n`;
  if (order.digiflazzSn) text += `SN/Token: ${order.digiflazzSn}\n`;
  if (order.tripayPayUrl && order.status === 'pending_payment') text += `\n🔗 Link Bayar: ${order.tripayPayUrl}\n`;
  if (order.adminNote) text += `\n📝 Catatan: ${order.adminNote}\n`;
  if (order.status === 'failed') text += `\nKetik *#komplain ${order.id}* untuk komplain`;

  await sock.sendMessage(jid, { text }, { quoted: msg });
}

async function handleKomplain(sock, msg, args) {
  const jid = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  if (!args[0]) {
    await sock.sendMessage(jid, { text: '❌ Format: #komplain <ID_ORDER> <pesan_komplain>' }, { quoted: msg });
    return;
  }
  const orderId = args[0].toUpperCase();
  const message = args.slice(1).join(' ') || 'Tidak ada pesan';
  const order = db.getOrder(orderId);
  if (!order) {
    await sock.sendMessage(jid, { text: `❌ Order \`${orderId}\` tidak ditemukan` }, { quoted: msg });
    return;
  }
  if (order.buyerJid !== buyerJid) {
    await sock.sendMessage(jid, { text: `❌ Kamu tidak memiliki akses ke order ini` }, { quoted: msg });
    return;
  }
  const phone = buyerJid.replace('@s.whatsapp.net', '');
  await sendToAdmin(`⚠️ *KOMPLAIN DARI PELANGGAN*\n\n` +
    `👤 No WA: ${phone}\n` +
    `📦 Order ID: ${orderId}\n` +
    `🛒 Produk: ${order.productName}\n` +
    `💰 Total: ${formatRupiah(order.amount)}\n` +
    `📝 Pesan: ${message}\n\n` +
    `Status saat ini: ${orderStatusText(order.status)}`);
  await sock.sendMessage(jid, { text: `✅ Komplain untuk order *${orderId}* telah dikirim ke admin. Kami akan segera menghubungi kamu.` }, { quoted: msg });
}

module.exports = { handleMenu, handlePricelist, handleSearch, handleBuy, handleBuyState, handleOrderHistory, handleCheckOrder, handleKomplain, paymentMethodMap };
