const axios   = require('axios');
const moment  = require('moment');
require('moment/locale/id');
moment.locale('id');

const db           = require('../models/db');
const { formatRupiah, formatDate, orderStatusEmoji, orderStatusText, isAdmin } = require('../utils/helper');
const { header, orderHeader, LINE } = require('../utils/template');
const orderService = require('../services/orderService');
const { sendToAdmin } = require('../utils/sender');

// ── State multi-step pembelian ─────────────────────────────────────────────
const buyState = {};

const send = (sock, jid, text, msg) =>
  sock.sendMessage(jid, { text }, msg ? { quoted: msg } : undefined);

// ═══════════════════════════════════════════════════════════════════════════
// MENU
// ═══════════════════════════════════════════════════════════════════════════
async function handleMenu(sock, msg) {
  const jid = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  const user = db.getUser(buyerJid);
  const name = user.name || buyerJid.replace('@s.whatsapp.net', '');

  const text =
    `${header(sock)}\n` +
    ` *MENU ${(process.env.STORE_NAME || 'CASSIE STORE').toUpperCase()}*\n\n` +
    `🛍️⊹ 𝗽𝗿𝗼𝗱𝘂𝗰𝘁 ⦂\n` +
    `  !pricelist — Lihat daftar kategori\n` +
    `  !pricelist <kategori> — Produk per kategori\n` +
    `  !cari <kata kunci> — Cari produk\n\n` +
    `🛍️⊹ 𝗯𝗲𝗹𝗶 ⦂\n` +
    `  !beli <kode> — Beli produk\n` +
    `  #buy <kode> — Sama dengan !beli\n\n` +
    `🛍️⊹ 𝗽𝗲𝘀𝗮𝗻𝗮𝗻 ⦂\n` +
    `  !pesanan — Riwayat pesananku\n` +
    `  !cekpesanan <ID> — Cek status pesanan\n` +
    `  #komplain <ID> <pesan> — Komplain pesanan\n\n` +
    `_Prefix: !, ., #_`;
  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// PRICELIST — per kategori + pagination
// ═══════════════════════════════════════════════════════════════════════════
async function handlePricelist(sock, msg, args) {
  const jid   = msg.key.remoteJid;
  const input = args.join(' ').trim().toLowerCase();

  const digiAll = db.getDigiProducts();
  const manuals = Object.values(db.getProducts()).filter(p => p.active !== false);

  // ── Tanpa argumen: tampil daftar kategori ─────────────────────────────
  if (!input) {
    const catMap = {};
    Object.values(digiAll).forEach(p => {
      if (p.active === false || p.stock !== 'available') return;
      const c = p.category || 'Lainnya';
      catMap[c] = (catMap[c] || 0) + 1;
    });

    let text =
      `${header(sock)}\n` +
      ` *📋 DAFTAR KATEGORI*\n` +
      `${LINE}\n\n`;

    if (manuals.length) {
      text += `🏪 *MANUAL* — ${manuals.length} produk\n`;
      text += `   › !pricelist manual\n\n`;
    }

    if (!Object.keys(catMap).length) {
      text += `_Belum ada produk. Admin ketik .getservice_\n`;
    } else {
      Object.entries(catMap)
        .sort((a, b) => b[1] - a[1])
        .forEach(([cat, count]) => {
          text += `📁 *${cat}* — ${count} produk\n`;
          text += `   › !pricelist ${cat.toLowerCase()}\n`;
        });
    }

    text += `\n${LINE}\n`;
    text += `🔍 *!cari <kata>*  •  🛒 *!beli <kode>*`;
    return await send(sock, jid, text, msg);
  }

  // ── Produk MANUAL ─────────────────────────────────────────────────────
  if (input === 'manual') {
    if (!manuals.length)
      return await send(sock, jid,
        `${header(sock)}\n❌ Belum ada produk manual.`, msg);

    let text =
      `${header(sock)}\n` +
      ` *🏪 PRODUK MANUAL*\n` +
      `${LINE}\n\n`;

    manuals.forEach(p => {
      text += `🩰 *${p.name}*\n`;
      text += `   𝗸𝗼𝗱𝗲  ⦂ \`${p.id}\`\n`;
      text += `   𝗵𝗮𝗿𝗴𝗮 ⦂ *${formatRupiah(p.price)}*\n`;
      if (p.description) text += `   𝗶𝗻𝗳𝗼  ⦂ ${p.description}\n`;
      if (p.stock !== undefined)
        text += `   𝘀𝘁𝗼𝗸  ⦂ ${p.stock > 0 ? p.stock : '❌ Habis'}\n`;
      text += '\n';
    });

    text += `${LINE}\n`;
    text += `💡 *!beli ${manuals[0]?.id || 'KODE'}*`;
    return await send(sock, jid, text, msg);
  }

  // ── Kategori / brand Digiflazz ────────────────────────────────────────
  const matched = Object.values(digiAll).filter(p => {
    if (p.active === false || p.stock !== 'available') return false;
    return (
      p.category?.toLowerCase().includes(input) ||
      p.brand?.toLowerCase().includes(input)
    );
  });

  if (!matched.length)
    return await send(sock, jid,
      `${header(sock)}\n❌ Kategori *${input}* tidak ditemukan.\nKetik *!pricelist* untuk daftar kategori.`, msg);

  // Group by brand
  const brands = {};
  matched.forEach(p => {
    const b = p.brand || 'Lainnya';
    if (!brands[b]) brands[b] = [];
    brands[b].push(p);
  });

  const LIMIT  = 1800;
  const catTitle = input.toUpperCase();
  let chunk    = `${header(sock)}\n *📁 ${catTitle}* — ${matched.length} produk\n${LINE}\n\n`;
  let chunks   = [];

  Object.entries(brands).forEach(([brand, prods]) => {
    let block = `📱 *${brand}*\n`;
    prods.forEach(p => {
      block += `  🩰 ${p.name}\n`;
      block += `     𝗸𝗼𝗱𝗲 ⦂ \`${p.sku}\`  𝗵𝗮𝗿𝗴𝗮 ⦂ ${formatRupiah(p.sellPrice)}\n`;
    });
    block += '\n';

    if (chunk.length + block.length > LIMIT) {
      chunks.push(chunk);
      chunk = ` *📁 ${catTitle}* (lanjutan)\n${LINE}\n\n`;
    }
    chunk += block;
  });
  chunks.push(chunk);

  const total = chunks.length;
  for (let i = 0; i < chunks.length; i++) {
    let page = chunks[i];
    if (total > 1) page += `📄 _Halaman ${i + 1}/${total}_\n`;
    if (i === chunks.length - 1) {
      page += `${LINE}\n`;
      page += `💡 *!beli <kode>*  •  🔍 *!cari <kata>*`;
    }
    await send(sock, jid, page, i === 0 ? msg : null);
    if (total > 1 && i < chunks.length - 1)
      await new Promise(r => setTimeout(r, 700));
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// CARI
// ═══════════════════════════════════════════════════════════════════════════
async function handleSearch(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args.length)
    return await send(sock, jid,
      `❌ Format: *!cari <kata kunci>*\nContoh: !cari xl 5000`, msg);

  const kw      = args.join(' ').toLowerCase();
  const digi    = db.getDigiProducts();
  const manuals = Object.values(db.getProducts()).filter(p => p.active !== false);

  const results = [];
  manuals.forEach(p => {
    if (p.name.toLowerCase().includes(kw) || p.id.toLowerCase().includes(kw))
      results.push({ _type: 'manual', kode: p.id, nama: p.name, harga: p.price });
  });
  Object.values(digi).forEach(p => {
    if (p.active === false) return;
    if (p.name.toLowerCase().includes(kw) || p.sku.toLowerCase().includes(kw) || p.brand?.toLowerCase().includes(kw))
      results.push({ _type: 'digi', kode: p.sku, nama: p.name, harga: p.sellPrice });
  });

  if (!results.length)
    return await send(sock, jid,
      `${header(sock)}\n🔍 Produk "*${kw}*" tidak ditemukan.\n\nCoba kata lain atau lihat *!pricelist*`, msg);

  let text =
    `${header(sock)}\n` +
    ` *🔍 HASIL: "${kw}"*\n` +
    `${LINE}\n` +
    `_${results.length} produk ditemukan_\n\n`;

  results.slice(0, 25).forEach(p => {
    const icon = p._type === 'manual' ? '🏪' : '🩰';
    text += `${icon} *${p.nama}*\n`;
    text += `   𝗸𝗼𝗱𝗲 ⦂ \`${p.kode}\`  𝗵𝗮𝗿𝗴𝗮 ⦂ ${formatRupiah(p.harga)}\n\n`;
  });
  if (results.length > 25)
    text += `_... +${results.length - 25} lainnya. Persempit pencarian._\n\n`;
  text += `${LINE}\n💡 *!beli <kode>*`;
  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// BELI — deteksi otomatis manual vs digiflazz
// ═══════════════════════════════════════════════════════════════════════════
async function handleBuy(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;

  if (!args[0]) {
    return await send(sock, jid,
      `${header(sock)}\n` +
      ` *🛒 CARA BELI*\n${LINE}\n\n` +
      `📦 Produk topup (pulsa, data, dll):\n` +
      `   *!beli <kode> <nomor>*\n` +
      `   _Contoh: !beli XL5 08123456789_\n\n` +
      `🏪 Produk manual (joki, dll):\n` +
      `   *!beli <kode>*\n` +
      `   _Contoh: !beli JOKI-ML_\n\n` +
      `${LINE}\n` +
      `📋 *!pricelist*  •  🔍 *!cari <kata>*`, msg);
  }

  const kodeInput = args[0].toUpperCase();

  // ── Cek manual dulu ───────────────────────────────────────────────────
  const manualProd = db.getProduct(kodeInput);
  if (manualProd && manualProd.active !== false) {
    if (manualProd.stock !== undefined && manualProd.stock <= 0)
      return await send(sock, jid, `❌ Stok *${manualProd.name}* habis`, msg);

    buyState[buyerJid] = {
      productId: kodeInput, productType: 'manual',
      productName: manualProd.name, amount: manualProd.price,
      customerNo: '', step: 'select_payment'
    };
    return await showPaymentMenu(sock, jid, msg, manualProd.name, manualProd.price);
  }

  // ── Cek Digiflazz ─────────────────────────────────────────────────────
  const digiProd = db.getDigiProducts()[kodeInput];
  if (digiProd && digiProd.active !== false) {
    if (digiProd.stock === 'empty')
      return await send(sock, jid, `❌ Produk *${digiProd.name}* sedang kosong`, msg);

    const customerNo = args[1];
    if (!customerNo) {
      return await send(sock, jid,
        `${header(sock)}\n` +
        ` 🩰 *${digiProd.name}*\n` +
        `${LINE}\n` +
        `   𝗵𝗮𝗿𝗴𝗮 ⦂ *${formatRupiah(digiProd.sellPrice)}*\n\n` +
        `❗ Masukkan nomor tujuan!\n` +
        `Format: *!beli ${kodeInput} <nomor>*\n` +
        `Contoh: *!beli ${kodeInput} 08123456789*`, msg);
    }

    buyState[buyerJid] = {
      productId: kodeInput, productType: 'digiflazz',
      productName: digiProd.name, amount: digiProd.sellPrice,
      customerNo, step: 'select_payment'
    };
    return await showPaymentMenu(sock, jid, msg, digiProd.name, digiProd.sellPrice, customerNo);
  }

  // ── Tidak ketemu ──────────────────────────────────────────────────────
  await send(sock, jid,
    `${header(sock)}\n❌ Kode *${kodeInput}* tidak ditemukan.\n\n` +
    `🔍 *!cari ${args[0]}*  •  📋 *!pricelist*`, msg);
}

// ── Tampil menu pilih pembayaran ───────────────────────────────────────────
async function showPaymentMenu(sock, jid, msg, productName, amount, customerNo = '') {
  const text =
    `${header(sock)}\n` +
    ` *🛒 DETAIL PEMBELIAN*\n` +
    `${LINE}\n` +
    `🩰 𝗽𝗿𝗼𝗱𝘂𝗸   ⦂ ${productName}\n` +
    (customerNo ? `📱 𝗻𝗼. 𝘁𝘂𝗷𝘂𝗮𝗻 ⦂ ${customerNo}\n` : '') +
    `💰 𝘁𝗼𝘁𝗮𝗹    ⦂ *${formatRupiah(amount)}*\n` +
    `${LINE}\n\n` +
    `*Pilih metode pembayaran:*\n\n` +
    `1️⃣  QRIS _(scan QR)_\n` +
    `2️⃣  BCA Virtual Account\n` +
    `3️⃣  BRI Virtual Account\n` +
    `4️⃣  Mandiri Virtual Account\n` +
    `5️⃣  OVO\n` +
    `6️⃣  GoPay\n` +
    `7️⃣  DANA\n\n` +
    `Balas *1-7* atau ketik *batal*`;
  await send(sock, jid, text, msg);
}

const PAY_MAP = {
  '1': 'QRIS', '2': 'BCAVA', '3': 'BRIVA', '4': 'MANDIRIVA',
  '5': 'OVO',  '6': 'GOPAY', '7': 'DANA',
  'qris': 'QRIS', 'bca': 'BCAVA', 'bri': 'BRIVA',
  'mandiri': 'MANDIRIVA', 'ovo': 'OVO', 'gopay': 'GOPAY', 'dana': 'DANA'
};
const PAY_LABEL = {
  QRIS: 'QRIS', BCAVA: 'BCA Virtual Account', BRIVA: 'BRI Virtual Account',
  MANDIRIVA: 'Mandiri Virtual Account', OVO: 'OVO', GOPAY: 'GoPay', DANA: 'DANA'
};

// ── Handler state pembelian ────────────────────────────────────────────────
async function handleBuyState(sock, msg, rawText) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  const state    = buyState[buyerJid];
  if (!state) return false;

  const input = rawText.trim().toLowerCase();

  if (input === 'batal') {
    delete buyState[buyerJid];
    await send(sock, jid, `❌ Pembelian dibatalkan.`, msg);
    return true;
  }

  // ── Step 1: pilih metode ───────────────────────────────────────────────
  if (state.step === 'select_payment') {
    const method = PAY_MAP[input];
    if (!method) {
      await send(sock, jid, `❌ Pilihan tidak valid. Ketik *1-7* atau *batal*.`, msg);
      return true;
    }
    state.paymentMethod = method;
    state.step = 'confirm';

    const confirmText =
      `${header(sock)}\n` +
      ` *✅ KONFIRMASI PESANAN*\n` +
      `${LINE}\n` +
      `🩰 𝗽𝗿𝗼𝗱𝘂𝗸   ⦂ ${state.productName}\n` +
      (state.customerNo ? `📱 𝗻𝗼. 𝘁𝘂𝗷𝘂𝗮𝗻 ⦂ ${state.customerNo}\n` : '') +
      `💰 𝘁𝗼𝘁𝗮𝗹    ⦂ *${formatRupiah(state.amount)}*\n` +
      `💳 𝗽𝗮𝘆𝗺𝗲𝗻𝘁  ⦂ ${PAY_LABEL[method] || method}\n` +
      `${LINE}\n\n` +
      `Ketik *ya* untuk lanjut atau *batal* untuk batal`;
    await send(sock, jid, confirmText, msg);
    return true;
  }

  // ── Step 2: konfirmasi ─────────────────────────────────────────────────
  if (state.step === 'confirm') {
    if (input !== 'ya' && input !== 'yes') {
      await send(sock, jid, `❌ Ketik *ya* untuk lanjut atau *batal* untuk batal.`, msg);
      return true;
    }
    const snap = { ...state };
    delete buyState[buyerJid];

    await send(sock, jid, `⏳ _Membuat invoice pembayaran..._`, msg);

    try {
      const user  = db.getUser(buyerJid);
      const order = await orderService.createOrder({
        buyerJid,
        buyerName:     user.name || buyerJid.replace('@s.whatsapp.net', ''),
        productId:     snap.productId,
        productType:   snap.productType,
        customerNo:    snap.customerNo,
        paymentMethod: snap.paymentMethod
      });

      const exp = new Date(order.tripayExpiredTime * 1000);
      let invoiceText =
        `${header(sock)}\n` +
        ` *🧾 INVOICE PEMBAYARAN*\n` +
        `${LINE}\n` +
        `📦 𝗼𝗿𝗱𝗲𝗿   ⦂ \`${order.id}\`\n` +
        `🩰 𝗽𝗿𝗼𝗱𝘂𝗸   ⦂ ${order.productName}\n` +
        (snap.customerNo ? `📱 𝗻𝗼. 𝘁𝘂𝗷𝘂𝗮𝗻 ⦂ ${snap.customerNo}\n` : '') +
        `💰 𝘁𝗼𝘁𝗮𝗹    ⦂ *${formatRupiah(order.amount)}*\n` +
        `💳 𝗺𝗲𝘁𝗼𝗱𝗲   ⦂ ${PAY_LABEL[order.paymentMethod] || order.paymentMethod}\n` +
        `⏰ 𝗯𝗲𝗿𝗹𝗮𝗸𝘂  ⦂ ${formatDate(exp)}\n` +
        `${LINE}\n\n`;

      if (order.tripayPayCode) {
        invoiceText += `🔢 *Nomor Pembayaran:*\n\`${order.tripayPayCode}\`\n\n`;
      }
      if (order.tripayPayUrl) {
        invoiceText += `🔗 *Link Bayar:*\n${order.tripayPayUrl}\n\n`;
      }
      invoiceText += `_Cek status: *!cekpesanan ${order.id}*_`;

      await send(sock, jid, invoiceText, msg);

      // Kirim gambar QR kalau QRIS
      if (snap.paymentMethod === 'QRIS' && order.tripayQrUrl) {
        await sendQrisImage(sock, jid, order);
      }

    } catch (e) {
      await send(sock, jid,
        `${header(sock)}\n❌ *Gagal membuat pesanan*\n${LINE}\n\n` +
        `${e.message}\n\n` +
        `_Coba beberapa saat lagi atau hubungi admin_`, msg);
    }
    return true;
  }

  return false;
}

// ── Kirim gambar QRIS ──────────────────────────────────────────────────────
async function sendQrisImage(sock, jid, order) {
  try {
    const resp = await axios.get(order.tripayQrUrl, { responseType: 'arraybuffer', timeout: 10000 });
    const buf  = Buffer.from(resp.data);
    await sock.sendMessage(jid, {
      image:   buf,
      caption:
        `📱 *Scan QRIS untuk membayar*\n\n` +
        `Order : \`${order.id}\`\n` +
        `Total : *${formatRupiah(order.amount)}*\n\n` +
        `_Berlaku hingga ${formatDate(new Date(order.tripayExpiredTime * 1000))}_`
    });
  } catch {
    await sock.sendMessage(jid, {
      text: `📱 *Link QRIS:*\n${order.tripayQrUrl}\n\nBuka di browser lalu scan QR-nya.`
    });
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// RIWAYAT PESANAN
// ═══════════════════════════════════════════════════════════════════════════
async function handleOrderHistory(sock, msg) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  const orders   = db.getUserOrders(buyerJid);

  if (!orders.length)
    return await send(sock, jid,
      `${header(sock)}\n📋 Belum ada riwayat pesanan.`, msg);

  let text =
    `${header(sock)}\n` +
    ` *📋 RIWAYAT PESANANKU*\n` +
    `${LINE}\n` +
    `_10 pesanan terakhir_\n\n`;

  orders.slice(-10).reverse().forEach(o => {
    text += `${orderStatusEmoji(o.status)} *${o.id}*\n`;
    text += `   🩰 ${o.productName}\n`;
    text += `   💰 ${formatRupiah(o.amount)} — ${orderStatusText(o.status)}\n`;
    text += `   🕐 ${formatDate(o.createdAt)}\n\n`;
  });
  text += `${LINE}\n_Detail: *!cekpesanan <ID>*_`;
  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// CEK PESANAN
// ═══════════════════════════════════════════════════════════════════════════
async function handleCheckOrder(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;

  if (!args[0])
    return await send(sock, jid, `❌ Format: *!cekpesanan <ID_ORDER>*`, msg);

  const order = db.getOrder(args[0].toUpperCase());
  if (!order)
    return await send(sock, jid, `❌ Order \`${args[0]}\` tidak ditemukan.`, msg);

  if (order.buyerJid !== buyerJid && !isAdmin(buyerJid))
    return await send(sock, jid, `❌ Kamu tidak punya akses ke order ini.`, msg);

  let text =
    `${header(sock)}\n` +
    ` *📦 DETAIL PESANAN*\n` +
    `${LINE}\n` +
    `📋 𝗜𝗗      ⦂ \`${order.id}\`\n` +
    `${orderStatusEmoji(order.status)} 𝘀𝘁𝗮𝘁𝘂𝘀  ⦂ ${orderStatusText(order.status)}\n` +
    `🩰 𝗽𝗿𝗼𝗱𝘂𝗸  ⦂ ${order.productName}\n` +
    `💰 𝘁𝗼𝘁𝗮𝗹  ⦂ ${formatRupiah(order.amount)}\n` +
    `🕐 𝘁𝗮𝗻𝗴𝗴𝗮𝗹 ⦂ ${formatDate(order.createdAt)}\n`;

  if (order.customerNo)  text += `📱 𝗻𝗼. 𝘁𝘂𝗷 ⦂ ${order.customerNo}\n`;
  if (order.digiflazzSn) text += `🔑 𝗦𝗡/𝘁𝗼𝗸𝗲𝗻 ⦂ ${order.digiflazzSn}\n`;
  if (order.adminNote)   text += `📝 𝗰𝗮𝘁𝗮𝘁𝗮𝗻 ⦂ ${order.adminNote}\n`;

  text += `${LINE}\n`;

  if (order.status === 'pending_payment' && order.tripayPayUrl)
    text += `🔗 *Link Bayar:* ${order.tripayPayUrl}\n`;
  if (order.status === 'failed')
    text += `💬 *#komplain ${order.id} <pesan>*`;

  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// KOMPLAIN
// ═══════════════════════════════════════════════════════════════════════════
async function handleKomplain(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;

  if (!args[0])
    return await send(sock, jid, `❌ Format: *#komplain <ID_ORDER> <pesan>*`, msg);

  const orderId = args[0].toUpperCase();
  const pesan   = args.slice(1).join(' ') || '(tanpa pesan)';
  const order   = db.getOrder(orderId);

  if (!order)
    return await send(sock, jid, `❌ Order \`${orderId}\` tidak ditemukan.`, msg);
  if (order.buyerJid !== buyerJid)
    return await send(sock, jid, `❌ Kamu tidak punya akses ke order ini.`, msg);

  const phone = buyerJid.replace('@s.whatsapp.net', '');
  await sendToAdmin(
    `⚠️ *KOMPLAIN PELANGGAN*\n${LINE}\n` +
    `👤 WA    ⦂ ${phone}\n` +
    `📦 Order ⦂ ${orderId}\n` +
    `🩰 Produk ⦂ ${order.productName}\n` +
    `💰 Total ⦂ ${formatRupiah(order.amount)}\n` +
    `📝 Pesan ⦂ ${pesan}\n` +
    `📋 Status ⦂ ${orderStatusText(order.status)}`
  );
  await send(sock, jid,
    `✅ Komplain order *${orderId}* sudah dikirim ke admin!\nKami akan segera menghubungimu 🩰`, msg);
}

module.exports = {
  handleMenu, handlePricelist, handleSearch,
  handleBuy, handleBuyState,
  handleOrderHistory, handleCheckOrder, handleKomplain,
  PAY_MAP
};
