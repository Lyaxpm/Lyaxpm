const axios   = require('axios');
const db      = require('../models/db');
const { formatRupiah, formatDate, orderStatusEmoji, orderStatusText, isAdmin } = require('../utils/helper');
const orderService = require('../services/orderService');
const { sendToAdmin } = require('../utils/sender');

// ── State multi-step pembelian ─────────────────────────────────────────────
const buyState = {};

// ── Helper: kirim teks ─────────────────────────────────────────────────────
const send = (sock, jid, text, msg) =>
  sock.sendMessage(jid, { text }, msg ? { quoted: msg } : undefined);

// ═══════════════════════════════════════════════════════════════════════════
// MENU
// ═══════════════════════════════════════════════════════════════════════════
async function handleMenu(sock, msg) {
  const jid  = msg.key.remoteJid;
  const text =
    `🛒 *MENU TOKO DIGITAL*\n\n` +
    `📋 *Produk*\n` +
    `  !pricelist — Lihat daftar kategori\n` +
    `  !pricelist <kategori> — Produk per kategori\n` +
    `  !cari <kata kunci> — Cari produk\n\n` +
    `💳 *Beli*\n` +
    `  !beli <kode> — Beli produk (semua jenis)\n` +
    `  #buy <kode> — Sama dengan !beli\n\n` +
    `📦 *Pesanan*\n` +
    `  !pesanan — Riwayat pesananku\n` +
    `  !cekpesanan <ID> — Cek status pesanan\n` +
    `  #komplain <ID> <pesan> — Komplain pesanan\n\n` +
    `_Prefix: !, ., #_`;
  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// PRICELIST — tampil per kategori + pagination
// ═══════════════════════════════════════════════════════════════════════════
async function handlePricelist(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const input    = args.join(' ').trim().toLowerCase();

  const digiAll  = db.getDigiProducts();
  const manuals  = Object.values(db.getProducts()).filter(p => p.active !== false);

  // ── Tanpa argumen: tampilkan DAFTAR KATEGORI ──────────────────────────
  if (!input) {
    // Kumpulkan kategori unik dari Digiflazz
    const catMap = {};
    Object.values(digiAll).forEach(p => {
      if (p.active === false || p.stock !== 'available') return;
      const c = p.category || 'Lainnya';
      catMap[c] = (catMap[c] || 0) + 1;
    });

    let text = `📋 *KATEGORI PRODUK*\n\n`;

    if (manuals.length) {
      text += `🏪 *MANUAL* — ${manuals.length} produk\n`;
      text += `   Ketik: *!pricelist manual*\n\n`;
    }

    Object.entries(catMap)
      .sort((a, b) => b[1] - a[1])
      .forEach(([cat, count]) => {
        text += `📁 *${cat}* — ${count} produk\n`;
        text += `   Ketik: *!pricelist ${cat.toLowerCase()}*\n`;
      });

    text += `\n💡 Cari produk: *!cari <kata kunci>*`;
    text += `\n💡 Beli: *!beli <kode_produk>*`;
    return await send(sock, jid, text, msg);
  }

  // ── Kategori MANUAL ───────────────────────────────────────────────────
  if (input === 'manual') {
    if (!manuals.length) {
      return await send(sock, jid, '❌ Belum ada produk manual.', msg);
    }
    let text = `🏪 *PRODUK MANUAL*\n${'─'.repeat(28)}\n\n`;
    manuals.forEach(p => {
      text += `🔹 *${p.name}*\n`;
      text += `   Kode: \`${p.id}\`\n`;
      text += `   Harga: *${formatRupiah(p.price)}*\n`;
      if (p.description) text += `   ${p.description}\n`;
      if (p.stock !== undefined) text += `   Stok: ${p.stock > 0 ? p.stock : '❌ Habis'}\n`;
      text += '\n';
    });
    text += `\n💡 Cara beli: *!beli ${manuals[0]?.id || 'KODE'}*`;
    return await send(sock, jid, text, msg);
  }

  // ── Kategori / brand Digiflazz ────────────────────────────────────────
  const matched = Object.values(digiAll).filter(p => {
    if (p.active === false || p.stock !== 'available') return false;
    return (
      p.category?.toLowerCase().includes(input) ||
      p.brand?.toLowerCase().includes(input)
    );
  });

  if (!matched.length) {
    return await send(sock, jid,
      `❌ Kategori *${input}* tidak ditemukan.\nKetik *!pricelist* untuk lihat semua kategori.`, msg);
  }

  // Group by brand
  const brands = {};
  matched.forEach(p => {
    const b = p.brand || 'Lainnya';
    if (!brands[b]) brands[b] = [];
    brands[b].push(p);
  });

  const LIMIT = 1500; // karakter per pesan agar aman
  let chunk   = `📁 *${input.toUpperCase()}* — ${matched.length} produk\n${'─'.repeat(28)}\n\n`;
  let chunks  = [];

  Object.entries(brands).forEach(([brand, prods]) => {
    let brandBlock = `📱 *${brand}*\n`;
    prods.forEach(p => {
      brandBlock += `  • ${p.name}\n`;
      brandBlock += `    Kode: \`${p.sku}\`  |  ${formatRupiah(p.sellPrice)}\n`;
    });
    brandBlock += '\n';

    if (chunk.length + brandBlock.length > LIMIT) {
      chunks.push(chunk);
      chunk = `📁 *${input.toUpperCase()}* (lanjutan)\n\n`;
    }
    chunk += brandBlock;
  });
  chunks.push(chunk);

  const total = chunks.length;
  for (let i = 0; i < chunks.length; i++) {
    let page = chunks[i];
    if (total > 1) page += `\n📄 Halaman ${i + 1}/${total}`;
    if (i === chunks.length - 1) {
      page += `\n\n💡 Beli: *!beli <kode_produk>*`;
      page += `\n🔍 Cari: *!cari <kata kunci>*`;
    }
    await send(sock, jid, page, i === 0 ? msg : null);
    if (total > 1) await new Promise(r => setTimeout(r, 600));
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// CARI
// ═══════════════════════════════════════════════════════════════════════════
async function handleSearch(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args.length) {
    return await send(sock, jid, '❌ Format: *!cari <kata kunci>*\nContoh: !cari xl 5000', msg);
  }
  const kw      = args.join(' ').toLowerCase();
  const digi    = db.getDigiProducts();
  const manuals = Object.values(db.getProducts()).filter(p => p.active !== false);

  const results = [];
  manuals.forEach(p => {
    if (p.name.toLowerCase().includes(kw) || p.id.toLowerCase().includes(kw))
      results.push({ _type: 'manual', kode: p.id, nama: p.name, harga: p.price });
  });
  Object.values(digi).forEach(p => {
    if (p.active === false) return;
    if (p.name.toLowerCase().includes(kw) || p.sku.toLowerCase().includes(kw) || p.brand?.toLowerCase().includes(kw))
      results.push({ _type: 'digi', kode: p.sku, nama: p.name, harga: p.sellPrice, brand: p.brand });
  });

  if (!results.length)
    return await send(sock, jid, `❌ Produk "*${kw}*" tidak ditemukan.`, msg);

  let text = `🔍 *HASIL PENCARIAN: "${kw}"*\n${results.length} produk ditemukan\n\n`;
  results.slice(0, 25).forEach(p => {
    const icon = p._type === 'manual' ? '🏪' : '📦';
    text += `${icon} *${p.nama}*\n`;
    text += `   Kode: \`${p.kode}\`  |  ${formatRupiah(p.harga)}\n\n`;
  });
  if (results.length > 25) text += `_... dan ${results.length - 25} lainnya. Persempit pencarian._\n\n`;
  text += `💡 Beli: *!beli <kode>*`;
  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// BELI — deteksi otomatis manual vs digiflazz
// ═══════════════════════════════════════════════════════════════════════════
async function handleBuy(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;

  if (!args[0]) {
    return await send(sock, jid,
      `❌ Format beli:\n` +
      `• Produk topup : *!beli <kode> <nomor tujuan>*\n` +
      `  Contoh: *!beli XL5 08123456789*\n\n` +
      `• Produk manual: *!beli <kode>*\n` +
      `  Contoh: *!beli JOKI-ML*\n\n` +
      `Lihat produk: *!pricelist*  |  Cari: *!cari <kata>*`, msg);
  }

  const kodeInput = args[0].toUpperCase();

  // ── Cek manual dulu ───────────────────────────────────────────────────
  const manualProd = db.getProduct(kodeInput);
  if (manualProd && manualProd.active !== false) {
    if (manualProd.stock !== undefined && manualProd.stock <= 0) {
      return await send(sock, jid, `❌ Stok *${manualProd.name}* habis`, msg);
    }
    buyState[buyerJid] = {
      productId: kodeInput, productType: 'manual',
      productName: manualProd.name, amount: manualProd.price,
      customerNo: '', step: 'select_payment'
    };
    return await showPaymentMenu(sock, jid, msg, manualProd.name, manualProd.price);
  }

  // ── Cek Digiflazz ─────────────────────────────────────────────────────
  const digiProd = db.getDigiProducts()[kodeInput];
  if (digiProd && digiProd.active !== false) {
    if (digiProd.stock === 'empty') {
      return await send(sock, jid, `❌ Produk *${digiProd.name}* sedang kosong`, msg);
    }
    // Produk Digiflazz butuh nomor tujuan
    const customerNo = args[1];
    if (!customerNo) {
      return await send(sock, jid,
        `📦 *${digiProd.name}*\nHarga: ${formatRupiah(digiProd.sellPrice)}\n\n` +
        `❌ Belum ada nomor tujuan!\n` +
        `Format: *!beli ${kodeInput} <nomor>*\nContoh: *!beli ${kodeInput} 08123456789*`, msg);
    }
    buyState[buyerJid] = {
      productId: kodeInput, productType: 'digiflazz',
      productName: digiProd.name, amount: digiProd.sellPrice,
      customerNo, step: 'select_payment'
    };
    return await showPaymentMenu(sock, jid, msg, digiProd.name, digiProd.sellPrice, customerNo);
  }

  // ── Tidak ketemu ──────────────────────────────────────────────────────
  await send(sock, jid,
    `❌ Kode *${kodeInput}* tidak ditemukan.\n\n` +
    `🔍 Cari produk: *!cari ${args[0]}*\n` +
    `📋 Lihat kategori: *!pricelist*`, msg);
}

// ── Tampil menu pilih pembayaran ───────────────────────────────────────────
async function showPaymentMenu(sock, jid, msg, productName, amount, customerNo = '') {
  const text =
    `🛒 *DETAIL PEMBELIAN*\n\n` +
    `📦 Produk  : ${productName}\n` +
    (customerNo ? `📱 No Tujuan: ${customerNo}\n` : '') +
    `💰 Total   : *${formatRupiah(amount)}*\n\n` +
    `*Pilih metode pembayaran:*\n` +
    `1️⃣  QRIS (scan QR)\n` +
    `2️⃣  BCA Virtual Account\n` +
    `3️⃣  BRI Virtual Account\n` +
    `4️⃣  Mandiri Virtual Account\n` +
    `5️⃣  OVO\n` +
    `6️⃣  GoPay\n` +
    `7️⃣  DANA\n\n` +
    `Balas angka *1-7* atau ketik *batal*`;
  await send(sock, jid, text, msg);
}

const PAY_MAP = {
  '1': 'QRIS', '2': 'BCAVA', '3': 'BRIVA', '4': 'MANDIRIVA',
  '5': 'OVO',  '6': 'GOPAY', '7': 'DANA',
  'qris': 'QRIS', 'bca': 'BCAVA', 'bri': 'BRIVA',
  'mandiri': 'MANDIRIVA', 'ovo': 'OVO', 'gopay': 'GOPAY', 'dana': 'DANA'
};
const PAY_LABEL = {
  QRIS: 'QRIS', BCAVA: 'BCA Virtual Account', BRIVA: 'BRI Virtual Account',
  MANDIRIVA: 'Mandiri Virtual Account', OVO: 'OVO', GOPAY: 'GoPay', DANA: 'DANA'
};

// ── Handler state pembelian (dipanggil setiap pesan masuk) ─────────────────
async function handleBuyState(sock, msg, rawText) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  const state    = buyState[buyerJid];
  if (!state) return false;

  const input = rawText.trim().toLowerCase();

  if (input === 'batal') {
    delete buyState[buyerJid];
    await send(sock, jid, '❌ Pembelian dibatalkan.', msg);
    return true;
  }

  // ── Step 1: pilih metode bayar ─────────────────────────────────────────
  if (state.step === 'select_payment') {
    const method = PAY_MAP[input];
    if (!method) {
      await send(sock, jid, '❌ Pilihan tidak valid. Ketik angka *1-7* atau *batal*.', msg);
      return true;
    }
    state.paymentMethod = method;
    state.step = 'confirm';
    const confirmText =
      `✅ *KONFIRMASI PESANAN*\n\n` +
      `📦 Produk  : ${state.productName}\n` +
      (state.customerNo ? `📱 No Tujuan: ${state.customerNo}\n` : '') +
      `💰 Total   : *${formatRupiah(state.amount)}*\n` +
      `💳 Bayar   : ${PAY_LABEL[method] || method}\n\n` +
      `Ketik *ya* untuk lanjut atau *batal* untuk batal`;
    await send(sock, jid, confirmText, msg);
    return true;
  }

  // ── Step 2: konfirmasi ─────────────────────────────────────────────────
  if (state.step === 'confirm') {
    if (input !== 'ya' && input !== 'yes') {
      await send(sock, jid, '❌ Ketik *ya* untuk konfirmasi atau *batal* untuk batal.', msg);
      return true;
    }
    const snap = { ...state };
    delete buyState[buyerJid];

    await send(sock, jid, '⏳ Membuat invoice pembayaran...', msg);

    try {
      const user  = db.getUser(buyerJid);
      const order = await orderService.createOrder({
        buyerJid,
        buyerName:     user.name || buyerJid.replace('@s.whatsapp.net', ''),
        productId:     snap.productId,
        productType:   snap.productType,
        customerNo:    snap.customerNo,
        paymentMethod: snap.paymentMethod
      });

      // ── Kirim invoice ────────────────────────────────────────────────
      const exp = new Date(order.tripayExpiredTime * 1000);
      let invoiceText =
        `🧾 *INVOICE PEMBAYARAN*\n\n` +
        `📦 Order ID : ${order.id}\n` +
        `🛒 Produk   : ${order.productName}\n` +
        `💰 Total    : *${formatRupiah(order.amount)}*\n` +
        `💳 Metode   : ${PAY_LABEL[order.paymentMethod] || order.paymentMethod}\n` +
        `⏰ Berlaku  : ${formatDate(exp)}\n\n`;

      if (order.tripayPayCode) {
        invoiceText += `🔢 *Nomor Pembayaran:*\n\`${order.tripayPayCode}\`\n\n`;
      }
      if (order.tripayPayUrl) {
        invoiceText += `🔗 *Link Bayar:*\n${order.tripayPayUrl}\n\n`;
      }
      invoiceText += `Cek status: *!cekpesanan ${order.id}*`;

      await send(sock, jid, invoiceText, msg);

      // ── Khusus QRIS: kirim gambar QR ────────────────────────────────
      if (snap.paymentMethod === 'QRIS' && order.tripayQrUrl) {
        await sendQrisImage(sock, jid, order);
      }

    } catch (e) {
      await send(sock, jid, `❌ Gagal membuat pesanan:\n${e.message}`, msg);
    }
    return true;
  }

  return false;
}

// ── Unduh & kirim gambar QRIS ──────────────────────────────────────────────
async function sendQrisImage(sock, jid, order) {
  try {
    const resp = await axios.get(order.tripayQrUrl, { responseType: 'arraybuffer', timeout: 10000 });
    const buf  = Buffer.from(resp.data);
    await sock.sendMessage(jid, {
      image:   buf,
      caption: `📱 *Scan QRIS untuk membayar*\n\n` +
                `Order: ${order.id}\n` +
                `Total: *${formatRupiah(order.amount)}*\n\n` +
                `_QR berlaku hingga ${formatDate(new Date(order.tripayExpiredTime * 1000))}_`
    });
  } catch (e) {
    // Gagal unduh gambar — fallback ke teks link saja
    await sock.sendMessage(jid, {
      text: `📱 *Link QRIS:*\n${order.tripayQrUrl}\n\nBuka link di browser lalu scan QR-nya.`
    });
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// RIWAYAT PESANAN
// ═══════════════════════════════════════════════════════════════════════════
async function handleOrderHistory(sock, msg) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  const orders   = db.getUserOrders(buyerJid);

  if (!orders.length)
    return await send(sock, jid, '📋 Kamu belum memiliki riwayat pesanan.', msg);

  let text = `📋 *RIWAYAT PESANANKU*\n_10 pesanan terakhir_\n\n`;
  orders.slice(-10).reverse().forEach(o => {
    text += `${orderStatusEmoji(o.status)} *${o.id}*\n`;
    text += `   ${o.productName}\n`;
    text += `   ${formatRupiah(o.amount)} — ${orderStatusText(o.status)}\n`;
    text += `   ${formatDate(o.createdAt)}\n\n`;
  });
  text += `Detail: *!cekpesanan <ID>*`;
  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// CEK PESANAN
// ═══════════════════════════════════════════════════════════════════════════
async function handleCheckOrder(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;

  if (!args[0])
    return await send(sock, jid, '❌ Format: *!cekpesanan <ID_ORDER>*', msg);

  const order = db.getOrder(args[0].toUpperCase());
  if (!order)
    return await send(sock, jid, `❌ Order \`${args[0]}\` tidak ditemukan.`, msg);

  if (order.buyerJid !== buyerJid && !isAdmin(buyerJid))
    return await send(sock, jid, '❌ Kamu tidak punya akses ke order ini.', msg);

  let text =
    `📦 *DETAIL PESANAN*\n\n` +
    `ID     : ${order.id}\n` +
    `Status : ${orderStatusEmoji(order.status)} ${orderStatusText(order.status)}\n` +
    `Produk : ${order.productName}\n` +
    `Total  : ${formatRupiah(order.amount)}\n` +
    `Tanggal: ${formatDate(order.createdAt)}\n`;
  if (order.customerNo)  text += `No Tujuan: ${order.customerNo}\n`;
  if (order.digiflazzSn) text += `SN/Token : ${order.digiflazzSn}\n`;
  if (order.adminNote)   text += `\n📝 Catatan: ${order.adminNote}\n`;
  if (order.status === 'pending_payment' && order.tripayPayUrl) {
    text += `\n🔗 Link Bayar: ${order.tripayPayUrl}\n`;
  }
  if (order.status === 'failed') {
    text += `\nKetik *#komplain ${order.id}* untuk komplain`;
  }
  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// KOMPLAIN
// ═══════════════════════════════════════════════════════════════════════════
async function handleKomplain(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;

  if (!args[0])
    return await send(sock, jid, '❌ Format: *#komplain <ID_ORDER> <pesan>*', msg);

  const orderId = args[0].toUpperCase();
  const pesan   = args.slice(1).join(' ') || '(tanpa pesan)';
  const order   = db.getOrder(orderId);

  if (!order)
    return await send(sock, jid, `❌ Order \`${orderId}\` tidak ditemukan.`, msg);
  if (order.buyerJid !== buyerJid)
    return await send(sock, jid, '❌ Kamu tidak punya akses ke order ini.', msg);

  const phone = buyerJid.replace('@s.whatsapp.net', '');
  await sendToAdmin(
    `⚠️ *KOMPLAIN PELANGGAN*\n\n` +
    `👤 WA   : ${phone}\n` +
    `📦 Order: ${orderId}\n` +
    `🛒 Produk: ${order.productName}\n` +
    `💰 Total : ${formatRupiah(order.amount)}\n` +
    `📝 Pesan : ${pesan}\n` +
    `📋 Status: ${orderStatusText(order.status)}`
  );
  await send(sock, jid,
    `✅ Komplain order *${orderId}* telah dikirim ke admin.\nKami akan segera menghubungimu.`, msg);
}

module.exports = {
  handleMenu, handlePricelist, handleSearch,
  handleBuy, handleBuyState,
  handleOrderHistory, handleCheckOrder, handleKomplain,
  PAY_MAP
};
