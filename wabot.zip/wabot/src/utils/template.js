const moment = require('moment');
require('moment/locale/id');
moment.locale('id');

// ── Header cantik ──────────────────────────────────────────────────────────
function header(sock) {
  const now  = moment();
  const time = now.format('HH:mm');
  const date = now.format('dddd, DD MMMM YYYY');
  const user = sock?.user?.id?.split(':')[0] || '';
  return (
    `. ° "랜" ⊹ . ᶥ ‹🩰›  ֪  𝗁𝖾𝗅𝗅𝗈\n` +
    `╭ ┈ 𝖾𝗎' 𝖻𝖾𝖺𝗎꯭𝗍𝗂𝖿𝗎𝗅'𝗌 𝖼𝖺𝗍𝖺𝗅𝗈𝗀𝗎𝖾\n` +
    `╰  " 🩰 "  ─── ${process.env.STORE_NAME || 'cassie store'}\n` +
    `│ ֪   𝗍𝗂𝗆𝖾  ⦂ ${time}\n` +
    `│ ֪   𝖽𝖺𝗍𝖾  ⦂ ${date}\n` +
    `╰────────────────╸🛒`
  );
}

// ── Header untuk pesan pesanan / invoice ──────────────────────────────────
function orderHeader(title) {
  return (
    `╭ ┈ 🩰 ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈\n` +
    `│  *${title}*\n` +
    `╰────────────────╸`
  );
}

// ── Divider tipis ──────────────────────────────────────────────────────────
const LINE = `┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄`;

module.exports = { header, orderHeader, LINE };
