let _sock = null;

function setSock(sock) {
  _sock = sock;
}

async function sendText(jid, text) {
  if (!_sock) return;
  await _sock.sendMessage(jid, { text });
}

async function sendReply(msg, text) {
  if (!_sock) return;
  await _sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });
}

async function sendToAdmin(text) {
  if (!_sock) return;
  const adminNumbers = (process.env.ADMIN_NUMBERS || process.env.OWNER_NUMBER || '').split(',').map(n => n.trim());
  for (const num of adminNumbers) {
    if (num) {
      const jid = num + '@s.whatsapp.net';
      await _sock.sendMessage(jid, { text });
    }
  }
}

async function notifyAdminNewOrder(order) {
  const { formatRupiah, formatDate, orderStatusText } = require('./helper');
  const text = `🔔 *PESANAN BARU*\n\n` +
    `📦 Order ID: ${order.id}\n` +
    `👤 Pembeli: ${order.buyerName || order.buyerJid}\n` +
    `📞 No WA: ${order.buyerJid.replace('@s.whatsapp.net', '')}\n` +
    `🛒 Produk: ${order.productName}\n` +
    `💰 Total: ${formatRupiah(order.amount)}\n` +
    `📅 Waktu: ${formatDate(order.createdAt)}\n` +
    `📋 Status: ${orderStatusText(order.status)}\n` +
    (order.productType === 'manual' ? `\n⚠️ *Produk Manual - Perlu konfirmasi manual!*` : '');
  await sendToAdmin(text);
}

async function notifyAdminPaymentConfirmed(order) {
  const { formatRupiah, formatDate } = require('./helper');
  const text = `💳 *PEMBAYARAN BERHASIL*\n\n` +
    `📦 Order ID: ${order.id}\n` +
    `👤 Pembeli: ${order.buyerName || order.buyerJid}\n` +
    `📞 No WA: ${order.buyerJid.replace('@s.whatsapp.net', '')}\n` +
    `🛒 Produk: ${order.productName}\n` +
    `💰 Total: ${formatRupiah(order.amount)}\n` +
    `📅 Waktu: ${formatDate(Date.now())}\n` +
    (order.productType === 'manual'
      ? `\n⚠️ *Produk Manual!*\n✏️ Balas dengan:\n*!selesai ${order.id}* untuk konfirmasi sukses\n*!gagal ${order.id} <alasan>* untuk konfirmasi gagal`
      : `\n🤖 Produk diproses otomatis via Digiflazz`);
  await sendToAdmin(text);
}

module.exports = { setSock, sendText, sendReply, sendToAdmin, notifyAdminNewOrder, notifyAdminPaymentConfirmed };
