const moment = require('moment');

function formatRupiah(amount) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
}

function formatDate(timestamp) {
  return moment(timestamp).format('DD/MM/YYYY HH:mm');
}

function generateOrderId(prefix = 'ORD') {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `${prefix}-${ts}-${rand}`;
}

function parseCommand(message, prefixes = ['!', '.', '#']) {
  const text = message.trim();
  for (const prefix of prefixes) {
    if (text.startsWith(prefix)) {
      const withoutPrefix = text.slice(prefix.length).trim();
      const parts = withoutPrefix.split(/\s+/);
      const cmd = parts[0].toLowerCase();
      const args = parts.slice(1);
      return { prefix, cmd, args, fullText: withoutPrefix };
    }
  }
  return null;
}

function isAdmin(jid, sock) {
  const adminNumbers = (process.env.ADMIN_NUMBERS || process.env.OWNER_NUMBER || '').split(',').map(n => n.trim());
  const phone = jid.replace('@s.whatsapp.net', '');
  return adminNumbers.includes(phone);
}

function isOwner(jid) {
  const ownerNumber = (process.env.OWNER_NUMBER || '').trim();
  const phone = jid.replace('@s.whatsapp.net', '');
  return phone === ownerNumber;
}

function sanitizeJid(jid) {
  return jid.includes('@') ? jid : jid + '@s.whatsapp.net';
}

function orderStatusEmoji(status) {
  const map = {
    pending_payment: '⏳',
    paid: '💰',
    processing: '🔄',
    success: '✅',
    failed: '❌',
    refunded: '↩️',
    cancelled: '🚫',
    pending_admin: '👨‍💼'
  };
  return map[status] || '❓';
}

function orderStatusText(status) {
  const map = {
    pending_payment: 'Menunggu Pembayaran',
    paid: 'Sudah Dibayar',
    processing: 'Sedang Diproses',
    success: 'Berhasil',
    failed: 'Gagal',
    refunded: 'Dikembalikan',
    cancelled: 'Dibatalkan',
    pending_admin: 'Menunggu Konfirmasi Admin'
  };
  return map[status] || status;
}

function chunkArray(arr, size) {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
}

module.exports = { formatRupiah, formatDate, generateOrderId, parseCommand, isAdmin, isOwner, sanitizeJid, orderStatusEmoji, orderStatusText, chunkArray };
