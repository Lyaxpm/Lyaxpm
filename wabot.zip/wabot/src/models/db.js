const fs = require('fs');
const path = require('path');

const DB_PATH = process.env.DB_PATH || './data/db.json';

const defaultDB = {
  users: {},
  products: {}, // manual products
  digiflazzProducts: {}, // cached from digiflazz
  orders: {},
  settings: {
    profitMargin: parseFloat(process.env.DEFAULT_PROFIT_MARGIN) || 10,
    paymentMethods: [],
    welcomeMessage: 'Selamat datang di Toko Digital kami! 🛒',
    maintenanceMode: false
  },
  bannedUsers: []
};

function loadDB() {
  try {
    const dir = path.dirname(DB_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify(defaultDB, null, 2));
      return defaultDB;
    }
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    const db = JSON.parse(raw);
    // Merge with defaults
    return {
      ...defaultDB,
      ...db,
      settings: { ...defaultDB.settings, ...(db.settings || {}) }
    };
  } catch (e) {
    console.error('DB load error:', e);
    return defaultDB;
  }
}

function saveDB(db) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
  } catch (e) {
    console.error('DB save error:', e);
  }
}

// In-memory DB with auto-save
let _db = loadDB();

const db = {
  get() { return _db; },
  save() { saveDB(_db); },
  reload() { _db = loadDB(); return _db; },

  // Users
  getUser(jid) {
    if (!_db.users[jid]) {
      _db.users[jid] = { jid, name: '', joinedAt: Date.now(), totalOrders: 0, totalSpent: 0 };
    }
    return _db.users[jid];
  },
  updateUser(jid, data) {
    _db.users[jid] = { ..._db.getUser(jid), ...data };
    saveDB(_db);
  },
  isBanned(jid) { return _db.bannedUsers.includes(jid); },
  banUser(jid) {
    if (!_db.bannedUsers.includes(jid)) _db.bannedUsers.push(jid);
    saveDB(_db);
  },
  unbanUser(jid) {
    _db.bannedUsers = _db.bannedUsers.filter(u => u !== jid);
    saveDB(_db);
  },

  // Products (manual)
  getProducts() { return _db.products; },
  getProduct(id) { return _db.products[id]; },
  addProduct(id, data) {
    _db.products[id] = { id, ...data, createdAt: Date.now() };
    saveDB(_db);
  },
  updateProduct(id, data) {
    _db.products[id] = { ..._db.products[id], ...data, updatedAt: Date.now() };
    saveDB(_db);
  },
  deleteProduct(id) {
    delete _db.products[id];
    saveDB(_db);
  },

  // Digiflazz Products Cache
  getDigiProducts() { return _db.digiflazzProducts; },
  setDigiProducts(products) {
    _db.digiflazzProducts = products;
    _db.digiflazzLastUpdate = Date.now();
    saveDB(_db);
  },

  // Orders
  getOrders() { return _db.orders; },
  getOrder(id) { return _db.orders[id]; },
  createOrder(id, data) {
    _db.orders[id] = { id, ...data, createdAt: Date.now(), status: 'pending_payment' };
    saveDB(_db);
    return _db.orders[id];
  },
  updateOrder(id, data) {
    _db.orders[id] = { ..._db.orders[id], ...data, updatedAt: Date.now() };
    saveDB(_db);
    return _db.orders[id];
  },
  getUserOrders(jid) {
    return Object.values(_db.orders).filter(o => o.buyerJid === jid);
  },

  // Settings
  getSettings() { return _db.settings; },
  updateSettings(data) {
    _db.settings = { ..._db.settings, ...data };
    saveDB(_db);
  },
  getProfitMargin() { return _db.settings.profitMargin || 10; }
};

// Fix: getUser references db not _db
db.getUser = function(jid) {
  if (!_db.users[jid]) {
    _db.users[jid] = { jid, name: '', joinedAt: Date.now(), totalOrders: 0, totalSpent: 0 };
  }
  return _db.users[jid];
};

module.exports = db;
