const axios = require('axios');
const crypto = require('crypto');
const db = require('../models/db');

const BASE_URL = process.env.DIGIFLAZZ_BASE_URL || 'https://api.digiflazz.com/v1';
const USERNAME = process.env.DIGIFLAZZ_USERNAME;
const API_KEY = process.env.DIGIFLAZZ_API_KEY;

function sign(data) {
  return crypto.createHash('md5').update(data).digest('hex');
}

async function getBalance() {
  try {
    const sign_str = sign(USERNAME + API_KEY + 'depo');
    const { data } = await axios.post(`${BASE_URL}/cek-saldo`, {
      cmd: 'deposit',
      username: USERNAME,
      sign: sign_str
    });
    return data.data;
  } catch (e) {
    console.error('Digiflazz getBalance error:', e.message);
    throw e;
  }
}

async function getPricelist(type = 'prepaid', category = '') {
  try {
    const sign_str = sign(USERNAME + API_KEY + 'pricelist');
    const payload = {
      cmd: 'prepaid',
      username: USERNAME,
      sign: sign_str
    };
    if (type === 'pasca') payload.cmd = 'pasca';
    const { data } = await axios.post(`${BASE_URL}/price-list`, payload);
    let products = data.data || [];
    if (category) products = products.filter(p => p.category?.toLowerCase().includes(category.toLowerCase()));
    return products;
  } catch (e) {
    console.error('Digiflazz getPricelist error:', e.message);
    throw e;
  }
}

async function refreshPricelist() {
  try {
    const products = await getPricelist('prepaid');
    const pasca = await getPricelist('pasca');
    const all = [...products, ...pasca];
    const margin = db.getProfitMargin();
    const mapped = {};
    all.forEach(p => {
      const sellPrice = Math.ceil(p.price * (1 + margin / 100) / 100) * 100;
      mapped[p.buyer_sku_code] = {
        sku: p.buyer_sku_code,
        name: p.product_name,
        category: p.category,
        brand: p.brand,
        type: p.type,
        seller_name: p.seller_name,
        buyerPrice: p.price,
        sellPrice,
        description: p.desc,
        stock: p.buyer_product_status ? 'available' : 'empty',
        startCutOff: p.start_cut_off,
        endCutOff: p.end_cut_off
      };
    });
    db.setDigiProducts(mapped);
    return mapped;
  } catch (e) {
    console.error('refreshPricelist error:', e.message);
    throw e;
  }
}

async function topup(refId, buyerSkuCode, customerNo) {
  try {
    const sign_str = sign(USERNAME + API_KEY + refId);
    const { data } = await axios.post(`${BASE_URL}/transaction`, {
      username: USERNAME,
      buyer_sku_code: buyerSkuCode,
      customer_no: customerNo,
      ref_id: refId,
      sign: sign_str,
      testing: false
    });
    return data.data;
  } catch (e) {
    console.error('Digiflazz topup error:', e.message);
    throw e;
  }
}

function verifyWebhook(body, signature) {
  const secret = process.env.DIGIFLAZZ_WEBHOOK_SECRET || API_KEY;
  const hash = crypto.createHmac('sha1', secret).update(JSON.stringify(body)).digest('hex');
  return hash === signature;
}

module.exports = { getBalance, getPricelist, refreshPricelist, topup, verifyWebhook };
