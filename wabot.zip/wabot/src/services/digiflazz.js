const axios = require('axios');
const crypto = require('crypto');
const db = require('../models/db');

const BASE_URL = process.env.DIGIFLAZZ_BASE_URL || 'https://api.digiflazz.com/v1';
const USERNAME = process.env.DIGIFLAZZ_USERNAME;
const API_KEY = process.env.DIGIFLAZZ_API_KEY;

function sign(data) {
  return crypto.createHash('md5').update(data).digest('hex');
}

async function getBalance() {
  try {
    const sign_str = sign(USERNAME + API_KEY + 'depo');
    const { data } = await axios.post(`${BASE_URL}/cek-saldo`, {
      cmd: 'deposit',
      username: USERNAME,
      sign: sign_str
    });
    return data.data;
  } catch (e) {
    console.error('Digiflazz getBalance error:', e.message);
    throw e;
  }
}

async function getPricelist(type = 'prepaid', category = '') {
  try {
    const sign_str = sign(USERNAME + API_KEY + 'pricelist');
    const payload = {
      cmd: 'prepaid',
      username: USERNAME,
      sign: sign_str
    };
    if (type === 'pasca') payload.cmd = 'pasca';
    const { data } = await axios.post(`${BASE_URL}/price-list`, payload);
    let products = data.data || [];
    if (category) products = products.filter(p => p.category?.toLowerCase().includes(category.toLowerCase()));
    return products;
  } catch (e) {
    console.error('Digiflazz getPricelist error:', e.message);
    throw e;
  }
}

async function refreshPricelist() {
  try {
    const products = await getPricelist('prepaid');
    const pasca = await getPricelist('pasca');
    const all = [...products, ...pasca];
    const margin = db.getProfitMargin();
    const mapped = {};
    all.forEach(p => {
      const sellPrice = Math.ceil(p.price * (1 + margin / 100) / 100) * 100;
      mapped[p.buyer_sku_code] = {
        sku: p.buyer_sku_code,
        name: p.product_name,
        category: p.category,
        brand: p.brand,
        type: p.type,
        seller_name: p.seller_name,
        buyerPrice: p.price,
        sellPrice,
        description: p.desc,
        stock: p.buyer_product_status ? 'available' : 'empty',
        startCutOff: p.start_cut_off,
        endCutOff: p.end_cut_off
      };
    });
    db.setDigiProducts(mapped);
    return mapped;
  } catch (e) {
    console.error('refreshPricelist error:', e.message);
    throw e;
  }
}

async function topup(refId, buyerSkuCode, customerNo) {
  try {
    const sign_str = sign(USERNAME + API_KEY + refId);
    const { data } = await axios.post(`${BASE_URL}/transaction`, {
      username: USERNAME,
      buyer_sku_code: buyerSkuCode,
      customer_no: customerNo,
      ref_id: refId,
      sign: sign_str,
      testing: false
    });
    return data.data;
  } catch (e) {
    console.error('Digiflazz topup error:', e.message);
    throw e;
  }
}

/**
 * Ambil semua layanan dari Digiflazz dan simpan ke digiProducts cache.
 * Bisa filter berdasarkan kategori, brand, atau type.
 * @param {object} opts - { category, brand, type, onlyAvailable }
 * @returns {{ imported, skipped, total, categories }}
 */
async function importServicesFromDigiflazz(opts = {}) {
  const { category, brand, type, onlyAvailable = false } = opts;

  const prepaid = await getPricelist('prepaid');
  const pasca   = await getPricelist('pasca');
  let all = [...prepaid, ...pasca];

  // Filter opsional
  if (category)      all = all.filter(p => p.category?.toLowerCase().includes(category.toLowerCase()));
  if (brand)         all = all.filter(p => p.brand?.toLowerCase().includes(brand.toLowerCase()));
  if (type)          all = all.filter(p => p.type?.toLowerCase().includes(type.toLowerCase()));
  if (onlyAvailable) all = all.filter(p => p.buyer_product_status === true);

  const margin = db.getProfitMargin();
  const existing = db.getDigiProducts();
  let imported = 0;
  let skipped  = 0;
  const categorySet = new Set();

  all.forEach(p => {
    const sku = p.buyer_sku_code;
    const sellPrice = Math.ceil(p.price * (1 + margin / 100) / 100) * 100;
    categorySet.add(p.category || 'Lainnya');

    if (existing[sku]) {
      // Sudah ada — update harga & stok saja, pertahankan custom sellPrice jika ada
      existing[sku] = {
        ...existing[sku],
        name:       p.product_name,
        category:   p.category,
        brand:      p.brand,
        type:       p.type,
        buyerPrice: p.price,
        // Jika admin belum custom harga, pakai kalkulasi margin
        sellPrice:  existing[sku]._customPrice ? existing[sku].sellPrice : sellPrice,
        stock:      p.buyer_product_status ? 'available' : 'empty',
        startCutOff: p.start_cut_off,
        endCutOff:   p.end_cut_off,
        description: p.desc,
        updatedAt:   Date.now()
      };
      skipped++;
    } else {
      existing[sku] = {
        sku,
        name:        p.product_name,
        category:    p.category,
        brand:       p.brand,
        type:        p.type,
        seller_name: p.seller_name,
        buyerPrice:  p.price,
        sellPrice,
        description: p.desc,
        stock:       p.buyer_product_status ? 'available' : 'empty',
        startCutOff: p.start_cut_off,
        endCutOff:   p.end_cut_off,
        _customPrice: false,
        importedAt:  Date.now()
      };
      imported++;
    }
  });

  db.setDigiProducts(existing);

  return {
    total:      all.length,
    imported,
    skipped,
    categories: [...categorySet].sort()
  };
}

function verifyWebhook(body, signature) {
  const secret = process.env.DIGIFLAZZ_WEBHOOK_SECRET || API_KEY;
  const hash = crypto.createHmac('sha1', secret).update(JSON.stringify(body)).digest('hex');
  return hash === signature;
}

module.exports = { getBalance, getPricelist, refreshPricelist, importServicesFromDigiflazz, topup, verifyWebhook };
