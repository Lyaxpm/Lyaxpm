const axios  = require('axios');
const crypto = require('crypto');
const db     = require('../models/db');

const BASE_URL = process.env.DIGIFLAZZ_BASE_URL || 'https://api.digiflazz.com/v1';
const USERNAME = process.env.DIGIFLAZZ_USERNAME;
const API_KEY  = process.env.DIGIFLAZZ_API_KEY;

function sign(data) {
  return crypto.createHash('md5').update(data).digest('hex');
}

// Harga dari Digiflazz: prepaid pakai p.price, pasca pakai p.admin_fee atau p.price
// Beberapa produk pasca price = 0 dan harga asli di field lain
function resolvePrice(p) {
  const raw = Number(p.price) || Number(p.buyer_price) || 0;
  return raw;
}

// Produk butuh input apa? Deteksi otomatis dari kategori/brand/nama
function detectInputType(p) {
  const cat   = (p.category || '').toLowerCase();
  const brand = (p.brand || '').toLowerCase();
  const name  = (p.product_name || '').toLowerCase();

  // Game yang butuh ID + Server
  if (brand.includes('mobile legend') || name.includes('mobile legend')) return 'game_id_server';
  if (brand.includes('genshin') || name.includes('genshin'))             return 'game_id_server';
  if (brand.includes('honkai') || name.includes('honkai'))               return 'game_id_server';
  if (brand.includes('clash of clan') || name.includes('clash of clan')) return 'game_id_server';
  if (brand.includes('call of duty') || name.includes('call of duty'))   return 'game_id_server';

  // Game cukup ID saja
  if (cat.includes('game') || cat.includes('voucher'))                   return 'game_id';
  if (brand.includes('free fire') || name.includes('free fire'))         return 'game_id';
  if (brand.includes('pubg') || name.includes('pubg'))                   return 'game_id';

  // E-wallet / dompet digital
  if (cat.includes('e-wallet') || cat.includes('ewallet') ||
      cat.includes('dompet') || brand.includes('gopay') ||
      brand.includes('ovo') || brand.includes('dana') ||
      brand.includes('shopeepay') || brand.includes('linkaja'))          return 'phone';

  // PLN / Listrik - butuh nomor meter/ID pelanggan
  if (brand.includes('pln') || cat.includes('listrik') ||
      cat.includes('token') || name.includes('token listrik'))           return 'pln';

  // Pascabayar (tagihan) - nomor ID pelanggan
  if (cat.includes('pasca') || cat.includes('tagihan') ||
      cat.includes('pascabayar'))                                        return 'customer_id';

  // Pulsa / Paket Data - nomor HP
  if (cat.includes('pulsa') || cat.includes('paket data') ||
      cat.includes('data') || cat.includes('telepon'))                   return 'phone';

  // Default nomor HP
  return 'phone';
}

async function getBalance() {
  try {
    const s = sign(USERNAME + API_KEY + 'depo');
    const { data } = await axios.post(`${BASE_URL}/cek-saldo`, {
      cmd: 'deposit', username: USERNAME, sign: s
    });
    return data.data;
  } catch (e) {
    console.error('Digiflazz getBalance error:', e.message);
    throw e;
  }
}

async function getPricelist(type = 'prepaid') {
  try {
    const s = sign(USERNAME + API_KEY + 'pricelist');
    const { data } = await axios.post(`${BASE_URL}/price-list`, {
      cmd: type === 'pasca' ? 'pasca' : 'prepaid',
      username: USERNAME, sign: s
    });
    return data.data || [];
  } catch (e) {
    console.error('Digiflazz getPricelist error:', e.message);
    throw e;
  }
}

function mapProduct(p, margin, existing) {
  const sku       = p.buyer_sku_code;
  const buyPrice  = resolvePrice(p);
  const sellPrice = existing?._customPrice
    ? existing.sellPrice
    : Math.ceil(buyPrice * (1 + margin / 100) / 100) * 100;

  return {
    sku,
    name:        p.product_name,
    category:    p.category,
    brand:       p.brand,
    type:        p.type,
    seller_name: p.seller_name,
    buyerPrice:  buyPrice,
    sellPrice,
    description: p.desc || '',
    stock:       p.buyer_product_status ? 'available' : 'empty',
    startCutOff: p.start_cut_off,
    endCutOff:   p.end_cut_off,
    inputType:   detectInputType(p),  // ← tipe input customer
    _customPrice: existing?._customPrice || false,
    importedAt:  existing?.importedAt || Date.now(),
    updatedAt:   Date.now()
  };
}

async function refreshPricelist() {
  const prepaid = await getPricelist('prepaid');
  const pasca   = await getPricelist('pasca');
  const margin  = db.getProfitMargin();
  const existing = db.getDigiProducts();
  const mapped  = {};

  [...prepaid, ...pasca].forEach(p => {
    const sku = p.buyer_sku_code;
    mapped[sku] = mapProduct(p, margin, existing[sku]);
  });

  db.setDigiProducts(mapped);
  return mapped;
}

async function importServicesFromDigiflazz(opts = {}) {
  const { category, brand, type, onlyAvailable = false } = opts;

  let all = [...await getPricelist('prepaid'), ...await getPricelist('pasca')];
  if (category)      all = all.filter(p => p.category?.toLowerCase().includes(category.toLowerCase()));
  if (brand)         all = all.filter(p => p.brand?.toLowerCase().includes(brand.toLowerCase()));
  if (type)          all = all.filter(p => p.type?.toLowerCase().includes(type.toLowerCase()));
  if (onlyAvailable) all = all.filter(p => p.buyer_product_status === true);

  const margin   = db.getProfitMargin();
  const existing = db.getDigiProducts();
  let imported = 0, skipped = 0;
  const categorySet = new Set();

  all.forEach(p => {
    const sku = p.buyer_sku_code;
    categorySet.add(p.category || 'Lainnya');
    const isNew = !existing[sku];
    existing[sku] = mapProduct(p, margin, existing[sku]);
    isNew ? imported++ : skipped++;
  });

  db.setDigiProducts(existing);
  return { total: all.length, imported, skipped, categories: [...categorySet].sort() };
}

async function topup(refId, buyerSkuCode, customerNo) {
  try {
    const s = sign(USERNAME + API_KEY + refId);
    const { data } = await axios.post(`${BASE_URL}/transaction`, {
      username: USERNAME, buyer_sku_code: buyerSkuCode,
      customer_no: customerNo, ref_id: refId, sign: s, testing: false
    });
    return data.data;
  } catch (e) {
    console.error('Digiflazz topup error:', e.message);
    throw e;
  }
}

function verifyWebhook(body, signature) {
  const secret = process.env.DIGIFLAZZ_WEBHOOK_SECRET || API_KEY;
  return crypto.createHmac('sha1', secret).update(JSON.stringify(body)).digest('hex') === signature;
}

module.exports = {
  getBalance, getPricelist, refreshPricelist,
  importServicesFromDigiflazz, topup, verifyWebhook, detectInputType
};
