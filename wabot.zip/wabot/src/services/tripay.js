const axios = require('axios');
const crypto = require('crypto');

const BASE_URL = process.env.TRIPAY_BASE_URL || 'https://tripay.co.id/api';
const API_KEY = process.env.TRIPAY_API_KEY;
const PRIVATE_KEY = process.env.TRIPAY_PRIVATE_KEY;
const MERCHANT_CODE = process.env.TRIPAY_MERCHANT_CODE;
const WEBHOOK_BASE = process.env.WEBHOOK_BASE_URL || 'http://localhost:3000';

const headers = {
  Authorization: `Bearer ${API_KEY}`
};

function signTransaction(merchantRef, amount) {
  return crypto.createHmac('sha256', PRIVATE_KEY)
    .update(MERCHANT_CODE + merchantRef + amount)
    .digest('hex');
}

async function getPaymentChannels() {
  try {
    const { data } = await axios.get(`${BASE_URL}/merchant/payment-channel`, { headers });
    return data.data;
  } catch (e) {
    console.error('Tripay getPaymentChannels error:', e.message);
    throw e;
  }
}

async function createTransaction({ orderId, amount, customerName, customerPhone, customerEmail, productName, qty = 1, paymentMethod = 'QRIS' }) {
  try {
    const signature = signTransaction(orderId, amount);
    const expiry = Math.floor(Date.now() / 1000) + (24 * 60 * 60); // 24 jam
    const payload = {
      method: paymentMethod,
      merchant_ref: orderId,
      amount,
      customer_name: customerName || 'Pelanggan',
      customer_email: customerEmail || `${customerPhone}@wa.bot`,
      customer_phone: customerPhone,
      order_items: [
        {
          sku: orderId,
          name: productName,
          price: amount,
          quantity: qty
        }
      ],
      callback_url: `${WEBHOOK_BASE}/webhook/tripay`,
      return_url: `${WEBHOOK_BASE}/order/${orderId}`,
      expired_time: expiry,
      signature
    };
    const { data } = await axios.post(`${BASE_URL}/transaction/create`, payload, { headers });
    if (!data.success) throw new Error(data.message);
    return data.data;
  } catch (e) {
    console.error('Tripay createTransaction error:', e.response?.data || e.message);
    throw new Error(e.response?.data?.message || e.message);
  }
}

async function getTransactionDetail(reference) {
  try {
    const { data } = await axios.get(`${BASE_URL}/transaction/detail`, {
      headers,
      params: { reference }
    });
    return data.data;
  } catch (e) {
    console.error('Tripay getTransactionDetail error:', e.message);
    throw e;
  }
}

function verifyCallback(body, signature) {
  const hash = crypto.createHmac('sha256', PRIVATE_KEY)
    .update(JSON.stringify(body))
    .digest('hex');
  return hash === signature;
}

module.exports = { getPaymentChannels, createTransaction, getTransactionDetail, verifyCallback };
