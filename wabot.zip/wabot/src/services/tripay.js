const axios = require('axios');
const crypto = require('crypto');

const BASE_URL      = process.env.TRIPAY_BASE_URL    || 'https://tripay.co.id/api';
const API_KEY       = process.env.TRIPAY_API_KEY      || '';
const PRIVATE_KEY   = process.env.TRIPAY_PRIVATE_KEY  || '';
const MERCHANT_CODE = process.env.TRIPAY_MERCHANT_CODE || '';
const WEBHOOK_BASE  = process.env.WEBHOOK_BASE_URL    || 'http://localhost:3000';

const headers = () => ({ Authorization: `Bearer ${API_KEY}` });

function signTransaction(merchantRef, amount) {
  return crypto.createHmac('sha256', PRIVATE_KEY)
    .update(MERCHANT_CODE + merchantRef + amount)
    .digest('hex');
}

// Ambil pesan error Tripay dari berbagai format response
function extractError(e) {
  const d = e.response?.data;
  if (!d) return e.message || 'Unknown error';

  // Format: { success: false, message: "..." }
  if (d.message) return d.message;

  // Format: { errors: { field: ["msg"] } }
  if (d.errors) {
    const msgs = [];
    Object.entries(d.errors).forEach(([k, v]) => {
      msgs.push(`${k}: ${Array.isArray(v) ? v.join(', ') : v}`);
    });
    return msgs.join(' | ');
  }

  // Format: string langsung
  if (typeof d === 'string') return d;

  return JSON.stringify(d);
}

async function getPaymentChannels() {
  try {
    const { data } = await axios.get(`${BASE_URL}/merchant/payment-channel`, { headers: headers() });
    return data.data || [];
  } catch (e) {
    console.error('[Tripay] getPaymentChannels:', e.message);
    throw new Error(`Gagal ambil channel: ${extractError(e)}`);
  }
}

async function createTransaction({
  orderId, amount, customerName, customerPhone,
  customerEmail, productName, qty = 1, paymentMethod = 'QRIS'
}) {
  // Validasi env dulu
  if (!API_KEY)       throw new Error('TRIPAY_API_KEY belum diisi di .env');
  if (!PRIVATE_KEY)   throw new Error('TRIPAY_PRIVATE_KEY belum diisi di .env');
  if (!MERCHANT_CODE) throw new Error('TRIPAY_MERCHANT_CODE belum diisi di .env');

  const signature = signTransaction(orderId, amount);
  const expiry    = Math.floor(Date.now() / 1000) + (24 * 60 * 60);
  const phone     = (customerPhone || '').replace(/\D/g, '');

  const payload = {
    method:        paymentMethod,
    merchant_ref:  orderId,
    amount,
    customer_name:  customerName  || 'Pelanggan',
    customer_email: customerEmail || `${phone}@customer.id`,
    customer_phone: phone,
    order_items: [{
      sku:      orderId,
      name:     productName.substring(0, 50), // max 50 char
      price:    amount,
      quantity: qty
    }],
    callback_url:  `${WEBHOOK_BASE}/webhook/tripay`,
    return_url:    `${WEBHOOK_BASE}/order/${orderId}`,
    expired_time:  expiry,
    signature
  };

  console.log('[Tripay] createTransaction payload:', JSON.stringify({ ...payload, signature: '***' }));

  try {
    const { data } = await axios.post(
      `${BASE_URL}/transaction/create`,
      payload,
      { headers: headers(), timeout: 15000 }
    );

    console.log('[Tripay] response:', JSON.stringify(data));

    if (!data.success) {
      throw new Error(data.message || 'Tripay menolak transaksi (tanpa pesan error)');
    }
    return data.data;
  } catch (e) {
    if (e.response) {
      // HTTP error dari Tripay
      const errMsg = extractError(e);
      console.error('[Tripay] HTTP error', e.response.status, errMsg);
      throw new Error(`Tripay error (${e.response.status}): ${errMsg}`);
    } else if (e.request) {
      // Tidak dapat respons
      console.error('[Tripay] No response:', e.message);
      throw new Error('Tidak bisa terhubung ke Tripay. Cek koneksi server.');
    } else {
      // Error lain (validasi, dsb)
      throw e;
    }
  }
}

async function getTransactionDetail(reference) {
  try {
    const { data } = await axios.get(`${BASE_URL}/transaction/detail`, {
      headers: headers(),
      params: { reference },
      timeout: 10000
    });
    return data.data;
  } catch (e) {
    throw new Error(`Gagal cek transaksi: ${extractError(e)}`);
  }
}

function verifyCallback(body, signature) {
  const hash = crypto.createHmac('sha256', PRIVATE_KEY)
    .update(JSON.stringify(body))
    .digest('hex');
  return hash === signature;
}

module.exports = { getPaymentChannels, createTransaction, getTransactionDetail, verifyCallback };
