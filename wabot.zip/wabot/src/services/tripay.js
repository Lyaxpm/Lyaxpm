const axios = require('axios');
const crypto = require('crypto');

const BASE_URL      = process.env.TRIPAY_BASE_URL     || 'https://tripay.co.id/api';
const API_KEY       = process.env.TRIPAY_API_KEY       || '';
const PRIVATE_KEY   = process.env.TRIPAY_PRIVATE_KEY   || '';
const MERCHANT_CODE = process.env.TRIPAY_MERCHANT_CODE || '';
const WEBHOOK_BASE  = process.env.WEBHOOK_BASE_URL     || '';

function getHeaders() {
  return { Authorization: `Bearer ${API_KEY}` };
}

function signTransaction(merchantRef, amount) {
  return crypto.createHmac('sha256', PRIVATE_KEY)
    .update(MERCHANT_CODE + merchantRef + amount)
    .digest('hex');
}

function extractError(e) {
  const d = e.response?.data;
  if (!d) return e.message || 'Unknown error';
  if (typeof d === 'string') return d;
  if (d.message) return d.message;
  if (d.errors) {
    return Object.entries(d.errors)
      .map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(', ') : v}`)
      .join(' | ');
  }
  return JSON.stringify(d);
}

function validateEnv() {
  const missing = [];
  if (!API_KEY)       missing.push('TRIPAY_API_KEY');
  if (!PRIVATE_KEY)   missing.push('TRIPAY_PRIVATE_KEY');
  if (!MERCHANT_CODE) missing.push('TRIPAY_MERCHANT_CODE');
  if (missing.length) throw new Error(`Isi dulu di .env: ${missing.join(', ')}`);

  // Validasi WEBHOOK_BASE_URL — Tripay WAJIB URL yang bisa diakses publik
  if (!WEBHOOK_BASE || WEBHOOK_BASE.includes('yourdomain') || WEBHOOK_BASE.includes('localhost')) {
    console.warn('[Tripay] ⚠️  WEBHOOK_BASE_URL belum diset ke URL publik! Callback tidak akan diterima.');
  }
}

async function getPaymentChannels() {
  validateEnv();
  try {
    const { data } = await axios.get(`${BASE_URL}/merchant/payment-channel`, {
      headers: getHeaders(), timeout: 10000
    });
    return data.data || [];
  } catch (e) {
    throw new Error(`Gagal ambil channel: ${extractError(e)}`);
  }
}

async function createTransaction({
  orderId, amount, customerName, customerPhone,
  productName, paymentMethod = 'QRIS'
}) {
  validateEnv();

  // Callback & return URL — pakai WEBHOOK_BASE jika ada, fallback ke placeholder
  const cbBase = (WEBHOOK_BASE && !WEBHOOK_BASE.includes('yourdomain'))
    ? WEBHOOK_BASE.replace(/\/$/, '')
    : null;

  const callbackUrl = cbBase ? `${cbBase}/webhook/tripay` : '';
  const returnUrl   = cbBase ? `${cbBase}/order/${orderId}` : '';

  const signature = signTransaction(orderId, amount);
  const expiry    = Math.floor(Date.now() / 1000) + (24 * 60 * 60);
  const phone     = (customerPhone || '').replace(/\D/g, '');

  const payload = {
    method:         paymentMethod,
    merchant_ref:   orderId,
    amount,
    customer_name:  (customerName  || 'Pelanggan').substring(0, 50),
    customer_email: `${phone || 'customer'}@store.id`,
    customer_phone: phone || '08000000000',
    order_items: [{
      sku:      orderId,
      name:     productName.substring(0, 50),
      price:    amount,
      quantity: 1
    }],
    expired_time: expiry,
    signature
  };

  // Hanya tambahkan jika URL valid
  if (callbackUrl) payload.callback_url = callbackUrl;
  if (returnUrl)   payload.return_url   = returnUrl;

  console.log('[Tripay] Request →', paymentMethod, orderId, `Rp${amount}`);

  try {
    const { data } = await axios.post(
      `${BASE_URL}/transaction/create`,
      payload,
      { headers: getHeaders(), timeout: 20000 }
    );

    if (!data.success) {
      throw new Error(data.message || 'Tripay menolak transaksi');
    }

    console.log('[Tripay] ✅ Invoice dibuat:', data.data?.reference);
    return data.data;

  } catch (e) {
    if (e.response) {
      const msg = extractError(e);
      console.error('[Tripay] ❌ HTTP', e.response.status, msg);
      throw new Error(`Tripay (${e.response.status}): ${msg}`);
    } else if (e.request) {
      console.error('[Tripay] ❌ Tidak ada respons dari server Tripay');
      throw new Error(
        'Tidak bisa terhubung ke server Tripay.\n' +
        'Pastikan server punya koneksi internet dan Tripay tidak sedang maintenance.'
      );
    }
    throw e;
  }
}

async function getTransactionDetail(reference) {
  validateEnv();
  try {
    const { data } = await axios.get(`${BASE_URL}/transaction/detail`, {
      headers: getHeaders(),
      params: { reference },
      timeout: 10000
    });
    return data.data;
  } catch (e) {
    throw new Error(`Gagal cek transaksi: ${extractError(e)}`);
  }
}

function verifyCallback(body, signature) {
  const hash = crypto.createHmac('sha256', PRIVATE_KEY)
    .update(JSON.stringify(body))
    .digest('hex');
  return hash === signature;
}

module.exports = { getPaymentChannels, createTransaction, getTransactionDetail, verifyCallback };
