const { v4: uuidv4 } = require('uuid');
const db = require('../models/db');
const tripay = require('./tripay');
const digiflazz = require('./digiflazz');
const { generateOrderId, formatRupiah, orderStatusText, orderStatusEmoji } = require('../utils/helper');
const sender = require('../utils/sender');

async function createOrder({ buyerJid, buyerName, productId, productType, customerNo, paymentMethod }) {
  let product, amount, productName, skuCode;

  if (productType === 'manual') {
    product = db.getProduct(productId);
    if (!product) throw new Error('Produk tidak ditemukan');
    if (product.stock !== undefined && product.stock <= 0) throw new Error('Stok produk habis');
    amount = product.price;
    productName = product.name;
  } else {
    // digiflazz product
    const digiProducts = db.getDigiProducts();
    product = digiProducts[productId];
    if (!product) throw new Error('Produk tidak ditemukan');
    if (product.stock === 'empty') throw new Error('Produk sedang kosong');
    amount = product.sellPrice;
    productName = product.name;
    skuCode = product.sku;
  }

  const orderId = generateOrderId('ORD');
  const phone = buyerJid.replace('@s.whatsapp.net', '');

  // Create Tripay transaction
  let tripayData;
  try {
    tripayData = await tripay.createTransaction({
      orderId,
      amount,
      customerName: buyerName || 'Pelanggan',
      customerPhone: phone,
      productName,
      paymentMethod: paymentMethod || 'QRIS'
    });
  } catch (e) {
    throw new Error(`Gagal membuat pembayaran: ${e.message}`);
  }

  const order = db.createOrder(orderId, {
    id: orderId,
    buyerJid,
    buyerName,
    productId,
    productType,
    productName,
    skuCode,
    customerNo: customerNo || '',
    amount,
    paymentMethod: paymentMethod || 'QRIS',
    tripayReference: tripayData.reference,
    tripayPayUrl: tripayData.pay_url || tripayData.checkout_url,
    tripayQrUrl: tripayData.qr_url,
    tripayPayCode: tripayData.pay_code,
    tripayExpiredTime: tripayData.expired_time,
    status: 'pending_payment'
  });

  await sender.notifyAdminNewOrder(order);
  return order;
}

async function processDigiflazzOrder(order) {
  if (order.productType !== 'digiflazz') return;
  try {
    db.updateOrder(order.id, { status: 'processing' });
    const result = await digiflazz.topup(order.id, order.skuCode, order.customerNo);

    if (result.status === 'Sukses') {
      db.updateOrder(order.id, {
        status: 'success',
        digiflazzSn: result.sn,
        digiflazzMessage: result.message,
        processedAt: Date.now()
      });
      const updatedOrder = db.getOrder(order.id);
      // Update user stats
      const user = db.getUser(order.buyerJid);
      db.updateUser(order.buyerJid, {
        totalOrders: (user.totalOrders || 0) + 1,
        totalSpent: (user.totalSpent || 0) + order.amount
      });
      await notifyBuyerSuccess(updatedOrder);
    } else if (result.status === 'Gagal') {
      db.updateOrder(order.id, { status: 'failed', digiflazzMessage: result.message });
      await notifyBuyerFailed(db.getOrder(order.id), result.message);
    } else {
      // Pending - bisa dicek lagi nanti
      db.updateOrder(order.id, { status: 'processing', digiflazzMessage: result.message });
    }
  } catch (e) {
    console.error('processDigiflazzOrder error:', e.message);
    db.updateOrder(order.id, { status: 'failed', failReason: e.message });
    await notifyBuyerFailed(db.getOrder(order.id), e.message);
  }
}

async function onPaymentSuccess(reference) {
  // Find order by tripay reference
  const orders = db.getOrders();
  const order = Object.values(orders).find(o => o.tripayReference === reference);
  if (!order) { console.error('Order not found for reference:', reference); return; }
  if (order.status !== 'pending_payment') return; // Already processed

  db.updateOrder(order.id, { status: 'paid', paidAt: Date.now() });
  const updatedOrder = db.getOrder(order.id);

  await sender.notifyAdminPaymentConfirmed(updatedOrder);

  if (updatedOrder.productType === 'digiflazz') {
    await processDigiflazzOrder(updatedOrder);
  } else {
    // Manual product - tunggu admin konfirmasi
    db.updateOrder(order.id, { status: 'pending_admin' });
    await notifyBuyerPendingAdmin(updatedOrder);
  }
}

async function adminConfirmOrder(orderId, result, adminNote = '') {
  const order = db.getOrder(orderId);
  if (!order) throw new Error('Order tidak ditemukan');
  if (!['pending_admin', 'paid'].includes(order.status)) throw new Error('Status order tidak bisa dikonfirmasi');

  if (result === 'success') {
    db.updateOrder(orderId, { status: 'success', adminNote, processedAt: Date.now() });
    const user = db.getUser(order.buyerJid);
    db.updateUser(order.buyerJid, {
      totalOrders: (user.totalOrders || 0) + 1,
      totalSpent: (user.totalSpent || 0) + order.amount
    });
    await notifyBuyerSuccess(db.getOrder(orderId));
  } else {
    db.updateOrder(orderId, { status: 'failed', adminNote, failReason: adminNote });
    await notifyBuyerFailed(db.getOrder(orderId), adminNote || 'Pesanan gagal diproses');
  }
}

async function notifyBuyerSuccess(order) {
  const text = `✅ *PESANAN BERHASIL*\n\n` +
    `📦 Order ID: ${order.id}\n` +
    `🛒 Produk: ${order.productName}\n` +
    `💰 Total: ${formatRupiah(order.amount)}\n` +
    (order.customerNo ? `📱 No Tujuan: ${order.customerNo}\n` : '') +
    (order.digiflazzSn ? `🔑 SN/Token: ${order.digiflazzSn}\n` : '') +
    (order.adminNote ? `📝 Catatan: ${order.adminNote}\n` : '') +
    `\nTerima kasih telah berbelanja! 🙏`;
  await sender.sendText(order.buyerJid, text);
}

async function notifyBuyerFailed(order, reason) {
  const text = `❌ *PESANAN GAGAL*\n\n` +
    `📦 Order ID: ${order.id}\n` +
    `🛒 Produk: ${order.productName}\n` +
    `💰 Total: ${formatRupiah(order.amount)}\n` +
    `📝 Alasan: ${reason || 'Terjadi kesalahan'}\n\n` +
    `Mohon hubungi admin untuk bantuan lebih lanjut atau ketik *#komplain ${order.id}*`;
  await sender.sendText(order.buyerJid, text);
}

async function notifyBuyerPendingAdmin(order) {
  const text = `💰 *PEMBAYARAN DITERIMA*\n\n` +
    `📦 Order ID: ${order.id}\n` +
    `🛒 Produk: ${order.productName}\n` +
    `💰 Total: ${formatRupiah(order.amount)}\n\n` +
    `⏳ Pesanan Anda sedang diproses oleh admin.\nKami akan segera menginformasikan hasilnya.`;
  await sender.sendText(order.buyerJid, text);
}

module.exports = { createOrder, onPaymentSuccess, adminConfirmOrder, processDigiflazzOrder };
