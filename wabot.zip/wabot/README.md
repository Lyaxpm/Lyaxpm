# 🛒 Toko Digital WhatsApp Bot

Bot WhatsApp toko digital otomatis terintegrasi dengan **Digiflazz** (PPOB/topup) dan **Tripay** (payment gateway).

---

## ✨ Fitur Utama

- ✅ Login via **Pairing Code** (tanpa QR)
- ✅ Integrasi **Digiflazz** (pulsa, data, token listrik, dll)
- ✅ Integrasi **Tripay** payment gateway (QRIS, VA, e-wallet)
- ✅ Callback real-time pembayaran & status Digiflazz
- ✅ Harga otomatis + margin keuntungan yang bisa diatur
- ✅ Produk manual (tidak terhubung Digiflazz)
- ✅ Panel admin lengkap
- ✅ Multi-prefix: `!`, `.`, `#`
- ✅ Ban/unban user
- ✅ Broadcast ke semua user
- ✅ Notifikasi komplain ke admin

---

## 📋 Persyaratan

- Node.js v18+
- Akun Digiflazz (https://digiflazz.com)
- Akun Tripay (https://tripay.co.id)
- Domain/VPS dengan HTTPS untuk webhook

---

## 🚀 Instalasi

```bash
# 1. Clone/download project
cd wa-toko-digital-bot

# 2. Install dependencies
npm install

# 3. Copy dan isi .env
cp .env.example .env
nano .env

# 4. Jalankan bot
npm start
```

---

## ⚙️ Konfigurasi `.env`

```env
# Nomor admin (tanpa +, pisah koma jika lebih dari 1)
OWNER_NUMBER=6281234567890
ADMIN_NUMBERS=6281234567890,6289876543210

# Digiflazz
DIGIFLAZZ_USERNAME=username_kamu
DIGIFLAZZ_API_KEY=api_key_digiflazz

# Tripay
TRIPAY_API_KEY=api_key_tripay
TRIPAY_PRIVATE_KEY=private_key_tripay
TRIPAY_MERCHANT_CODE=kode_merchant

# Margin keuntungan default (%)
DEFAULT_PROFIT_MARGIN=10

# URL webhook (harus HTTPS + bisa diakses publik)
WEBHOOK_BASE_URL=https://yourdomain.com
WEBHOOK_PORT=3000
```

---

## 🔐 Login Bot (Pairing Code)

Saat pertama kali dijalankan:

1. Masukkan nomor WhatsApp bot saat diminta
2. Muncul **pairing code** 8 digit (contoh: `ABCD-1234`)
3. Buka WhatsApp > **Settings** > **Linked Devices** > **Link a Device**
4. Pilih **"Link with phone number instead"**
5. Masukkan kode pairing
6. Bot akan terhubung ✅

---

## 📡 Setup Webhook

Tambahkan URL webhook di:
- **Tripay**: Dashboard > Pengaturan > Callback URL → `https://yourdomain.com/webhook/tripay`
- **Digiflazz**: Dashboard > Pengaturan → `https://yourdomain.com/webhook/digiflazz`

---

## 💬 Perintah Bot

### Perintah User (semua bisa pakai prefix `!`, `.`, atau `#`)

| Perintah | Fungsi |
|----------|--------|
| `!menu` | Menu utama |
| `!pricelist` | Lihat semua produk |
| `!pricelist pulsa` | Filter berdasarkan kategori |
| `!cari xl 5rb` | Cari produk |
| `!beli XL5 08123456789` | Beli produk Digiflazz |
| `#buy XL5 08123456789` | Sama dengan !beli |
| `!belimanual JOKI-ML` | Beli produk manual |
| `!pesanan` | Riwayat pesanan |
| `!cekpesanan ORD-XXX` | Cek status pesanan |
| `#komplain ORD-XXX pesan` | Komplain ke admin |

### Perintah Admin

| Perintah | Fungsi |
|----------|--------|
| `!adminmenu` | Menu admin |
| `!addproduk ID harga nama` | Tambah produk manual |
| `!editproduk ID harga 75000` | Edit harga produk |
| `!hapusproduk ID` | Hapus produk |
| `!listproduk` | Daftar produk manual |
| `!pesananadmin` | Semua pesanan |
| `!selesai ORD-XXX catatan` | Konfirmasi pesanan sukses |
| `!gagal ORD-XXX alasan` | Konfirmasi pesanan gagal |
| `!ban 6281xxx` | Ban user |
| `!unban 6281xxx` | Unban user |
| `!setting margin 15` | Ubah margin ke 15% |
| `!setting maintenance on` | Aktifkan maintenance |
| `!refreshpricelist` | Update harga Digiflazz |
| `!saldo` | Cek saldo Digiflazz |
| `!broadcast pesan` | Kirim ke semua user |

---

## 🔄 Alur Pembelian

```
User → !beli SKU nomor
     → Pilih metode pembayaran
     → Konfirmasi
     → Bot buat invoice Tripay
     → User bayar
     → Tripay callback → Bot terima
     → [Digiflazz] Proses otomatis → Kirim SN ke user
     → [Manual] Admin konfirmasi → Bot kirim info ke user
```

---

## 📁 Struktur Project

```
wabot/
├── src/
│   ├── index.js              # Entry point + koneksi WA
│   ├── commands/
│   │   ├── userCommands.js   # Perintah user
│   │   └── adminCommands.js  # Perintah admin
│   ├── handlers/
│   │   ├── messageHandler.js # Router pesan
│   │   └── webhookServer.js  # Express webhook server
│   ├── services/
│   │   ├── digiflazz.js     # Digiflazz API
│   │   ├── tripay.js        # Tripay API
│   │   └── orderService.js  # Logic pesanan
│   ├── models/
│   │   └── db.js            # Database JSON
│   └── utils/
│       ├── helper.js        # Helper functions
│       └── sender.js        # WA message sender
├── data/                    # Database JSON (auto-created)
├── session/                 # Session WhatsApp (auto-created)
├── .env.example
├── package.json
└── README.md
```

---

## 🛡️ Keamanan

- Gunakan HTTPS untuk webhook
- Jangan share `.env` ke publik
- Session folder mengandung kredensial WA, jaga kerahasiaannya
- Backup folder `data/` secara berkala

---

## ❓ Troubleshooting

**Bot tidak connect:**
- Pastikan pairing code dimasukkan dalam 60 detik
- Hapus folder `session/` dan restart

**Webhook tidak diterima:**
- Pastikan URL bisa diakses dari internet (gunakan VPS/hosting)
- Pastikan port terbuka di firewall

**Pricelist kosong:**
- Jalankan `!refreshpricelist` di chat admin
- Cek kredensial Digiflazz di `.env`
