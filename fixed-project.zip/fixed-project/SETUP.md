# 🚀 PANDUAN SETUP PRODUCTION

## ✅ FILE YANG SUDAH DIFIX

| File | Perubahan |
|------|-----------|
| `src/contexts/AuthContext.tsx` | + agentRecord, workspaceOwnerId (agent support) |
| `src/pages/dashboard/WAConnection.tsx` | Real QR scan via GOWA (hapus simulasi) |
| `src/pages/admin/AdminLogin.tsx` | **BARU** - Login khusus admin |
| `src/pages/admin/AdminSettings.tsx` | Evolution API → GOWA API fields |
| `src/components/ProtectedRoute.tsx` | Admin route → redirect ke /admin/login |
| `src/App.tsx` | + route /admin/login |
| `supabase/functions/send-message/index.ts` | GOWA send + real agent name |
| `supabase/functions/gowa-create-instance/` | **BARU** - Init WA session |
| `supabase/functions/gowa-webhook/` | **BARU** - Terima pesan masuk WA |
| `supabase/functions/gowa-delete-instance/` | **BARU** - Disconnect WA |
| `supabase/functions/gowa-qr/` | **BARU** - Polling QR code |
| `supabase/migrations/20260307000001_gowa_and_fixes.sql` | GOWA settings + agents + channel_configs |
| `docker-compose.gowa.yml` | **BARU** - Setup GOWA di VPS |
| `.gitignore` | + .env (fix security) |

---

## 🛠️ LANGKAH SETUP DI VPS

### 1. Install Docker (kalau belum)
```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER && newgrp docker
```

### 2. Jalankan GOWA
```bash
# Edit docker-compose.gowa.yml dulu:
# - Ganti 8080 dengan port NAT VPS kamu
# - Ganti GANTI_PASSWORD_INI dengan password kuat
# - Ganti SUPABASE_PROJECT dengan Project ID Supabase kamu

nano docker-compose.gowa.yml
docker compose -f docker-compose.gowa.yml up -d
docker logs gowa --tail 20   # pastikan berjalan
```

### 3. Jalankan Migration di Supabase
Buka Supabase Dashboard → SQL Editor → paste isi file:
`supabase/migrations/20260307000001_gowa_and_fixes.sql`
Klik Run.

### 4. Deploy Edge Functions
```bash
cd project-folder

# Install Supabase CLI kalau belum
npm install -g supabase

# Login
supabase login

# Link ke project kamu
supabase link --project-ref SUPABASE_PROJECT_ID

# Deploy semua function baru/updated
supabase functions deploy gowa-create-instance
supabase functions deploy gowa-webhook
supabase functions deploy gowa-delete-instance
supabase functions deploy gowa-qr
supabase functions deploy send-message

# Set secrets (WAJIB)
supabase secrets set OPENROUTER_API_KEY=sk-or-xxx
supabase secrets set TRIPAY_API_KEY=xxx
supabase secrets set TRIPAY_PRIVATE_KEY=xxx
supabase secrets set TRIPAY_MERCHANT_CODE=xxx
```

### 5. Isi Pengaturan GOWA di Admin Panel
1. Login ke `/admin/login`
2. Buka Admin Settings → Konfigurasi Server
3. Isi **GOWA API URL**: `http://IP_VPS:PORT_KAMU` (contoh: `http://103.12.34.56:8080`)
4. Isi **GOWA Basic Auth**: `admin:PASSWORD_YANG_KAMU_SET`
5. Klik Simpan

### 6. Build Frontend
```bash
npm install
npm run build

# Deploy dist/ ke web server atau:
npx serve dist -p PORT_FRONTEND
```

---

## 👤 CARA BUAT AKUN ADMIN

Setelah deploy:
1. Register akun biasa di `/register`
2. Buka Supabase → SQL Editor → jalankan:
```sql
UPDATE public.user_roles
SET role = 'admin'
WHERE user_id = (SELECT id FROM auth.users WHERE email = 'EMAIL_KAMU@domain.com');
```
3. Login di `/admin/login` dengan email + password tadi

---

## 🔑 KONFIGURASI GOWA DI ADMIN SETTINGS

Setelah GOWA berjalan di VPS, isi di Admin Settings:
- **GOWA API URL**: `http://IP_VPS:PORT` (jangan pakai domain kalau belum setup SSL untuk GOWA)
- **GOWA Basic Auth**: `admin:PASSWORD` (sama persis dengan APP_BASIC_AUTH di docker-compose)

---

## 📋 PORT YANG DIBUTUHKAN (dari 10 port NAT VPS kamu)

| Port | Untuk | Keterangan |
|------|-------|------------|
| Satu port | GOWA | WhatsApp API server |
| Satu port | Frontend (optional) | Kalau serve sendiri, bukan dari hosting |

Supabase dipakai cloud (gratis tier) → tidak perlu port tambahan.

---

## ⚠️ CATATAN PENTING

1. **GOWA adalah single-WA per container** — cocok untuk 1 nomor WA platform.
   Jika tiap klien butuh nomor WA sendiri, mereka perlu hosting GOWA sendiri,
   atau kamu jalankan multiple container per klien (advanced setup).

2. **Webhook GOWA → Supabase** harus bisa connect dari VPS ke internet (Supabase URL).
   Pastikan VPS punya akses internet keluar.

3. **QR Code expired** setelah 60 detik → klik Refresh QR untuk generate ulang.

4. **Test koneksi WA**: Setelah scan QR, coba kirim pesan WhatsApp ke nomor yang terhubung.
   Balasan AI harusnya muncul dalam 2-5 detik.
