import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-api-key" };

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const apiKey = req.headers.get("x-api-key");
    if (!apiKey) return new Response(JSON.stringify({ error: "Missing x-api-key header" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { data: profile } = await supabase.from("profiles").select("id").eq("api_key", apiKey).single();
    if (!profile) return new Response(JSON.stringify({ error: "Invalid API key" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    const userId = profile.id;

    // Check subscription
    const { data: sub } = await supabase.from("subscriptions").select("status").eq("user_id", userId).single();
    if (sub?.status === "suspended") return new Response(JSON.stringify({ error: "Account suspended" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const url = new URL(req.url);
    const path = url.pathname.replace(/^\/functions\/v1\/public-api\/?/, "/").replace(/\/+/g, "/");

    // POST /send-message
    if (req.method === "POST" && path === "/send-message") {
      const { channel, contact, message } = await req.json();
      // Create or find chat log
      const { data: existing } = await supabase.from("chat_logs").select("id").eq("user_id", userId).eq("channel", channel).eq("contact_number", contact).eq("status", "active").single();
      let chatLogId: string;
      if (existing) { chatLogId = existing.id; }
      else {
        const { data: nl } = await supabase.from("chat_logs").insert({ user_id: userId, channel, contact_number: contact, status: "active", handler: "API" }).select("id").single();
        chatLogId = nl!.id;
      }
      // Call send-message function logic inline
      await supabase.from("chat_messages").insert({ chat_log_id: chatLogId, user_id: userId, sender_type: "agent", sender_name: "API", content: message });
      await supabase.from("chat_logs").update({ message_preview: message.substring(0, 100) }).eq("id", chatLogId);
      return new Response(JSON.stringify({ success: true, message_id: chatLogId }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // GET /chats
    if (req.method === "GET" && (path === "/chats" || path === "/chats/")) {
      const channel = url.searchParams.get("channel");
      const status = url.searchParams.get("status");
      const page = parseInt(url.searchParams.get("page") || "1");
      const limit = parseInt(url.searchParams.get("limit") || "20");
      let query = supabase.from("chat_logs").select("*", { count: "exact" }).eq("user_id", userId).order("created_at", { ascending: false }).range((page - 1) * limit, page * limit - 1);
      if (channel) query = query.eq("channel", channel);
      if (status) query = query.eq("status", status);
      const { data, count } = await query;
      return new Response(JSON.stringify({ data, total: count, page }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // GET /chats/:id/messages
    const msgMatch = path.match(/^\/chats\/([^/]+)\/messages$/);
    if (req.method === "GET" && msgMatch) {
      const { data } = await supabase.from("chat_messages").select("*").eq("chat_log_id", msgMatch[1]).order("created_at", { ascending: true });
      return new Response(JSON.stringify({ data }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // POST /chats/:id/reply
    const replyMatch = path.match(/^\/chats\/([^/]+)\/reply$/);
    if (req.method === "POST" && replyMatch) {
      const { message } = await req.json();
      await supabase.from("chat_messages").insert({ chat_log_id: replyMatch[1], user_id: userId, sender_type: "agent", sender_name: "API", content: message });
      await supabase.from("chat_logs").update({ message_preview: message.substring(0, 100) }).eq("id", replyMatch[1]);
      return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "Not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
