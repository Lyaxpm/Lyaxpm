import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { action, user_id, discord_bot_token, guild_id, channel_id } = await req.json();
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const { data: settings } = await supabase.from("platform_settings").select("key, value").in("key", ["discord_relay_url", "discord_relay_secret"]);
    const map: Record<string, string> = {};
    settings?.forEach((s: any) => map[s.key] = s.value);

    if (!map.discord_relay_url) return new Response(JSON.stringify({ error: "Discord relay not configured" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const endpoint = action === "start" ? "/spawn" : "/kill";
    const body = action === "start"
      ? { secret: map.discord_relay_secret, user_id, bot_token: discord_bot_token, guild_id, channel_id }
      : { secret: map.discord_relay_secret, user_id };

    await fetch(`${map.discord_relay_url}${endpoint}`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });

    return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
