import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const OPENROUTER_API_KEY = Deno.env.get("OPENROUTER_API_KEY");
    if (!OPENROUTER_API_KEY) throw new Error("OPENROUTER_API_KEY not configured");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const { message, contact_number, user_id, conversation_id, request_escalation } = await req.json();

    if (!message || !user_id) {
      return new Response(JSON.stringify({ error: "message and user_id required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check if user wants escalation to human
    if (request_escalation) {
      // Update chat_log status to escalated
      if (conversation_id) {
        await supabase.from("chat_logs").update({
          status: "escalated",
          handler: "Human",
          escalated_at: new Date().toISOString(),
        }).eq("id", conversation_id);
      }
      return new Response(JSON.stringify({
        escalated: true,
        message: "Percakapan telah dieskalasi ke CS. Tim kami akan segera membalas.",
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Fetch bot settings
    const { data: botSettings } = await supabase
      .from("bot_settings").select("*").eq("user_id", user_id).single();

    // Fetch FAQs
    const { data: faqs } = await supabase
      .from("faq_items").select("question, answer").eq("user_id", user_id);

    // Fetch knowledge base content
    const { data: kbItems } = await supabase
      .from("knowledge_bases").select("title, content").eq("user_id", user_id).eq("status", "ready");

    // Build system prompt
    const botName = botSettings?.bot_name || "CS Bot";
    const tone = botSettings?.tone || "friendly";
    const welcomeMsg = botSettings?.welcome_message || "";

    let systemPrompt = `Kamu adalah ${botName}, asisten customer service AI. 
Gaya bahasa: ${tone}.
Pesan sambutan: ${welcomeMsg}

INSTRUKSI PENTING:
- Jawab pertanyaan pelanggan dengan ramah dan membantu.
- Jika kamu tidak tahu jawabannya, tawarkan untuk menghubungkan ke CS manusia.
- Jika pelanggan meminta bicara dengan manusia atau CS, respons dengan JSON: {"escalate": true, "reason": "alasan eskalasi"}
- Jawab dalam Bahasa Indonesia kecuali pelanggan berbicara bahasa lain.
`;

    if (faqs && faqs.length > 0) {
      systemPrompt += "\n\nFAQ yang tersedia:\n";
      faqs.forEach((faq: any) => {
        systemPrompt += `Q: ${faq.question}\nA: ${faq.answer}\n\n`;
      });
    }

    if (kbItems && kbItems.length > 0) {
      systemPrompt += "\n\nInformasi dari knowledge base:\n";
      kbItems.forEach((kb: any) => {
        systemPrompt += `[${kb.title}]: ${(kb.content || "").substring(0, 2000)}\n\n`;
      });
    }

    // Get conversation history
    let conversationMessages: { role: string; content: string }[] = [];
    if (conversation_id) {
      const { data: history } = await supabase
        .from("chat_messages").select("sender_type, content")
        .eq("chat_log_id", conversation_id)
        .order("created_at", { ascending: true })
        .limit(20);
      if (history) {
        conversationMessages = history.map((m: any) => ({
          role: m.sender_type === "customer" ? "user" : "assistant",
          content: m.content,
        }));
      }
    }

    // Create or get chat_log
    let chatLogId = conversation_id;
    if (!chatLogId) {
      const { data: newLog } = await supabase.from("chat_logs").insert({
        user_id,
        contact_number: contact_number || "widget",
        handler: "AI",
        status: "active",
        message_preview: message.substring(0, 100),
      }).select("id").single();
      chatLogId = newLog?.id;
    }

    // Save customer message
    if (chatLogId) {
      await supabase.from("chat_messages").insert({
        chat_log_id: chatLogId,
        user_id,
        sender_type: "customer",
        sender_name: contact_number || "Customer",
        content: message,
      });
    }

    // Get AI model from platform settings
    const { data: modelSetting } = await supabase
      .from("platform_settings").select("value").eq("key", "ai_model").single();
    const aiModel = (modelSetting as any)?.value || "google/gemini-2.5-flash";

    // Call OpenRouter
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": supabaseUrl,
      },
      body: JSON.stringify({
        model: aiModel,
        messages: [
          { role: "system", content: systemPrompt },
          ...conversationMessages,
          { role: "user", content: message },
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("OpenRouter error:", response.status, errText);
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, coba lagi nanti." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      return new Response(JSON.stringify({ error: "AI service error" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // We need to intercept the stream to:
    // 1. Collect full response for saving
    // 2. Detect escalation requests
    // 3. Forward to client
    const { readable, writable } = new TransformStream();
    const writer = writable.getWriter();
    const encoder = new TextEncoder();
    const decoder = new TextDecoder();

    const reader = response.body!.getReader();
    let fullResponse = "";

    (async () => {
      try {
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          
          let newlineIdx;
          while ((newlineIdx = buffer.indexOf("\n")) !== -1) {
            const line = buffer.slice(0, newlineIdx).trim();
            buffer = buffer.slice(newlineIdx + 1);
            
            if (!line || line.startsWith(":")) continue;
            if (line.startsWith("data: ")) {
              const jsonStr = line.slice(6).trim();
              if (jsonStr === "[DONE]") {
                await writer.write(encoder.encode("data: [DONE]\n\n"));
                continue;
              }
              try {
                const parsed = JSON.parse(jsonStr);
                const content = parsed.choices?.[0]?.delta?.content;
                if (content) fullResponse += content;
                await writer.write(encoder.encode(line + "\n\n"));
              } catch {
                await writer.write(encoder.encode(line + "\n\n"));
              }
            }
          }
        }

        // Save bot response
        if (chatLogId && fullResponse) {
          await supabase.from("chat_messages").insert({
            chat_log_id: chatLogId,
            user_id,
            sender_type: "bot",
            sender_name: botName,
            content: fullResponse,
          });

          // Update chat_log preview
          await supabase.from("chat_logs").update({
            message_preview: fullResponse.substring(0, 100),
          }).eq("id", chatLogId);

          // Check if AI wants to escalate
          try {
            if (fullResponse.includes('"escalate"') && fullResponse.includes("true")) {
              await supabase.from("chat_logs").update({
                status: "escalated",
                handler: "Human",
                escalated_at: new Date().toISOString(),
              }).eq("id", chatLogId);
            }
          } catch { /* ignore parse error */ }
        }
      } catch (e) {
        console.error("Stream processing error:", e);
      } finally {
        await writer.close();
      }
    })();

    return new Response(readable, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("ai-chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
