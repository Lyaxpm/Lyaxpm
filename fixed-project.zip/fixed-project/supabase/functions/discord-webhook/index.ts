import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { user_id, author_id, author_username, content, channel_id, guild_id } = await req.json();
    if (!content || !user_id) return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: cfg } = await supabase.from("channel_configs").select("discord_bot_token, discord_channel_id").eq("user_id", user_id).eq("channel", "discord").eq("is_active", true).single();
    if (!cfg) return new Response("Not configured", { status: 404 });

    // Upsert chat_log
    const { data: existing } = await supabase.from("chat_logs").select("id").eq("user_id", user_id).eq("channel", "discord").eq("contact_number", author_id).eq("status", "active").single();
    let chatLogId: string;
    if (existing) {
      chatLogId = existing.id;
      await supabase.from("chat_logs").update({ message_preview: content.substring(0, 100), customer_name: author_username }).eq("id", chatLogId);
    } else {
      const { data: newLog } = await supabase.from("chat_logs").insert({ user_id, channel: "discord", contact_number: author_id, customer_name: author_username, status: "active", handler: "AI", message_preview: content.substring(0, 100) }).select("id").single();
      chatLogId = newLog!.id;
    }

    await supabase.from("chat_messages").insert({ chat_log_id: chatLogId, user_id, sender_type: "customer", sender_name: author_username, content });

    // Check assigned
    const { data: cl } = await supabase.from("chat_logs").select("assigned_agent_id").eq("id", chatLogId).single();
    if (cl?.assigned_agent_id) return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });

    // AI
    const aiRes = await fetch(`${Deno.env.get("SUPABASE_URL")}/functions/v1/ai-chat`, {
      method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}` },
      body: JSON.stringify({ message: content, user_id, contact_number: author_id, conversation_id: chatLogId }),
    });
    let aiReply = "";
    const reader = aiRes.body?.getReader();
    const decoder = new TextDecoder();
    if (reader) { while (true) { const { done, value } = await reader.read(); if (done) break; const chunk = decoder.decode(value); for (const line of chunk.split("\n")) { if (line.startsWith("data: ") && line !== "data: [DONE]") { try { aiReply += JSON.parse(line.slice(6)).choices?.[0]?.delta?.content || ""; } catch {} } } } }
    if (!aiReply) aiReply = "Maaf, saya tidak bisa memproses pesan Anda.";

    // Send to Discord
    const replyChannelId = cfg.discord_channel_id || channel_id;
    await fetch(`https://discord.com/api/v10/channels/${replyChannelId}/messages`, {
      method: "POST", headers: { Authorization: `Bot ${cfg.discord_bot_token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ content: aiReply }),
    });

    // Increment chats_used
    const { data: sub } = await supabase.from("subscriptions").select("chats_used").eq("user_id", user_id).single();
    if (sub) await supabase.from("subscriptions").update({ chats_used: sub.chats_used + 1 }).eq("user_id", user_id);

    return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("discord-webhook error:", e);
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
