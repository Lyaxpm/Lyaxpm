import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  try {
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const anonClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!);

    const token = req.headers.get("Authorization")?.replace("Bearer ", "");
    if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });
    const { data: { user } } = await anonClient.auth.getUser(token);
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });

    const { data: rows } = await supabase.from("platform_settings").select("key, value").in("key", ["gowa_api_url", "gowa_basic_auth"]);
    const cfg: Record<string, string> = {};
    rows?.forEach((r: any) => cfg[r.key] = r.value);
    const gowaUrl = cfg.gowa_api_url?.replace(/\/$/, "");
    const gowaAuth = cfg.gowa_basic_auth || "admin:admin";

    if (!gowaUrl) {
      return new Response(JSON.stringify({ error: "GOWA belum dikonfigurasi" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
    }

    const authHeader = `Basic ${btoa(gowaAuth)}`;

    // Check if already connected via /user/info
    try {
      const infoRes = await fetch(`${gowaUrl}/user/info`, { headers: { "Authorization": authHeader } });
      if (infoRes.ok) {
        const info = await infoRes.json();
        // GOWA /user/info returns results.phone when connected
        const phone = info?.results?.phone || info?.results?.pushName || null;
        if (phone) {
          await supabase.from("wa_connections").update({
            status: "connected", phone_number: phone, connected_at: new Date().toISOString(),
          }).eq("user_id", user.id);
          return new Response(JSON.stringify({ status: "connected", phone_number: phone }), { headers: { ...cors, "Content-Type": "application/json" } });
        }
      }
    } catch { /* not connected yet */ }

    // Get QR — GOWA endpoint: GET /login returns QR image or JSON
    try {
      const qrRes = await fetch(`${gowaUrl}/login`, { headers: { "Authorization": authHeader } });
      if (qrRes.ok) {
        const ct = qrRes.headers.get("content-type") || "";
        if (ct.includes("image")) {
          const buf = await qrRes.arrayBuffer();
          const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
          return new Response(JSON.stringify({ status: "qr", qr_image: `data:${ct};base64,${b64}` }), { headers: { ...cors, "Content-Type": "application/json" } });
        } else {
          const data = await qrRes.json();
          // GOWA may return { results: { qr_link: "data:image/png;base64,..." } }
          const qrImg = data?.results?.qr_link || data?.qr_link || data?.qr || null;
          return new Response(JSON.stringify({ status: qrImg ? "qr" : "waiting", qr_image: qrImg }), { headers: { ...cors, "Content-Type": "application/json" } });
        }
      }
    } catch { /* ignore */ }

    return new Response(JSON.stringify({ status: "waiting" }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  }
});
