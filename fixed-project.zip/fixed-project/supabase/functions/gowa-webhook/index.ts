import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  const json = { headers: { ...cors, "Content-Type": "application/json" } };

  try {
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const body = await req.json();
    console.log("GOWA webhook:", JSON.stringify(body).slice(0, 500));

    // GOWA webhook payload: { event, device_id, payload, secret }
    const event: string = body.event || "";
    const payload = body.payload || body;
    const secret: string = body.secret || body.webhook_secret || "";

    // Find user_id from secret (we set user.id as secret in gowa-create-instance)
    let userId: string | null = null;
    if (secret && /^[0-9a-f-]{36}$/.test(secret)) userId = secret;

    // Also try phone-based lookup if no secret
    if (!userId) {
      const deviceId: string = body.device_id || payload?.device || "";
      const phone = deviceId.split("@")[0];
      if (phone) {
        const { data } = await supabase.from("wa_connections").select("user_id").eq("phone_number", phone).single();
        if (data) userId = data.user_id;
      }
    }

    // Connection update events
    if (event === "connection.update" || event === "connection" || event.includes("connection")) {
      const connStatus: string = payload?.status || payload?.connection || "";
      if (connStatus === "open" || connStatus === "connected") {
        const phone = payload?.phone || payload?.phone_number || "";
        if (userId) {
          await supabase.from("wa_connections").update({
            status: "connected", phone_number: phone, connected_at: new Date().toISOString(),
          }).eq("user_id", userId);
        }
      } else if (connStatus === "close" || connStatus === "disconnected") {
        if (userId) {
          await supabase.from("wa_connections").update({ status: "disconnected", phone_number: null }).eq("user_id", userId);
        }
      }
      return new Response(JSON.stringify({ ok: true }), json);
    }

    // Message events
    if ((event === "message" || event === "messages.upsert") && userId) {
      const msg = payload?.message || payload;

      // Skip outgoing
      if (msg?.from_me === true || msg?.key?.fromMe === true) return new Response(JSON.stringify({ ok: true, skip: "outgoing" }), json);

      // Skip groups
      const sender: string = msg?.sender || msg?.from || msg?.key?.remoteJid || "";
      if (sender.includes("@g.us")) return new Response(JSON.stringify({ ok: true, skip: "group" }), json);

      const contactNumber = sender.split("@")[0].replace(/\D/g, "");
      const customerName: string = msg?.push_name || msg?.pushName || msg?.senderName || contactNumber;
      const messageText: string = msg?.text || msg?.body || msg?.message?.conversation || msg?.message?.extendedTextMessage?.text || "";

      if (!messageText || !contactNumber) return new Response(JSON.stringify({ ok: true, skip: "no_content" }), json);

      // Check subscription
      const { data: sub } = await supabase.from("subscriptions").select("chat_limit, chats_used, status").eq("user_id", userId).single();
      if (sub?.status === "suspended") return new Response(JSON.stringify({ ok: true, skip: "suspended" }), json);
      if (sub && sub.chat_limit !== -1 && (sub.chats_used || 0) >= sub.chat_limit) return new Response(JSON.stringify({ ok: true, skip: "limit" }), json);

      // Upsert chat_log
      const { data: existing } = await supabase.from("chat_logs").select("id, assigned_agent_id").eq("user_id", userId).eq("channel", "whatsapp").eq("contact_number", contactNumber).eq("status", "active").maybeSingle();

      let chatLogId: string;
      if (existing) {
        chatLogId = existing.id;
        await supabase.from("chat_logs").update({ message_preview: messageText.slice(0, 100) }).eq("id", chatLogId);
      } else {
        const { data: newLog } = await supabase.from("chat_logs").insert({ user_id: userId, channel: "whatsapp", contact_number: contactNumber, customer_name: customerName, message_preview: messageText.slice(0, 100), handler: "AI", status: "active" }).select("id").single();
        chatLogId = newLog!.id;
      }

      // Insert customer message
      await supabase.from("chat_messages").insert({ chat_log_id: chatLogId, user_id: userId, sender_type: "customer", sender_name: customerName, content: messageText });

      // If assigned to agent → don't auto-reply
      if (existing?.assigned_agent_id) return new Response(JSON.stringify({ ok: true, handled: "agent" }), json);

      // Call ai-chat
      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      let aiReply = "";
      try {
        const aiRes = await fetch(`${supabaseUrl}/functions/v1/ai-chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}` },
          body: JSON.stringify({ message: messageText, user_id: userId, contact_number: contactNumber, conversation_id: chatLogId }),
        });
        if (aiRes.ok) {
          const text = await aiRes.text();
          for (const line of text.split("\n")) {
            if (line.startsWith("data: ") && !line.includes("[DONE]")) {
              try { const c = JSON.parse(line.slice(6))?.choices?.[0]?.delta?.content; if (c) aiReply += c; } catch { /* skip */ }
            }
          }
          // If not SSE, try plain text
          if (!aiReply) aiReply = text.trim();
        }
      } catch (aiErr) { console.error("ai-chat error:", aiErr); }

      if (aiReply) {
        // Send via GOWA
        const { data: cfgRows } = await supabase.from("platform_settings").select("key, value").in("key", ["gowa_api_url", "gowa_basic_auth"]);
        const cfg: Record<string, string> = {};
        cfgRows?.forEach((r: any) => cfg[r.key] = r.value);
        const gowaUrl = cfg.gowa_api_url?.replace(/\/$/, "");
        const gowaAuth = cfg.gowa_basic_auth || "admin:admin";
        if (gowaUrl) {
          await fetch(`${gowaUrl}/send/message`, {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": `Basic ${btoa(gowaAuth)}` },
            body: JSON.stringify({ phone: contactNumber, message: aiReply }),
          });
        }
        await supabase.from("chat_messages").insert({ chat_log_id: chatLogId, user_id: userId, sender_type: "bot", sender_name: "AI", content: aiReply });
        await supabase.from("chat_logs").update({ message_preview: aiReply.slice(0, 100) }).eq("id", chatLogId);
        await supabase.from("subscriptions").update({ chats_used: (sub?.chats_used || 0) + 1 }).eq("user_id", userId);
      }

      return new Response(JSON.stringify({ ok: true, handled: "ai" }), json);
    }

    return new Response(JSON.stringify({ ok: true }), json);
  } catch (e: any) {
    console.error("gowa-webhook error:", e);
    return new Response(JSON.stringify({ error: e.message }), { status: 500, ...json });
  }
});
