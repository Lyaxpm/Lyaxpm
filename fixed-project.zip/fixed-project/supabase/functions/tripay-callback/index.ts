import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const planDetails: Record<string, { chatLimit: number; waLimit: number; price: number }> = {
  starter: { chatLimit: 500, waLimit: 1, price: 500000 },
  pro: { chatLimit: -1, waLimit: 1, price: 1200000 },
  enterprise: { chatLimit: -1, waLimit: 3, price: 2500000 },
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const TRIPAY_PRIVATE_KEY = Deno.env.get("TRIPAY_PRIVATE_KEY");
    if (!TRIPAY_PRIVATE_KEY) throw new Error("TRIPAY_PRIVATE_KEY not configured");

    const body = await req.json();
    const { merchant_ref, reference, status } = body;

    // Verify callback signature
    const callbackSignature = req.headers.get("X-Callback-Signature");
    if (callbackSignature) {
      const encoder = new TextEncoder();
      const data = encoder.encode(JSON.stringify(body));
      const key = encoder.encode(TRIPAY_PRIVATE_KEY);
      const cryptoKey = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
      const signatureBuffer = await crypto.subtle.sign("HMAC", cryptoKey, data);
      const computedSignature = Array.from(new Uint8Array(signatureBuffer)).map(b => b.toString(16).padStart(2, "0")).join("");
      
      if (computedSignature !== callbackSignature) {
        console.error("Invalid callback signature");
        return new Response(JSON.stringify({ error: "Invalid signature" }), {
          status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    // Find payment record
    const { data: payment } = await supabase
      .from("payments").select("*").eq("merchant_ref", merchant_ref).single();

    if (!payment) {
      return new Response(JSON.stringify({ error: "Payment not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const paymentStatus = status === "PAID" ? "paid" : status === "EXPIRED" ? "expired" : status === "FAILED" ? "failed" : "pending";

    // Update payment status
    await supabase.from("payments").update({
      status: paymentStatus,
      tripay_reference: reference,
      paid_at: paymentStatus === "paid" ? new Date().toISOString() : null,
    }).eq("id", payment.id);

    // If paid, upgrade subscription
    if (paymentStatus === "paid") {
      // Determine plan from amount
      let plan = "starter";
      if (payment.amount >= 2500000) plan = "enterprise";
      else if (payment.amount >= 1200000) plan = "pro";
      else if (payment.amount >= 500000) plan = "starter";

      const details = planDetails[plan];
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30);

      await supabase.from("subscriptions").update({
        plan,
        chat_limit: details.chatLimit,
        wa_limit: details.waLimit,
        price: details.price,
        status: "active",
        started_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        chats_used: 0,
      }).eq("user_id", payment.user_id);

      console.log(`Subscription upgraded to ${plan} for user ${payment.user_id}`);
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("tripay-callback error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
