import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const TRIPAY_API_URL = "https://tripay.co.id/api/transaction/create";

const planPrices: Record<string, number> = {
  starter: 500000,
  pro: 1200000,
  enterprise: 2500000,
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const TRIPAY_API_KEY = Deno.env.get("TRIPAY_API_KEY");
    const TRIPAY_PRIVATE_KEY = Deno.env.get("TRIPAY_PRIVATE_KEY");
    const TRIPAY_MERCHANT_CODE = Deno.env.get("TRIPAY_MERCHANT_CODE");

    if (!TRIPAY_API_KEY || !TRIPAY_PRIVATE_KEY || !TRIPAY_MERCHANT_CODE) {
      throw new Error("Tripay credentials not configured");
    }

    // Get user from JWT
    const authHeader = req.headers.get("Authorization");
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const anonClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!);
    let userId: string | null = null;
    let userEmail = "";

    if (authHeader) {
      const token = authHeader.replace("Bearer ", "");
      const { data: { user } } = await anonClient.auth.getUser(token);
      if (user) {
        userId = user.id;
        userEmail = user.email || "";
      }
    }

    if (!userId) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { plan, method } = await req.json();
    if (!plan || !planPrices[plan]) {
      return new Response(JSON.stringify({ error: "Invalid plan" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const amount = planPrices[plan];
    const merchantRef = `INV-${Date.now()}-${userId.substring(0, 8)}`;
    const expiry = Math.floor(Date.now() / 1000) + 24 * 60 * 60; // 24 hours

    // Generate signature
    const encoder = new TextEncoder();
    const signData = encoder.encode(TRIPAY_MERCHANT_CODE + merchantRef + amount);
    const key = encoder.encode(TRIPAY_PRIVATE_KEY);
    const cryptoKey = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const signatureBuffer = await crypto.subtle.sign("HMAC", cryptoKey, signData);
    const signature = Array.from(new Uint8Array(signatureBuffer)).map(b => b.toString(16).padStart(2, "0")).join("");

    const payload = {
      method: method || "QRIS",
      merchant_ref: merchantRef,
      amount,
      customer_name: userEmail,
      customer_email: userEmail,
      order_items: [{
        name: `Paket ${plan.charAt(0).toUpperCase() + plan.slice(1)} - ChatServis.AI`,
        price: amount,
        quantity: 1,
      }],
      expired_time: expiry,
      signature,
    };

    const tripayRes = await fetch(TRIPAY_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${TRIPAY_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const tripayData = await tripayRes.json();

    if (!tripayRes.ok || !tripayData.success) {
      console.error("Tripay error:", tripayData);
      return new Response(JSON.stringify({ error: tripayData.message || "Payment creation failed" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get subscription ID
    const { data: sub } = await supabase.from("subscriptions").select("id").eq("user_id", userId).single();

    // Save payment record
    await supabase.from("payments").insert({
      user_id: userId,
      subscription_id: sub?.id,
      tripay_reference: tripayData.data.reference,
      merchant_ref: merchantRef,
      amount,
      method: method || "QRIS",
      status: "pending",
    });

    return new Response(JSON.stringify({
      success: true,
      data: {
        reference: tripayData.data.reference,
        merchant_ref: merchantRef,
        amount,
        checkout_url: tripayData.data.checkout_url,
        pay_code: tripayData.data.pay_code,
        qr_url: tripayData.data.qr_url,
      },
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("tripay-create error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
