import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  try {
    const url = new URL(req.url);
    const parts = url.pathname.split("/");
    const user_id = parts[parts.length - 1];
    if (!user_id) return new Response("Missing user_id", { status: 400 });

    const body = await req.json();
    const message = body.message;
    if (!message?.text) return new Response("OK");

    const chatId = String(message.chat.id);
    const firstName = message.from?.first_name || "User";
    const text = message.text;

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // Get channel config
    const { data: cfg } = await supabase.from("channel_configs").select("telegram_bot_token").eq("user_id", user_id).eq("channel", "telegram").eq("is_active", true).single();
    if (!cfg) return new Response("Channel not configured", { status: 404 });
    const botToken = cfg.telegram_bot_token;

    // Upsert chat_log
    const { data: existing } = await supabase.from("chat_logs").select("id").eq("user_id", user_id).eq("channel", "telegram").eq("contact_number", chatId).eq("status", "active").single();
    let chatLogId: string;
    if (existing) {
      chatLogId = existing.id;
      await supabase.from("chat_logs").update({ message_preview: text.substring(0, 100), customer_name: firstName }).eq("id", chatLogId);
    } else {
      const { data: newLog } = await supabase.from("chat_logs").insert({ user_id, channel: "telegram", contact_number: chatId, customer_name: firstName, status: "active", handler: "AI", message_preview: text.substring(0, 100) }).select("id").single();
      chatLogId = newLog!.id;
    }

    // Insert customer message
    await supabase.from("chat_messages").insert({ chat_log_id: chatLogId, user_id, sender_type: "customer", sender_name: firstName, content: text });

    // Check chat limit
    const { data: sub } = await supabase.from("subscriptions").select("chat_limit, chats_used").eq("user_id", user_id).single();
    if (sub && sub.chat_limit !== -1 && sub.chats_used >= sub.chat_limit) {
      await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: chatId, text: "Maaf, layanan sedang tidak tersedia." }) });
      return new Response("OK");
    }

    // Check if assigned to agent
    const { data: chatLog } = await supabase.from("chat_logs").select("assigned_agent_id").eq("id", chatLogId).single();
    if (chatLog?.assigned_agent_id) return new Response("OK"); // Agent handles

    // Call AI
    const aiRes = await fetch(`${Deno.env.get("SUPABASE_URL")}/functions/v1/ai-chat`, {
      method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}` },
      body: JSON.stringify({ message: text, user_id, contact_number: chatId, conversation_id: chatLogId }),
    });
    let aiReply = "";
    const reader = aiRes.body?.getReader();
    const decoder = new TextDecoder();
    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value);
        for (const line of chunk.split("\n")) {
          if (line.startsWith("data: ") && line !== "data: [DONE]") {
            try { const p = JSON.parse(line.slice(6)); aiReply += p.choices?.[0]?.delta?.content || ""; } catch {}
          }
        }
      }
    }
    if (!aiReply) aiReply = "Maaf, saya tidak bisa memproses pesan Anda saat ini.";

    // Send reply
    await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: chatId, text: aiReply }) });

    // Increment chats_used
    if (sub) await supabase.from("subscriptions").update({ chats_used: sub.chats_used + 1 }).eq("user_id", user_id);

    return new Response("OK");
  } catch (e) {
    console.error("telegram-webhook error:", e);
    return new Response("Error", { status: 500 });
  }
});
