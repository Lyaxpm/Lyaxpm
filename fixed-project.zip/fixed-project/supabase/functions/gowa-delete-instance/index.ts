import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  try {
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const anonClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!);

    const token = req.headers.get("Authorization")?.replace("Bearer ", "");
    if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });
    const { data: { user } } = await anonClient.auth.getUser(token);
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });

    const { data: rows } = await supabase.from("platform_settings").select("key, value").in("key", ["gowa_api_url", "gowa_basic_auth"]);
    const cfg: Record<string, string> = {};
    rows?.forEach((r: any) => cfg[r.key] = r.value);
    const gowaUrl = cfg.gowa_api_url?.replace(/\/$/, "");
    const gowaAuth = cfg.gowa_basic_auth || "admin:admin";

    if (gowaUrl) {
      try {
        await fetch(`${gowaUrl}/logout`, {
          method: "GET",
          headers: { "Authorization": `Basic ${btoa(gowaAuth)}` },
        });
      } catch { /* ignore */ }
    }

    await supabase.from("wa_connections").update({
      status: "disconnected", phone_number: null, connected_at: null, instance_name: null,
    }).eq("user_id", user.id);

    return new Response(JSON.stringify({ success: true }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  }
});
