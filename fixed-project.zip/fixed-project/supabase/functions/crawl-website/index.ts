import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    const { url, kb_id, user_id } = await req.json();

    if (!url || !kb_id || !user_id) {
      return new Response(JSON.stringify({ error: "url, kb_id, and user_id required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Update status to crawling
    await supabase.from("knowledge_bases").update({ status: "crawling" }).eq("id", kb_id);

    let formattedUrl = url.trim();
    if (!formattedUrl.startsWith("http")) formattedUrl = "https://" + formattedUrl;

    // Fetch the page content
    const response = await fetch(formattedUrl, {
      headers: {
        "User-Agent": "ChatServisBot/1.0 (Knowledge Base Crawler)",
        "Accept": "text/html,application/xhtml+xml",
      },
    });

    if (!response.ok) {
      await supabase.from("knowledge_bases").update({ status: "error" }).eq("id", kb_id);
      return new Response(JSON.stringify({ error: `Failed to fetch: ${response.status}` }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const html = await response.text();

    // Extract text content from HTML (simple approach)
    let text = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
      .replace(/<nav[^>]*>[\s\S]*?<\/nav>/gi, "")
      .replace(/<footer[^>]*>[\s\S]*?<\/footer>/gi, "")
      .replace(/<header[^>]*>[\s\S]*?<\/header>/gi, "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/g, " ")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/\s+/g, " ")
      .trim();

    // Limit content size
    text = text.substring(0, 50000);

    // Extract title
    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].trim() : new URL(formattedUrl).hostname;

    // Update knowledge base with content
    await supabase.from("knowledge_bases").update({
      content: text,
      title,
      status: "ready",
      updated_at: new Date().toISOString(),
    }).eq("id", kb_id);

    return new Response(JSON.stringify({ success: true, title, content_length: text.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("Crawl error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
