import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version" };

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { chat_log_id, message, user_id } = await req.json();
    if (!chat_log_id || !message || !user_id) return new Response(JSON.stringify({ error: "Missing params" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const { data: chatLog } = await supabase.from("chat_logs").select("channel, contact_number").eq("id", chat_log_id).single();
    if (!chatLog) return new Response(JSON.stringify({ error: "Chat not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const channel = chatLog.channel || "whatsapp";
    const contact = chatLog.contact_number;

    // Get all platform settings once
    const { data: settingsRows } = await supabase.from("platform_settings").select("key, value");
    const settingsMap: Record<string, string> = {};
    settingsRows?.forEach((s: any) => settingsMap[s.key] = s.value);

    if (channel === "whatsapp") {
      const gowaUrl = settingsMap.gowa_api_url?.replace(/\/$/, "");
      const gowaAuth = settingsMap.gowa_basic_auth || "admin:admin";
      if (gowaUrl) {
        await fetch(`${gowaUrl}/send/message`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": `Basic ${btoa(gowaAuth)}` },
          body: JSON.stringify({ phone: contact, message: message }),
        });
      }
    } else if (channel === "telegram") {
      const { data: cfg } = await supabase.from("channel_configs").select("telegram_bot_token").eq("user_id", user_id).eq("channel", "telegram").single();
      if (cfg?.telegram_bot_token) {
        await fetch(`https://api.telegram.org/bot${cfg.telegram_bot_token}/sendMessage`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: contact, text: message }),
        });
      }
    } else if (channel === "discord") {
      const { data: cfg } = await supabase.from("channel_configs").select("discord_bot_token, discord_channel_id").eq("user_id", user_id).eq("channel", "discord").single();
      if (cfg?.discord_bot_token) {
        const chId = cfg.discord_channel_id || contact;
        await fetch(`https://discord.com/api/v10/channels/${chId}/messages`, {
          method: "POST", headers: { Authorization: `Bot ${cfg.discord_bot_token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ content: message }),
        });
      }
    }
    // widget: no external send needed

    // Insert agent message
    // Get real agent name
    const { data: agentProfile } = await supabase.from("profiles").select("full_name").eq("id", user_id).single();
    const senderName = agentProfile?.full_name || "CS Agent";
    await supabase.from("chat_messages").insert({ chat_log_id, user_id, sender_type: "agent", sender_name: senderName, content: message });
    await supabase.from("chat_logs").update({ message_preview: message.substring(0, 100), handler: "Human" }).eq("id", chat_log_id);

    return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
