
DO $$ BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_logs;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;
