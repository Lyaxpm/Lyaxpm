-- =============================================
-- Migration: GOWA + agents + chat_logs columns
-- =============================================

-- Add gowa settings to platform_settings
INSERT INTO public.platform_settings (key, value, description) VALUES
  ('gowa_api_url', '', 'URL GOWA WhatsApp API (contoh: http://IP_VPS:8080)'),
  ('gowa_basic_auth', 'admin:password', 'Basic auth GOWA format user:password')
ON CONFLICT (key) DO NOTHING;

-- Add instance_name column to wa_connections (if not exists)
ALTER TABLE public.wa_connections ADD COLUMN IF NOT EXISTS instance_name text;

-- Add channel + customer_name + assigned_agent_id to chat_logs (if not exists)
ALTER TABLE public.chat_logs ADD COLUMN IF NOT EXISTS channel text NOT NULL DEFAULT 'whatsapp';
ALTER TABLE public.chat_logs ADD COLUMN IF NOT EXISTS customer_name text;
ALTER TABLE public.chat_logs ADD COLUMN IF NOT EXISTS assigned_agent_id uuid;

-- Add is_read to chat_messages (if not exists)
ALTER TABLE public.chat_messages ADD COLUMN IF NOT EXISTS is_read boolean NOT NULL DEFAULT false;

-- Agents table for agent invite system
CREATE TABLE IF NOT EXISTS public.agents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  agent_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  name text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending',
  invite_token text UNIQUE DEFAULT gen_random_uuid()::text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners can manage their agents" ON public.agents
  FOR ALL TO authenticated USING (workspace_owner_id = auth.uid());

CREATE POLICY "Agents can view own record" ON public.agents
  FOR SELECT TO authenticated USING (agent_user_id = auth.uid());

CREATE POLICY "Admins can view all agents" ON public.agents
  FOR SELECT TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));

-- channel_configs table for Telegram/Discord tokens per client
CREATE TABLE IF NOT EXISTS public.channel_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  channel text NOT NULL,
  is_active boolean NOT NULL DEFAULT false,
  telegram_bot_token text,
  discord_bot_token text,
  discord_guild_id text,
  discord_channel_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, channel)
);

ALTER TABLE public.channel_configs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own channel configs" ON public.channel_configs
  FOR ALL TO authenticated USING (user_id = auth.uid());

-- Add api_key to profiles for Public API auth
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS api_key text UNIQUE DEFAULT gen_random_uuid()::text;

-- Add chat_logs + chat_messages to realtime
DO $$ BEGIN
  BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages; EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;

-- Allow agents to read/write messages for their workspace_owner's chats
-- (via RLS using join with agents table)
CREATE POLICY "Agents can view workspace messages" ON public.chat_messages
  FOR SELECT TO authenticated
  USING (
    user_id IN (
      SELECT workspace_owner_id FROM public.agents WHERE agent_user_id = auth.uid() AND status = 'active'
    )
  );

CREATE POLICY "Agents can insert workspace messages" ON public.chat_messages
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id IN (
      SELECT workspace_owner_id FROM public.agents WHERE agent_user_id = auth.uid() AND status = 'active'
    )
  );

CREATE POLICY "Agents can view workspace chat logs" ON public.chat_logs
  FOR SELECT TO authenticated
  USING (
    user_id IN (
      SELECT workspace_owner_id FROM public.agents WHERE agent_user_id = auth.uid() AND status = 'active'
    )
  );

CREATE POLICY "Agents can update workspace chat logs" ON public.chat_logs
  FOR UPDATE TO authenticated
  USING (
    user_id IN (
      SELECT workspace_owner_id FROM public.agents WHERE agent_user_id = auth.uid() AND status = 'active'
    )
  );
