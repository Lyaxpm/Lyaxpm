
-- Chat messages for live chat (individual messages within sessions)
CREATE TABLE public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_log_id uuid NOT NULL REFERENCES public.chat_logs(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  sender_type text NOT NULL DEFAULT 'customer',
  sender_name text,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own chat messages" ON public.chat_messages
FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can insert own chat messages" ON public.chat_messages
FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all chat messages" ON public.chat_messages
FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

-- Knowledge bases for website/business integration
CREATE TABLE public.knowledge_bases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  url text NOT NULL,
  title text,
  content text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.knowledge_bases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own knowledge bases" ON public.knowledge_bases
FOR ALL USING (user_id = auth.uid());

-- Payments table for Tripay
CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  subscription_id uuid REFERENCES public.subscriptions(id),
  tripay_reference text,
  merchant_ref text UNIQUE,
  amount integer NOT NULL,
  method text,
  status text NOT NULL DEFAULT 'pending',
  paid_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own payments" ON public.payments
FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can insert own payments" ON public.payments
FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can manage all payments" ON public.payments
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Add escalation fields to chat_logs
ALTER TABLE public.chat_logs 
ADD COLUMN IF NOT EXISTS escalated_to text,
ADD COLUMN IF NOT EXISTS escalated_at timestamptz,
ADD COLUMN IF NOT EXISTS agent_notes text;

-- Enable realtime for live chat
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;

-- Triggers
CREATE TRIGGER update_knowledge_bases_updated_at
BEFORE UPDATE ON public.knowledge_bases
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
