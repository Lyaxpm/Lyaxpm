
-- Platform-wide settings managed by admin
CREATE TABLE IF NOT EXISTS public.platform_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text NOT NULL,
  description text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage platform settings" ON public.platform_settings
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Authenticated users can read platform settings" ON public.platform_settings
  FOR SELECT TO authenticated
  USING (true);

-- Insert default platform settings
INSERT INTO public.platform_settings (key, value, description) VALUES
  ('ai_model', 'google/gemini-2.5-flash', 'Model AI yang digunakan'),
  ('starter_price', '500000', 'Harga paket Starter (Rp)'),
  ('pro_price', '1200000', 'Harga paket Pro (Rp)'),
  ('enterprise_price', '2500000', 'Harga paket Enterprise (Rp)'),
  ('starter_chat_limit', '500', 'Batas chat paket Starter'),
  ('pro_chat_limit', '-1', 'Batas chat paket Pro (-1=unlimited)'),
  ('enterprise_chat_limit', '-1', 'Batas chat paket Enterprise (-1=unlimited)'),
  ('tripay_mode', 'sandbox', 'Tripay mode: sandbox atau production');

-- Bot channels table for multi-channel support
CREATE TABLE IF NOT EXISTS public.bot_channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  channel_type text NOT NULL DEFAULT 'whatsapp',
  channel_name text NOT NULL DEFAULT '',
  config jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'disconnected',
  connected_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.bot_channels ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own channels" ON public.bot_channels
  FOR ALL TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can view all channels" ON public.bot_channels
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Add update policy for chat_logs so agents can update status
CREATE POLICY "Users can update own chat logs" ON public.chat_logs
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
