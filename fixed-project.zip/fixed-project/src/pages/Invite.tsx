import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export default function Invite() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const token = params.get("token");
  const [agent, setAgent] = useState<any>(null);
  const [ownerName, setOwnerName] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [accepting, setAccepting] = useState(false);
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [registering, setRegistering] = useState(false);

  useEffect(() => {
    if (!token) { setError("Token undangan tidak valid"); setLoading(false); return; }
    (supabase.from("agents" as any).select("*") as any).eq("invite_token", token).eq("status", "pending").single()
      .then(async ({ data, error: e }: any) => {
        if (e || !data) { setError("Undangan tidak ditemukan atau sudah digunakan"); setLoading(false); return; }
        setAgent(data);
        const { data: profile } = await supabase.from("profiles").select("full_name").eq("id", data.workspace_owner_id).single();
        setOwnerName((profile as any)?.full_name || "Pemilik Workspace");
        setRegEmail(data.email || "");
        setRegName(data.name || "");
        setLoading(false);
      });
  }, [token]);

  const acceptInvite = async () => {
    if (!user || !agent) return;
    setAccepting(true);
    await (supabase.from("agents" as any) as any).update({ agent_user_id: user.id, status: "active" }).eq("id", agent.id);
    toast.success("Undangan diterima!");
    navigate("/dashboard");
  };

  const registerAndAccept = async () => {
    if (!regEmail || !regPassword || regPassword.length < 6) {
      toast.error("Lengkapi form dengan benar (password min 6 karakter)");
      return;
    }
    setRegistering(true);
    const { data: authData, error: authErr } = await supabase.auth.signUp({
      email: regEmail,
      password: regPassword,
      options: { data: { full_name: regName } },
    });
    if (authErr) { toast.error(authErr.message); setRegistering(false); return; }
    if (authData.user) {
      await (supabase.from("agents" as any) as any).update({ agent_user_id: authData.user.id, status: "active" }).eq("id", agent.id);
      toast.success("Akun dibuat & undangan diterima!");
      navigate("/dashboard");
    }
    setRegistering(false);
  };

  if (loading) return (
    <div className="min-h-screen gradient-hero flex items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );

  if (error) return (
    <div className="min-h-screen gradient-hero flex items-center justify-center">
      <Card className="gradient-card border-border max-w-md w-full mx-4">
        <CardContent className="p-8 text-center">
          <XCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <p className="font-medium">{error}</p>
          <Button className="mt-4" variant="outline" onClick={() => navigate("/login")}>Ke Login</Button>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen gradient-hero flex items-center justify-center">
      <Card className="gradient-card border-border max-w-md w-full mx-4">
        <CardHeader className="text-center">
          <CardTitle className="text-xl">Undangan Agent</CardTitle>
          <p className="text-sm text-muted-foreground mt-1">
            Anda diundang oleh <span className="text-foreground font-medium">{ownerName}</span> untuk bergabung sebagai agent CS.
          </p>
        </CardHeader>
        <CardContent>
          {user ? (
            <div className="space-y-4 text-center">
              <p className="text-sm text-muted-foreground">Login sebagai <span className="text-foreground">{user.email}</span></p>
              <Button className="w-full glow-blue-sm" onClick={acceptInvite} disabled={accepting}>
                {accepting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <CheckCircle className="h-4 w-4 mr-2" />}
                Terima Undangan
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground text-center">Buat akun untuk menerima undangan</p>
              <div>
                <Label>Nama</Label>
                <Input className="mt-1" value={regName} onChange={e => setRegName(e.target.value)} />
              </div>
              <div>
                <Label>Email</Label>
                <Input className="mt-1" type="email" value={regEmail} onChange={e => setRegEmail(e.target.value)} />
              </div>
              <div>
                <Label>Password</Label>
                <Input className="mt-1" type="password" value={regPassword} onChange={e => setRegPassword(e.target.value)} />
              </div>
              <Button className="w-full glow-blue-sm" onClick={registerAndAccept} disabled={registering}>
                {registering ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <CheckCircle className="h-4 w-4 mr-2" />}
                Daftar & Terima Undangan
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
