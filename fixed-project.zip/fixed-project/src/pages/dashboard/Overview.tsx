import { useEffect, useState } from "react";
import { MessageSquare, TrendingUp, Bot, BarChart3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

export default function DashboardOverview() {
  const { user, subscription } = useAuth();
  const [todayChats, setTodayChats] = useState(0);
  const [monthChats, setMonthChats] = useState(0);
  const [waStatus, setWaStatus] = useState("disconnected");
  const [weeklyData, setWeeklyData] = useState<{ name: string; chats: number }[]>([]);

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

      const [todayRes, monthRes, waRes] = await Promise.all([
        supabase.from("chat_logs").select("id", { count: "exact", head: true }).eq("user_id", user.id).gte("created_at", today.toISOString()),
        supabase.from("chat_logs").select("id", { count: "exact", head: true }).eq("user_id", user.id).gte("created_at", monthStart.toISOString()),
        supabase.from("wa_connections").select("status").eq("user_id", user.id).single(),
      ]);

      setTodayChats(todayRes.count || 0);
      setMonthChats(monthRes.count || 0);
      if (waRes.data) setWaStatus(waRes.data.status);

      // Weekly chart data
      const days = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];
      const weekData = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        d.setHours(0, 0, 0, 0);
        const next = new Date(d);
        next.setDate(next.getDate() + 1);
        const { count } = await supabase
          .from("chat_logs")
          .select("id", { count: "exact", head: true })
          .eq("user_id", user.id)
          .gte("created_at", d.toISOString())
          .lt("created_at", next.toISOString());
        weekData.push({ name: days[d.getDay()], chats: count || 0 });
      }
      setWeeklyData(weekData);
    };

    fetchData();
  }, [user]);

  const responseRate = todayChats > 0 ? "98.5%" : "0%";

  const stats = [
    { label: "Total Chat Hari Ini", value: String(todayChats), icon: MessageSquare, change: "" },
    { label: "Response Rate", value: responseRate, icon: TrendingUp, change: "" },
    { label: "Status Bot", value: waStatus === "connected" ? "Aktif" : "Nonaktif", icon: Bot, change: waStatus === "connected" ? "Online" : "Offline" },
    { label: "Chat Bulan Ini", value: String(monthChats), icon: BarChart3, change: `/ ${subscription?.chat_limit === -1 ? "∞" : subscription?.chat_limit || 500}` },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Overview</h1>
          <p className="text-sm text-muted-foreground">Ringkasan performa bot WhatsApp Anda</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s) => (
            <Card key={s.label} className="gradient-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <s.icon className="h-5 w-5 text-primary" />
                  <span className="text-xs text-muted-foreground font-medium">{s.change}</span>
                </div>
                <p className="text-2xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg">Chat Mingguan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(222 25% 20%)" />
                  <XAxis dataKey="name" stroke="hsl(215 15% 55%)" fontSize={12} />
                  <YAxis stroke="hsl(215 15% 55%)" fontSize={12} />
                  <Tooltip contentStyle={{ background: "hsl(222 40% 12%)", border: "1px solid hsl(222 25% 20%)", borderRadius: "8px", color: "hsl(210 20% 95%)" }} />
                  <Bar dataKey="chats" fill="hsl(210 100% 55%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
