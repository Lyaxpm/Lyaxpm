import { useEffect, useState } from "react";
import { Plus, Trash2, Globe, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface KBItem {
  id: string;
  url: string;
  title: string | null;
  status: string;
  created_at: string;
}

export default function KnowledgeBase() {
  const { user, subscription } = useAuth();
  const [items, setItems] = useState<KBItem[]>([]);
  const [newUrl, setNewUrl] = useState("");
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("knowledge_bases")
      .select("id, url, title, status, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setItems((data as KBItem[]) || []);
        setLoading(false);
      });
  }, [user]);

  const addUrl = async () => {
    if (!newUrl.trim() || !user) return;
    setAdding(true);

    let url = newUrl.trim();
    if (!url.startsWith("http")) url = "https://" + url;

    const { data, error } = await supabase
      .from("knowledge_bases")
      .insert({ user_id: user.id, url, title: new URL(url).hostname, status: "pending" })
      .select()
      .single();

    if (error) {
      toast.error("Gagal menambah URL");
      setAdding(false);
      return;
    }

    setItems([data as KBItem, ...items]);
    setNewUrl("");
    toast.success("URL ditambahkan. Memulai crawling...");
    setAdding(false);

    // Trigger real crawling via edge function
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/crawl-website`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, kb_id: (data as any).id, user_id: user.id }),
      });
      const result = await res.json();
      if (result.success) {
        setItems((prev) =>
          prev.map((i) => (i.id === (data as any).id ? { ...i, status: "ready", title: result.title } : i))
        );
        toast.success("Konten berhasil di-crawl!");
      } else {
        setItems((prev) =>
          prev.map((i) => (i.id === (data as any).id ? { ...i, status: "error" } : i))
        );
        toast.error("Gagal crawl: " + (result.error || "Unknown error"));
      }
    } catch {
      setItems((prev) =>
        prev.map((i) => (i.id === (data as any).id ? { ...i, status: "error" } : i))
      );
      toast.error("Gagal melakukan crawling");
    }
  };

  const deleteItem = async (id: string) => {
    const { error } = await supabase.from("knowledge_bases").delete().eq("id", id);
    if (error) { toast.error("Gagal menghapus"); return; }
    setItems(items.filter((i) => i.id !== id));
    toast.success("URL dihapus dari knowledge base");
  };

  if (subscription && !["pro", "enterprise"].includes(subscription.plan)) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <h2 className="text-xl font-bold mb-2">Fitur Pro</h2>
          <p className="text-muted-foreground mb-4">Upgrade ke paket Pro atau Enterprise untuk mengakses Knowledge Base.</p>
          <Button onClick={() => (window.location.href = "/dashboard/subscription")} className="glow-blue-sm">
            Upgrade Sekarang
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        <div>
          <h1 className="text-2xl font-bold">Knowledge Base</h1>
          <p className="text-sm text-muted-foreground">
            Tambahkan URL website atau bisnis Anda agar bot bisa menjawab berdasarkan konten tersebut
          </p>
        </div>

        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" /> Tambah Website
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form
              onSubmit={(e) => { e.preventDefault(); addUrl(); }}
              className="flex gap-2"
            >
              <Input
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
                placeholder="https://website-anda.com"
                className="flex-1"
              />
              <Button type="submit" disabled={adding} className="glow-blue-sm">
                {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4 mr-2" />}
                {adding ? "Menambah..." : "Tambah"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg">URL Terdaftar ({items.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center text-muted-foreground py-8">Memuat...</div>
            ) : items.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                Belum ada URL. Tambahkan website bisnis Anda di atas.
              </div>
            ) : (
              <div className="space-y-3">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 border border-border">
                    <Globe className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.title || item.url}</p>
                      <p className="text-xs text-muted-foreground truncate">{item.url}</p>
                    </div>
                    <Badge
                      variant={item.status === "ready" ? "default" : item.status === "error" ? "destructive" : "secondary"}
                      className="text-xs flex items-center gap-1"
                    >
                      {item.status === "ready" && <CheckCircle className="h-3 w-3" />}
                      {item.status === "pending" && <Loader2 className="h-3 w-3 animate-spin" />}
                      {item.status === "error" && <AlertCircle className="h-3 w-3" />}
                      {item.status === "ready" ? "Siap" : item.status === "pending" ? "Crawling..." : "Error"}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive"
                      onClick={() => deleteItem(item.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
