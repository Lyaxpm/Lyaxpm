import { useEffect, useState } from "react";
import { Copy, Check, Save, Loader2, Eye } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export default function Widget() {
  const { user } = useAuth();
  const [settings, setSettings] = useState({ widget_color: "#6366f1", widget_position: "bottom-right", widget_enabled: true });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("bot_settings").select("widget_color, widget_position, widget_enabled").eq("user_id", user.id).single()
      .then(({ data }) => {
        if (data) setSettings(data as any);
        setLoading(false);
      });
  }, [user]);

  const saveSettings = async () => {
    if (!user) return;
    setSaving(true);
    await supabase.from("bot_settings").update(settings as any).eq("user_id", user.id);
    toast.success("Pengaturan widget disimpan");
    setSaving(false);
  };

  const embedCode = `<script>window.CHATBOT_CONFIG={userId:"${user?.id || "YOUR_USER_ID"}"}</script>\n<script src="${window.location.origin}/chat-widget.js"></script>`;

  const copyCode = () => {
    navigator.clipboard.writeText(embedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        <div>
          <h1 className="text-2xl font-bold">Chat Widget</h1>
          <p className="text-sm text-muted-foreground">Pasang widget chat AI di website Anda</p>
        </div>

        <Card className="gradient-card border-border">
          <CardHeader><CardTitle className="text-lg">Kode Embed</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Tambahkan kode berikut sebelum tag &lt;/body&gt; di website Anda:</p>
            <div className="relative">
              <pre className="bg-background/80 border border-border rounded-lg p-4 overflow-x-auto text-xs font-mono text-muted-foreground">
                {embedCode}
              </pre>
              <Button variant="ghost" size="icon" className="absolute top-2 right-2 h-8 w-8" onClick={copyCode}>
                {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border">
          <CardHeader><CardTitle className="text-lg">Pengaturan Widget</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Warna Utama</Label>
              <div className="flex gap-2 mt-1">
                <input type="color" value={settings.widget_color || "#6366f1"}
                  onChange={e => setSettings({ ...settings, widget_color: e.target.value })}
                  className="w-10 h-10 rounded border border-border cursor-pointer" />
                <Input value={settings.widget_color || ""} onChange={e => setSettings({ ...settings, widget_color: e.target.value })} className="flex-1" />
              </div>
            </div>
            <div>
              <Label>Posisi</Label>
              <Select value={settings.widget_position || "bottom-right"} onValueChange={v => setSettings({ ...settings, widget_position: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="bottom-right">Kanan Bawah</SelectItem>
                  <SelectItem value="bottom-left">Kiri Bawah</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between">
              <Label>Widget Aktif</Label>
              <Switch checked={settings.widget_enabled} onCheckedChange={v => setSettings({ ...settings, widget_enabled: v })} />
            </div>
            <Button onClick={saveSettings} disabled={saving} className="glow-blue-sm">
              {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
              Simpan
            </Button>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border">
          <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Eye className="h-5 w-5 text-primary" /> Preview</CardTitle></CardHeader>
          <CardContent>
            <div className="border border-border rounded-lg overflow-hidden bg-background" style={{ height: 500 }}>
              <iframe
                srcDoc={`<!DOCTYPE html><html><head><style>body{margin:0;background:#1a1a2e;}</style></head><body>
                  <script>window.CHATBOT_CONFIG={userId:"${user?.id || ""}"}</script>
                  <script src="${window.location.origin}/chat-widget.js"></script>
                </body></html>`}
                className="w-full h-full"
                title="Widget Preview"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
