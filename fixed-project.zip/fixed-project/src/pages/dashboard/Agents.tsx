import { useEffect, useState } from "react";
import { Plus, Trash2, Loader2, Users, Copy, Check } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Agent {
  id: string;
  name: string;
  email: string;
  status: string;
  invite_token: string;
  created_at: string;
}

export default function Agents() {
  const { user } = useAuth();
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialog, setDialog] = useState(false);
  const [newName, setNewName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [saving, setSaving] = useState(false);
  const [inviteLink, setInviteLink] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!user) return;
    (supabase.from("agents" as any).select("*") as any).eq("workspace_owner_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }: any) => { setAgents(data || []); setLoading(false); });
  }, [user]);

  const addAgent = async () => {
    if (!user || !newName.trim() || !newEmail.trim()) return;
    setSaving(true);
    const { data, error } = await (supabase.from("agents" as any).insert({
      workspace_owner_id: user.id,
      name: newName.trim(),
      email: newEmail.trim(),
    } as any) as any).select().single();

    if (error) { toast.error("Gagal menambah agent"); setSaving(false); return; }
    const agent = data as Agent;
    setAgents([agent, ...agents]);
    setInviteLink(`${window.location.origin}/invite?token=${agent.invite_token}`);
    setNewName(""); setNewEmail("");
    toast.success("Agent ditambahkan");
    setSaving(false);
  };

  const deleteAgent = async (id: string) => {
    await (supabase.from("agents" as any) as any).delete().eq("id", id);
    setAgents(agents.filter(a => a.id !== id));
    toast.success("Agent dihapus");
  };

  const copyLink = () => {
    navigator.clipboard.writeText(inviteLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Agent</h1>
            <p className="text-sm text-muted-foreground">Undang dan kelola agent CS Anda</p>
          </div>
          <Button onClick={() => { setDialog(true); setInviteLink(""); }} className="glow-blue-sm">
            <Plus className="h-4 w-4 mr-2" /> Tambah Agent
          </Button>
        </div>

        <Card className="gradient-card border-border">
          <CardContent className="p-0">
            {loading ? (
              <div className="p-8 text-center text-muted-foreground">Memuat...</div>
            ) : agents.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-3 text-muted-foreground/50" />
                <p>Belum ada agent. Undang agent pertama Anda.</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {agents.map(a => (
                  <div key={a.id} className="p-4 flex items-center gap-4">
                    <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
                      {a.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium">{a.name}</p>
                      <p className="text-xs text-muted-foreground">{a.email}</p>
                    </div>
                    <Badge variant={a.status === "active" ? "default" : "secondary"} className="text-xs">
                      {a.status === "active" ? "Aktif" : "Pending"}
                    </Badge>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteAgent(a.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>Tambah Agent Baru</DialogTitle></DialogHeader>
          {inviteLink ? (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Agent berhasil ditambahkan! Kirimkan link undangan berikut:</p>
              <div className="flex gap-2">
                <Input value={inviteLink} readOnly className="text-xs" />
                <Button variant="outline" size="icon" onClick={copyLink}>
                  {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              <Button className="w-full" variant="outline" onClick={() => setDialog(false)}>Tutup</Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <Label>Nama Agent</Label>
                <Input className="mt-1" value={newName} onChange={e => setNewName(e.target.value)} placeholder="Nama agent" />
              </div>
              <div>
                <Label>Email Agent</Label>
                <Input className="mt-1" value={newEmail} onChange={e => setNewEmail(e.target.value)} placeholder="agent@email.com" />
              </div>
              <Button className="w-full glow-blue-sm" onClick={addAgent} disabled={saving || !newName.trim() || !newEmail.trim()}>
                {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Plus className="h-4 w-4 mr-2" />}
                Tambah & Buat Link Undangan
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
