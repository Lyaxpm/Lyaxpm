import { useEffect, useState, useRef } from "react";
import { Send, Bot as BotIcon, User, Phone, MessageCircle, Hash, Globe, Search, Users } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { formatDistanceToNow } from "date-fns";
import { id as idLocale } from "date-fns/locale";
import { toast } from "sonner";

interface ChatSession {
  id: string;
  contact_number: string;
  customer_name: string | null;
  channel: string;
  message_preview: string | null;
  status: string;
  handler: string;
  assigned_agent_id: string | null;
  created_at: string;
}

interface Message {
  id: string;
  sender_type: string;
  sender_name: string | null;
  content: string;
  created_at: string;
  is_read: boolean;
}

interface Agent {
  id: string;
  name: string;
  agent_user_id: string | null;
}

const channelIcon = (ch: string) => {
  switch (ch) {
    case "whatsapp": return <Phone className="h-4 w-4 text-green-500" />;
    case "telegram": return <MessageCircle className="h-4 w-4 text-blue-400" />;
    case "discord": return <Hash className="h-4 w-4 text-indigo-400" />;
    default: return <Globe className="h-4 w-4 text-orange-400" />;
  }
};

export default function LiveChat() {
  const { user } = useAuth();
  const [workspaceUserId, setWorkspaceUserId] = useState<string | null>(null);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [selectedSession, setSelectedSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [tab, setTab] = useState("all");
  const [search, setSearch] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const [myAgentId, setMyAgentId] = useState<string | null>(null);

  // Determine workspace
  useEffect(() => {
    if (!user) return;
    (supabase.from("agents" as any).select("id, workspace_owner_id") as any)
      .eq("agent_user_id", user.id).eq("status", "active").limit(1)
      .then(({ data }: any) => {
        if (data && data.length > 0) {
          setWorkspaceUserId(data[0].workspace_owner_id);
          setMyAgentId(data[0].id);
        } else {
          setWorkspaceUserId(user.id);
        }
      });
  }, [user]);

  // Fetch sessions + agents
  useEffect(() => {
    if (!workspaceUserId) return;
    const fetchAll = async () => {
      const [sessRes, agentRes] = await Promise.all([
        supabase.from("chat_logs").select("*").eq("user_id", workspaceUserId)
          .order("created_at", { ascending: false }).limit(100),
        (supabase.from("agents" as any).select("id, name, agent_user_id") as any)
          .eq("workspace_owner_id", workspaceUserId).eq("status", "active"),
      ]);
      setSessions((sessRes.data as any[]) || []);
      setAgents((agentRes.data as any[]) || []);
      setLoading(false);
    };
    fetchAll();

    const channel = supabase.channel("inbox-sessions")
      .on("postgres_changes", { event: "*", schema: "public", table: "chat_logs", filter: `user_id=eq.${workspaceUserId}` },
        () => { fetchAll(); })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [workspaceUserId]);

  // Fetch messages
  useEffect(() => {
    if (!selectedSession) return;
    const fetchMsgs = async () => {
      const { data } = await supabase.from("chat_messages").select("*")
        .eq("chat_log_id", selectedSession.id).order("created_at", { ascending: true });
      setMessages((data as any[]) || []);
      // Mark as read
      await (supabase.from("chat_messages").update({ is_read: true } as any) as any)
        .eq("chat_log_id", selectedSession.id).eq("is_read", false);
    };
    fetchMsgs();

    const channel = supabase.channel(`chat-${selectedSession.id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages", filter: `chat_log_id=eq.${selectedSession.id}` },
        (payload) => { setMessages(prev => [...prev, payload.new as Message]); })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [selectedSession]);

  useEffect(() => { scrollRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedSession || !workspaceUserId) return;
    try {
      await supabase.functions.invoke("send-message", {
        body: { chat_log_id: selectedSession.id, message: newMessage, user_id: workspaceUserId },
      });
      setNewMessage("");
    } catch { toast.error("Gagal mengirim pesan"); }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const assignAgent = async (agentId: string) => {
    if (!selectedSession) return;
    const val = agentId === "none" ? null : agentId;
    await supabase.from("chat_logs").update({ assigned_agent_id: val } as any).eq("id", selectedSession.id);
    setSelectedSession({ ...selectedSession, assigned_agent_id: val });
  };

  const updateStatus = async (status: string) => {
    if (!selectedSession) return;
    await supabase.from("chat_logs").update({ status }).eq("id", selectedSession.id);
    setSelectedSession({ ...selectedSession, status });
  };

  const takeOver = async () => {
    if (!myAgentId || !selectedSession) return;
    await supabase.from("chat_logs").update({ assigned_agent_id: myAgentId, handler: "Human" } as any).eq("id", selectedSession.id);
    setSelectedSession({ ...selectedSession, assigned_agent_id: myAgentId, handler: "Human" });
    toast.success("Chat diambil alih");
  };

  const filtered = sessions.filter(s => {
    if (search) {
      const q = search.toLowerCase();
      if (!(s.customer_name?.toLowerCase().includes(q) || s.contact_number.toLowerCase().includes(q))) return false;
    }
    if (tab === "all") return true;
    if (["whatsapp", "telegram", "discord", "widget"].includes(tab)) return s.channel === tab;
    if (tab === "unassigned") return !s.assigned_agent_id;
    if (tab === "mine") return s.assigned_agent_id === myAgentId;
    return true;
  });

  return (
    <DashboardLayout>
      <div className="h-[calc(100vh-8rem)] flex gap-4">
        {/* Left */}
        <Card className="gradient-card border-border w-80 flex-shrink-0 flex flex-col">
          <div className="p-3 border-b border-border space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Cari..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-8 text-xs" />
            </div>
            <Tabs value={tab} onValueChange={setTab}>
              <TabsList className="w-full h-auto flex-wrap bg-secondary/50 p-0.5">
                <TabsTrigger value="all" className="text-[10px] px-2 py-1">Semua</TabsTrigger>
                <TabsTrigger value="whatsapp" className="text-[10px] px-2 py-1">WA</TabsTrigger>
                <TabsTrigger value="telegram" className="text-[10px] px-2 py-1">TG</TabsTrigger>
                <TabsTrigger value="discord" className="text-[10px] px-2 py-1">DC</TabsTrigger>
                <TabsTrigger value="widget" className="text-[10px] px-2 py-1">Web</TabsTrigger>
                <TabsTrigger value="unassigned" className="text-[10px] px-2 py-1">Belum</TabsTrigger>
                {myAgentId && <TabsTrigger value="mine" className="text-[10px] px-2 py-1">Saya</TabsTrigger>}
              </TabsList>
            </Tabs>
          </div>
          <ScrollArea className="flex-1">
            {loading ? (
              <div className="p-4 text-center text-muted-foreground text-sm">Memuat...</div>
            ) : filtered.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground text-sm">Tidak ada percakapan</div>
            ) : (
              <div className="divide-y divide-border">
                {filtered.map(s => (
                  <button key={s.id} onClick={() => setSelectedSession(s)}
                    className={`w-full text-left p-3 hover:bg-secondary/30 transition-colors ${selectedSession?.id === s.id ? "bg-secondary/50" : ""}`}>
                    <div className="flex items-center gap-2 mb-1">
                      {channelIcon(s.channel)}
                      <span className="text-sm font-medium truncate flex-1">{s.customer_name || s.contact_number}</span>
                      <Badge variant={s.status === "escalated" ? "destructive" : s.status === "active" ? "default" : "secondary"} className="text-[10px] px-1.5 py-0">
                        {s.status === "escalated" ? "Eskalasi" : s.status === "active" ? "Aktif" : "Selesai"}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground truncate">{s.message_preview?.substring(0, 50)}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">
                      {formatDistanceToNow(new Date(s.created_at), { addSuffix: true, locale: idLocale })}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </ScrollArea>
        </Card>

        {/* Right */}
        <Card className="gradient-card border-border flex-1 flex flex-col min-w-0">
          {selectedSession ? (
            <>
              <div className="p-3 border-b border-border flex items-center gap-3 flex-wrap">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  {channelIcon(selectedSession.channel)}
                  <div className="min-w-0">
                    <p className="font-medium text-sm truncate">{selectedSession.customer_name || selectedSession.contact_number}</p>
                    <p className="text-[10px] text-muted-foreground">{selectedSession.contact_number}</p>
                  </div>
                  <Badge variant="outline" className="text-[10px] capitalize">{selectedSession.channel}</Badge>
                </div>
                <Select value={selectedSession.assigned_agent_id || "none"} onValueChange={assignAgent}>
                  <SelectTrigger className="w-36 h-8 text-xs"><SelectValue placeholder="Assign" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Tidak Diassign</SelectItem>
                    {agents.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={selectedSession.status} onValueChange={updateStatus}>
                  <SelectTrigger className="w-28 h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Aktif</SelectItem>
                    <SelectItem value="resolved">Selesai</SelectItem>
                    <SelectItem value="escalated">Dieskalasi</SelectItem>
                  </SelectContent>
                </Select>
                {myAgentId && (
                  <Button size="sm" variant="outline" className="text-xs h-8" onClick={takeOver}>
                    <Users className="h-3 w-3 mr-1" /> Ambil Alih
                  </Button>
                )}
              </div>
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-3">
                  {messages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.sender_type === "customer" ? "justify-start" : "justify-end"}`}>
                      <div className={`max-w-[70%] rounded-2xl px-4 py-2 text-sm ${
                        msg.sender_type === "customer" ? "bg-muted"
                        : msg.sender_type === "bot" ? "bg-primary/20 border border-primary/30"
                        : "bg-accent/20 border border-accent/30"
                      }`}>
                        <div className="flex items-center gap-1 mb-1">
                          {msg.sender_type === "bot" && <BotIcon className="h-3 w-3 text-primary" />}
                          {msg.sender_type === "customer" && <User className="h-3 w-3" />}
                          <span className="text-[10px] opacity-70">
                            {msg.sender_type === "bot" ? "AI" : msg.sender_type === "agent" ? (msg.sender_name || "Agent") : (msg.sender_name || "Customer")}
                          </span>
                        </div>
                        <p className="whitespace-pre-wrap">{msg.content}</p>
                        <p className="text-[10px] opacity-50 mt-1">
                          {new Date(msg.created_at).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={scrollRef} />
                </div>
              </ScrollArea>
              <div className="p-3 border-t border-border">
                <div className="flex gap-2">
                  <Textarea value={newMessage} onChange={e => setNewMessage(e.target.value)} onKeyDown={handleKeyDown}
                    placeholder="Ketik pesan... (Enter=kirim, Shift+Enter=baris baru)" className="flex-1 min-h-[40px] max-h-24 resize-none text-sm" rows={1} />
                  <Button size="icon" className="glow-blue-sm self-end" onClick={sendMessage}><Send className="h-4 w-4" /></Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm">Pilih percakapan untuk mulai</div>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}
