import { useEffect, useState, useRef } from "react";
import { Wifi, WifiOff, QrCode, Smartphone, RefreshCw, Loader2, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type ConnStatus = "idle" | "connecting" | "qr" | "connected" | "error";

export default function WAConnection() {
  const { user } = useAuth();
  const [status, setStatus] = useState<ConnStatus>("idle");
  const [phoneNumber, setPhoneNumber] = useState<string | null>(null);
  const [connectedAt, setConnectedAt] = useState<string | null>(null);
  const [qrImage, setQrImage] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(60);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stopPolling = () => {
    if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
    if (countdownRef.current) { clearInterval(countdownRef.current); countdownRef.current = null; }
  };

  useEffect(() => {
    if (!user) return;
    supabase.from("wa_connections").select("*").eq("user_id", user.id).single()
      .then(({ data }) => {
        if (data) {
          const d = data as any;
          if (d.status === "connected") {
            setStatus("connected");
            setPhoneNumber(d.phone_number);
            setConnectedAt(d.connected_at);
          }
        }
        setLoading(false);
      });
    return () => stopPolling();
  }, [user]);

  const startPolling = () => {
    stopPolling();
    setCountdown(60);

    countdownRef.current = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          stopPolling();
          setStatus("idle");
          setQrImage(null);
          toast.warning("QR Code kadaluarsa. Silakan coba lagi.");
          return 60;
        }
        return prev - 1;
      });
    }, 1000);

    pollRef.current = setInterval(async () => {
      try {
        const { data, error: fnErr } = await supabase.functions.invoke("gowa-qr");
        if (fnErr || !data) return;
        if (data.status === "connected") {
          stopPolling();
          setStatus("connected");
          setPhoneNumber(data.phone_number);
          setConnectedAt(new Date().toISOString());
          setQrImage(null);
          toast.success("WhatsApp berhasil terhubung! 🎉");
        } else if (data.status === "qr" && data.qr_image) {
          setQrImage(data.qr_image);
        }
      } catch { /* ignore */ }
    }, 3000);
  };

  const startConnection = async () => {
    if (!user) return;
    setError(null);
    setStatus("connecting");
    setQrImage(null);
    try {
      const { data, error: fnErr } = await supabase.functions.invoke("gowa-create-instance");
      if (fnErr) throw new Error(fnErr.message);
      if (data?.error) throw new Error(data.error);
      setStatus("qr");
      startPolling();
    } catch (e: any) {
      setError(e.message);
      setStatus("error");
    }
  };

  const disconnect = async () => {
    if (!user) return;
    stopPolling();
    try {
      await supabase.functions.invoke("gowa-delete-instance");
      setStatus("idle");
      setPhoneNumber(null);
      setConnectedAt(null);
      setQrImage(null);
      toast.success("Koneksi WhatsApp diputus");
    } catch (e: any) {
      toast.error("Gagal: " + e.message);
    }
  };

  if (loading) return (
    <DashboardLayout>
      <div className="flex items-center justify-center p-16">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    </DashboardLayout>
  );

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-2xl">
        <div>
          <h1 className="text-2xl font-bold">Koneksi WhatsApp</h1>
          <p className="text-sm text-muted-foreground">Hubungkan nomor WhatsApp bisnis Anda ke platform</p>
        </div>

        <Card className="gradient-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Status Koneksi</CardTitle>
              <Badge variant={status === "connected" ? "default" : "destructive"} className="gap-1">
                {status === "connected" ? <><Wifi className="h-3 w-3" /> Terhubung</>
                  : (status === "connecting" || status === "qr") ? <><Loader2 className="h-3 w-3 animate-spin" /> Menghubungkan...</>
                  : <><WifiOff className="h-3 w-3" /> Terputus</>}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {status === "connected" ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-4 bg-green-500/10 rounded-lg border border-green-500/30">
                  <Smartphone className="h-10 w-10 text-green-500" />
                  <div>
                    <p className="font-semibold">{phoneNumber}</p>
                    <p className="text-sm text-muted-foreground">
                      Terhubung sejak {connectedAt ? new Date(connectedAt).toLocaleString("id-ID") : "-"}
                    </p>
                  </div>
                </div>
                <Button variant="destructive" className="w-full" onClick={disconnect}>
                  <WifiOff className="h-4 w-4 mr-2" /> Putuskan Koneksi
                </Button>
              </div>
            ) : status === "qr" ? (
              <div className="space-y-4">
                <Alert>
                  <QrCode className="h-4 w-4" />
                  <AlertDescription>
                    Buka WhatsApp → titik tiga → <strong>Perangkat Tertaut</strong> → <strong>Tautkan Perangkat</strong> → Scan QR
                  </AlertDescription>
                </Alert>
                <div className="flex flex-col items-center gap-4 py-4">
                  {qrImage ? (
                    <div className="relative">
                      <img src={qrImage} alt="QR Code" className="w-64 h-64 border-2 border-border rounded-lg" />
                      <div className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs font-bold rounded-full w-8 h-8 flex items-center justify-center">
                        {countdown}
                      </div>
                    </div>
                  ) : (
                    <div className="w-64 h-64 border-2 border-dashed border-border rounded-lg flex items-center justify-center">
                      <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  )}
                  <p className="text-sm text-muted-foreground">QR kadaluarsa dalam <strong>{countdown} detik</strong></p>
                  <Button variant="outline" size="sm" onClick={() => { stopPolling(); setQrImage(null); startPolling(); }}>
                    <RefreshCw className="h-4 w-4 mr-2" /> Refresh QR
                  </Button>
                </div>
                <Button variant="ghost" className="w-full" onClick={() => { stopPolling(); setStatus("idle"); setQrImage(null); }}>
                  Batal
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                <div className="p-4 bg-muted/50 rounded-lg text-sm text-muted-foreground space-y-1">
                  <p className="font-medium text-foreground mb-2">Cara menghubungkan:</p>
                  <p>1. Klik tombol "Mulai Koneksi" di bawah</p>
                  <p>2. QR Code akan tampil — scan dengan WhatsApp di ponsel</p>
                  <p>3. WhatsApp → titik tiga → Perangkat Tertaut → Tautkan Perangkat</p>
                  <p>4. Gunakan nomor WA khusus bisnis, bukan nomor pribadi</p>
                </div>
                <Button className="w-full glow-blue-sm" onClick={startConnection} disabled={status === "connecting"}>
                  {status === "connecting"
                    ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Mempersiapkan...</>
                    : <><QrCode className="h-4 w-4 mr-2" /> Mulai Koneksi WhatsApp</>}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="gradient-card border-border">
          <CardHeader><CardTitle className="text-sm font-medium">Informasi Penting</CardTitle></CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-1.5">
            <p>• WhatsApp yang terhubung akan menerima dan membalas pesan otomatis via AI</p>
            <p>• Nomor ini tidak bisa dibuka di WA Web selama terhubung ke platform</p>
            <p>• Gunakan nomor WA khusus bisnis (bukan nomor pribadi)</p>
            <p>• Sesi tetap aktif selama server GOWA menyala</p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
