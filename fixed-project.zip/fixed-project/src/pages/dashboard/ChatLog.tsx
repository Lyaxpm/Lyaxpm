import { useEffect, useState } from "react";
import { MessageSquare, Bot as BotIcon, User } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { formatDistanceToNow } from "date-fns";
import { id as idLocale } from "date-fns/locale";

interface ChatLog {
  id: string;
  contact_number: string;
  message_preview: string | null;
  handler: string;
  status: string;
  created_at: string;
}

export default function ChatLog() {
  const { user } = useAuth();
  const [chats, setChats] = useState<ChatLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("chat_logs")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(50)
      .then(({ data }) => {
        setChats((data as ChatLog[]) || []);
        setLoading(false);
      });
  }, [user]);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Chat Log</h1>
          <p className="text-sm text-muted-foreground">Riwayat percakapan WhatsApp</p>
        </div>
        <Card className="gradient-card border-border">
          <CardContent className="p-0">
            {loading ? (
              <div className="p-8 text-center text-muted-foreground">Memuat...</div>
            ) : chats.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">Belum ada riwayat chat</div>
            ) : (
              <div className="divide-y divide-border">
                {chats.map((chat) => (
                  <div key={chat.id} className="flex items-center gap-4 p-4 hover:bg-secondary/30 transition-colors">
                    <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                      <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">{chat.contact_number}</span>
                        <Badge variant={chat.handler === "AI" ? "default" : "secondary"} className="text-xs px-2 py-0">
                          {chat.handler === "AI" ? <><BotIcon className="h-3 w-3 mr-1" />AI</> : <><User className="h-3 w-3 mr-1" />Human</>}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{chat.message_preview}</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(chat.created_at), { addSuffix: true, locale: idLocale })}
                      </p>
                      <Badge variant={chat.status === "resolved" ? "outline" : "destructive"} className="text-xs mt-1">
                        {chat.status === "resolved" ? "Selesai" : "Eskalasi"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
