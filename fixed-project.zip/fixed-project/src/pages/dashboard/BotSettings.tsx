import { useState, useEffect } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import DashboardLayout from "@/components/DashboardLayout";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

interface FaqItem { id: string; question: string; answer: string; }

export default function BotSettings() {
  const { user, subscription } = useAuth();
  const [botName, setBotName] = useState("CS Bot");
  const [welcomeMsg, setWelcomeMsg] = useState("Halo! Selamat datang. Ada yang bisa saya bantu?");
  const [tone, setTone] = useState("friendly");
  const [faqs, setFaqs] = useState<FaqItem[]>([]);
  const [newQ, setNewQ] = useState("");
  const [newA, setNewA] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      supabase.from("bot_settings").select("*").eq("user_id", user.id).single(),
      supabase.from("faq_items").select("*").eq("user_id", user.id).order("created_at"),
    ]).then(([botRes, faqRes]) => {
      if (botRes.data) {
        const d = botRes.data as any;
        setBotName(d.bot_name);
        setWelcomeMsg(d.welcome_message);
        setTone(d.tone);
      }
      if (faqRes.data) setFaqs(faqRes.data as FaqItem[]);
    });
  }, [user]);

  const saveSettings = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from("bot_settings")
      .update({ bot_name: botName, welcome_message: welcomeMsg, tone })
      .eq("user_id", user.id);
    setSaving(false);
    if (error) toast.error("Gagal menyimpan");
    else toast.success("Pengaturan disimpan!");
  };

  const addFaq = async () => {
    if (!newQ || !newA || !user) return;
    const { data, error } = await supabase
      .from("faq_items")
      .insert({ user_id: user.id, question: newQ, answer: newA })
      .select()
      .single();
    if (error) { toast.error("Gagal menambah FAQ"); return; }
    setFaqs([...faqs, data as FaqItem]);
    setNewQ(""); setNewA("");
    toast.success("FAQ ditambahkan");
  };

  const deleteFaq = async (id: string) => {
    const { error } = await supabase.from("faq_items").delete().eq("id", id);
    if (error) { toast.error("Gagal menghapus"); return; }
    setFaqs(faqs.filter((f) => f.id !== id));
    toast.success("FAQ dihapus");
  };

  if (subscription && !["pro", "enterprise"].includes(subscription.plan)) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <h2 className="text-xl font-bold mb-2">Fitur Pro</h2>
          <p className="text-muted-foreground mb-4">Upgrade ke paket Pro atau Enterprise untuk mengakses Bot Settings.</p>
          <Button onClick={() => window.location.href = "/dashboard/subscription"} className="glow-blue-sm">Upgrade Sekarang</Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        <div>
          <h1 className="text-2xl font-bold">Bot Settings</h1>
          <p className="text-sm text-muted-foreground">Konfigurasi bot AI WhatsApp Anda</p>
        </div>

        <Card className="gradient-card border-border">
          <CardHeader><CardTitle className="text-lg">Pengaturan Umum</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Nama Bot</Label>
              <Input value={botName} onChange={(e) => setBotName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Pesan Sambutan</Label>
              <Textarea value={welcomeMsg} onChange={(e) => setWelcomeMsg(e.target.value)} rows={3} />
            </div>
            <div className="space-y-2">
              <Label>Gaya Bahasa</Label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="formal">Formal</SelectItem>
                  <SelectItem value="friendly">Ramah (Friendly)</SelectItem>
                  <SelectItem value="casual">Santai (Casual)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="glow-blue-sm" onClick={saveSettings} disabled={saving}>
              {saving ? "Menyimpan..." : "Simpan Pengaturan"}
            </Button>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border">
          <CardHeader><CardTitle className="text-lg">FAQ Manager</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {faqs.map((faq) => (
              <div key={faq.id} className="p-4 rounded-lg bg-secondary/30 border border-border">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">{faq.question}</p>
                    <p className="text-sm text-muted-foreground">{faq.answer}</p>
                  </div>
                  <Button variant="ghost" size="icon" className="text-destructive h-8 w-8" onClick={() => deleteFaq(faq.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
            <div className="border-t border-border pt-4 space-y-3">
              <Input placeholder="Pertanyaan baru..." value={newQ} onChange={(e) => setNewQ(e.target.value)} />
              <Textarea placeholder="Jawaban..." value={newA} onChange={(e) => setNewA(e.target.value)} rows={2} />
              <Button variant="outline" onClick={addFaq}><Plus className="h-4 w-4 mr-2" /> Tambah FAQ</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
