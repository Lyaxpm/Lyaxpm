import { useState } from "react";
import { ArrowRight, ExternalLink, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const planDetails: Record<string, { name: string; price: number; chatLimit: number; waLimit: number }> = {
  starter: { name: "Starter", price: 500000, chatLimit: 500, waLimit: 1 },
  pro: { name: "Pro", price: 1200000, chatLimit: -1, waLimit: 1 },
  enterprise: { name: "Enterprise", price: 2500000, chatLimit: -1, waLimit: 3 },
};

const paymentMethods = [
  { code: "QRIS", name: "QRIS" },
  { code: "BRIVA", name: "BRI Virtual Account" },
  { code: "BCAVA", name: "BCA Virtual Account" },
  { code: "BNIVA", name: "BNI Virtual Account" },
  { code: "MANDIRIVA", name: "Mandiri Virtual Account" },
  { code: "OVO", name: "OVO" },
  { code: "DANA", name: "DANA" },
  { code: "SHOPEEPAY", name: "ShopeePay" },
];

const upgrades = [
  { from: "starter", to: "pro" as const, label: "Pro", desc: "Unlimited chat, custom AI persona, Live Chat CS", price: 1200000 },
  { from: "starter", to: "enterprise" as const, label: "Enterprise", desc: "3 nomor WA, unlimited chat, widget, priority support", price: 2500000 },
  { from: "pro", to: "enterprise" as const, label: "Enterprise", desc: "3 nomor WA, priority support, custom integration, widget", price: 2500000 },
];

export default function Subscription() {
  const { user, subscription, refreshSubscription } = useAuth();
  const plan = subscription?.plan || "starter";
  const details = planDetails[plan];
  const [paymentDialog, setPaymentDialog] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [selectedMethod, setSelectedMethod] = useState("QRIS");
  const [processing, setProcessing] = useState(false);
  const [checkoutUrl, setCheckoutUrl] = useState<string | null>(null);

  const handleUpgrade = (toPlan: string) => {
    setSelectedPlan(toPlan);
    setCheckoutUrl(null);
    setPaymentDialog(true);
  };

  const processPayment = async () => {
    if (!selectedPlan || !user) return;
    setProcessing(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/tripay-create`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session?.access_token}`,
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({ plan: selectedPlan, method: selectedMethod }),
      });

      const result = await res.json();

      if (!res.ok || !result.success) {
        toast.error(result.error || "Gagal membuat pembayaran");
        setProcessing(false);
        return;
      }

      setCheckoutUrl(result.data.checkout_url);
      toast.success("Pembayaran berhasil dibuat! Silakan selesaikan pembayaran.");
    } catch (err) {
      toast.error("Terjadi kesalahan saat memproses pembayaran");
    }
    setProcessing(false);
  };

  const availableUpgrades = upgrades.filter((u) => u.from === plan);
  const chatUsagePercent = subscription
    ? subscription.chat_limit === -1 ? 30 : Math.min(100, (subscription.chats_used / subscription.chat_limit) * 100)
    : 0;

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        <div>
          <h1 className="text-2xl font-bold">Langganan</h1>
          <p className="text-sm text-muted-foreground">Kelola paket dan penggunaan Anda</p>
        </div>

        <Card className="gradient-card border-border border-primary/30">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Paket Saat Ini</CardTitle>
              <Badge className="bg-primary/20 text-primary border-primary/30 capitalize">{details?.name}</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-baseline gap-2">
              <span className="text-sm text-muted-foreground">Rp</span>
              <span className="text-3xl font-bold">{(subscription?.price || details?.price || 0).toLocaleString("id-ID")}</span>
              <span className="text-muted-foreground">/bulan</span>
            </div>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Penggunaan Chat</span>
                  <span>{subscription?.chats_used || 0} / {subscription?.chat_limit === -1 ? "Unlimited" : subscription?.chat_limit || 500}</span>
                </div>
                <Progress value={chatUsagePercent} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Nomor WA Aktif</span>
                  <span>1 / {subscription?.wa_limit || 1}</span>
                </div>
                <Progress value={100 / (subscription?.wa_limit || 1)} className="h-2" />
              </div>
            </div>
            <div className="text-sm text-muted-foreground">
              Perpanjangan berikutnya: <span className="text-foreground font-medium">
                {subscription?.expires_at ? new Date(subscription.expires_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }) : "-"}
              </span>
            </div>
          </CardContent>
        </Card>

        {availableUpgrades.length > 0 && (
          <Card className="gradient-card border-border">
            <CardHeader><CardTitle className="text-lg">Upgrade Paket</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              {availableUpgrades.map((u) => (
                <div key={u.to} className="p-4 rounded-lg bg-secondary/30 border border-border flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{u.label}</p>
                    <p className="text-sm text-muted-foreground">{u.desc}</p>
                    <p className="text-lg font-bold mt-1">Rp {u.price.toLocaleString("id-ID")}<span className="text-sm font-normal text-muted-foreground">/bulan</span></p>
                  </div>
                  <Button className="glow-blue-sm" onClick={() => handleUpgrade(u.to)}>
                    Upgrade <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Payment Dialog */}
      <Dialog open={paymentDialog} onOpenChange={setPaymentDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Pembayaran - Paket {selectedPlan ? planDetails[selectedPlan]?.name : ""}</DialogTitle>
          </DialogHeader>
          {!checkoutUrl ? (
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Total Pembayaran</p>
                <p className="text-2xl font-bold">
                  Rp {selectedPlan ? planDetails[selectedPlan]?.price.toLocaleString("id-ID") : 0}
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium">Metode Pembayaran</p>
                <Select value={selectedMethod} onValueChange={setSelectedMethod}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map((m) => (
                      <SelectItem key={m.code} value={m.code}>{m.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button className="w-full glow-blue-sm" onClick={processPayment} disabled={processing}>
                {processing ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Memproses...</> : "Bayar Sekarang"}
              </Button>
            </div>
          ) : (
            <div className="space-y-4 text-center">
              <div className="w-16 h-16 mx-auto bg-primary/20 rounded-full flex items-center justify-center">
                <ExternalLink className="h-8 w-8 text-primary" />
              </div>
              <p className="text-sm text-muted-foreground">
                Pembayaran berhasil dibuat. Klik tombol di bawah untuk menyelesaikan pembayaran.
              </p>
              <Button className="w-full glow-blue-sm" onClick={() => window.open(checkoutUrl, "_blank")}>
                <ExternalLink className="h-4 w-4 mr-2" /> Buka Halaman Pembayaran
              </Button>
              <p className="text-xs text-muted-foreground">
                Setelah pembayaran berhasil, paket Anda akan otomatis terupgrade.
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
