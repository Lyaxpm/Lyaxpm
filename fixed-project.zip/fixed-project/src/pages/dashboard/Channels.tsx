import { useEffect, useState } from "react";
import { Loader2, Phone, MessageCircle, Hash, Wifi, WifiOff, ExternalLink } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ChannelConfig {
  id?: string;
  channel: string;
  is_active: boolean;
  telegram_bot_token?: string;
  telegram_bot_username?: string;
  discord_bot_token?: string;
  discord_guild_id?: string;
  discord_channel_id?: string;
}

export default function Channels() {
  const { user } = useAuth();
  const [waStatus, setWaStatus] = useState("disconnected");
  const [waPhone, setWaPhone] = useState("");
  const [telegram, setTelegram] = useState<ChannelConfig | null>(null);
  const [discord, setDiscord] = useState<ChannelConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [tgToken, setTgToken] = useState("");
  const [tgUsername, setTgUsername] = useState("");
  const [tgSaving, setTgSaving] = useState(false);
  const [dcToken, setDcToken] = useState("");
  const [dcGuild, setDcGuild] = useState("");
  const [dcChannel, setDcChannel] = useState("");
  const [dcSaving, setDcSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      supabase.from("wa_connections").select("status, phone_number").eq("user_id", user.id).single(),
      (supabase.from("channel_configs" as any).select("*") as any).eq("user_id", user.id),
    ]).then(([waRes, chRes]: any[]) => {
      if (waRes.data) { setWaStatus(waRes.data.status); setWaPhone(waRes.data.phone_number || ""); }
      const channels = (chRes.data as any[]) || [];
      setTelegram(channels.find((c: any) => c.channel === "telegram") || null);
      setDiscord(channels.find((c: any) => c.channel === "discord") || null);
      setLoading(false);
    });
  }, [user]);

  const disconnectWa = async () => {
    if (!user) return;
    await supabase.from("wa_connections").update({ status: "disconnected" }).eq("user_id", user.id);
    setWaStatus("disconnected");
    toast.success("WhatsApp terputus");
  };

  const activateTelegram = async () => {
    if (!user || !tgToken.trim()) return;
    setTgSaving(true);
    try {
      const { data: cfg } = await (supabase.from("channel_configs" as any).upsert({
        user_id: user.id, channel: "telegram", is_active: true,
        telegram_bot_token: tgToken.trim(), telegram_bot_username: tgUsername.trim(),
      } as any, { onConflict: "user_id,channel" }) as any).select().single();

      const res = await supabase.functions.invoke("setup-telegram-webhook", {
        body: { user_id: user.id, bot_token: tgToken.trim() },
      });
      if (res.error) throw new Error(res.error.message);
      setTelegram(cfg as any);
      toast.success("Telegram berhasil diaktifkan!");
    } catch (e: any) { toast.error("Gagal mengaktifkan Telegram: " + e.message); }
    setTgSaving(false);
  };

  const deactivateTelegram = async () => {
    if (!telegram?.id) return;
    await (supabase.from("channel_configs" as any) as any).update({ is_active: false }).eq("id", telegram.id);
    setTelegram({ ...telegram, is_active: false });
    toast.success("Telegram dinonaktifkan");
  };

  const activateDiscord = async () => {
    if (!user || !dcToken.trim() || !dcGuild.trim() || !dcChannel.trim()) return;
    setDcSaving(true);
    try {
      const { data: cfg } = await (supabase.from("channel_configs" as any).upsert({
        user_id: user.id, channel: "discord", is_active: true,
        discord_bot_token: dcToken.trim(), discord_guild_id: dcGuild.trim(), discord_channel_id: dcChannel.trim(),
      } as any, { onConflict: "user_id,channel" }) as any).select().single();

      await supabase.functions.invoke("discord-bot-manager", {
        body: { action: "start", user_id: user.id, discord_bot_token: dcToken.trim(), guild_id: dcGuild.trim(), channel_id: dcChannel.trim() },
      });
      setDiscord(cfg as any);
      toast.success("Discord berhasil diaktifkan!");
    } catch (e: any) { toast.error("Gagal mengaktifkan Discord: " + e.message); }
    setDcSaving(false);
  };

  const deactivateDiscord = async () => {
    if (!discord?.id) return;
    await supabase.functions.invoke("discord-bot-manager", { body: { action: "stop", user_id: user?.id } });
    await (supabase.from("channel_configs" as any) as any).update({ is_active: false }).eq("id", discord.id);
    setDiscord({ ...discord, is_active: false });
    toast.success("Discord dinonaktifkan");
  };

  if (loading) return (
    <DashboardLayout><div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div></DashboardLayout>
  );

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        <div>
          <h1 className="text-2xl font-bold">Channel Bot</h1>
          <p className="text-sm text-muted-foreground">Hubungkan bot Anda ke berbagai platform</p>
        </div>

        {/* WhatsApp */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Phone className="h-5 w-5 text-green-500" /> WhatsApp
              {waStatus === "connected" ? <Badge className="ml-auto text-xs bg-green-500/20 text-green-400 border-green-500/30">Terhubung</Badge>
                : <Badge variant="secondary" className="ml-auto text-xs">Terputus</Badge>}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">WhatsApp dikelola oleh platform. Cukup scan QR, nomor Anda langsung aktif.</p>
            {waStatus === "connected" ? (
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">{waPhone || "Nomor terhubung"}</span>
                <Button variant="outline" size="sm" onClick={disconnectWa}><WifiOff className="h-4 w-4 mr-2" /> Putuskan</Button>
              </div>
            ) : (
              <Button className="glow-blue-sm" onClick={() => window.location.href = "/dashboard/connection"}>
                <Wifi className="h-4 w-4 mr-2" /> Hubungkan WhatsApp
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Telegram */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-blue-400" /> Telegram
              {telegram?.is_active ? <Badge className="ml-auto text-xs bg-blue-500/20 text-blue-400 border-blue-500/30">Aktif</Badge>
                : <Badge variant="secondary" className="ml-auto text-xs">Nonaktif</Badge>}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {telegram?.is_active ? (
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">@{telegram.telegram_bot_username || "bot"}</span>
                <Button variant="outline" size="sm" onClick={deactivateTelegram}><WifiOff className="h-4 w-4 mr-2" /> Nonaktifkan</Button>
              </div>
            ) : (
              <>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p><strong>1.</strong> Buka Telegram, cari <span className="text-foreground">@BotFather</span></p>
                  <p><strong>2.</strong> Ketik <code className="text-primary">/newbot</code> → ikuti instruksi → salin token</p>
                  <p><strong>3.</strong> Masukkan token dan username bot di bawah:</p>
                </div>
                <div><Label>Bot Token</Label><Input className="mt-1" value={tgToken} onChange={e => setTgToken(e.target.value)} placeholder="123456:ABC-DEF..." /></div>
                <div><Label>Username Bot (tanpa @)</Label><Input className="mt-1" value={tgUsername} onChange={e => setTgUsername(e.target.value)} placeholder="my_cs_bot" /></div>
                <Button className="glow-blue-sm" onClick={activateTelegram} disabled={tgSaving || !tgToken.trim()}>
                  {tgSaving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Wifi className="h-4 w-4 mr-2" />} Aktifkan
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        {/* Discord */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Hash className="h-5 w-5 text-indigo-400" /> Discord
              {discord?.is_active ? <Badge className="ml-auto text-xs bg-indigo-500/20 text-indigo-400 border-indigo-500/30">Aktif</Badge>
                : <Badge variant="secondary" className="ml-auto text-xs">Nonaktif</Badge>}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {discord?.is_active ? (
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Guild: {discord.discord_guild_id}</span>
                <Button variant="outline" size="sm" onClick={deactivateDiscord}><WifiOff className="h-4 w-4 mr-2" /> Nonaktifkan</Button>
              </div>
            ) : (
              <>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p><strong>1.</strong> Buka <a href="https://discord.com/developers/applications" target="_blank" rel="noopener" className="text-primary underline">discord.com/developers <ExternalLink className="h-3 w-3 inline" /></a></p>
                  <p><strong>2.</strong> New Application → Bot → Reset Token → salin</p>
                  <p><strong>3.</strong> OAuth2 → copy Client ID → invite bot dengan permissions=2048&scope=bot</p>
                </div>
                <div><Label>Bot Token</Label><Input className="mt-1" value={dcToken} onChange={e => setDcToken(e.target.value)} placeholder="Discord bot token" /></div>
                <div><Label>Guild / Server ID</Label><Input className="mt-1" value={dcGuild} onChange={e => setDcGuild(e.target.value)} placeholder="Klik kanan server → Copy ID" /><p className="text-xs text-muted-foreground mt-1">Aktifkan Developer Mode di Settings → Advanced</p></div>
                <div><Label>Channel ID</Label><Input className="mt-1" value={dcChannel} onChange={e => setDcChannel(e.target.value)} placeholder="Klik kanan channel → Copy ID" /></div>
                <Button className="glow-blue-sm" onClick={activateDiscord} disabled={dcSaving || !dcToken.trim() || !dcGuild.trim() || !dcChannel.trim()}>
                  {dcSaving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Wifi className="h-4 w-4 mr-2" />} Aktifkan
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
