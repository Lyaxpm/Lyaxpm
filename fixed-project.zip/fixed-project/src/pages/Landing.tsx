import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Bot, MessageSquare, BarChart3, Users, Zap, Shield, Clock, Star, Check, ArrowRight, Phone, Mail, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

const stagger = {
  visible: { transition: { staggerChildren: 0.15 } },
};

const features = [
  { icon: Bot, title: "AI Auto-Reply", desc: "Bot menjawab pertanyaan pelanggan secara otomatis 24/7 dengan kecerdasan buatan." },
  { icon: MessageSquare, title: "Integrasi WhatsApp", desc: "Hubungkan langsung ke nomor WhatsApp bisnis Anda tanpa ribet." },
  { icon: BarChart3, title: "Dashboard Real-time", desc: "Pantau semua percakapan dan performa bot secara langsung." },
  { icon: Users, title: "Multi-Client", desc: "Kelola banyak klien dan nomor WhatsApp dari satu platform." },
  { icon: Zap, title: "Respons Cepat", desc: "Waktu respons di bawah 2 detik untuk pengalaman pelanggan terbaik." },
  { icon: Shield, title: "Aman & Terenkripsi", desc: "Data pelanggan dilindungi dengan enkripsi end-to-end." },
];

const plans = [
  {
    name: "Starter",
    price: "500.000",
    period: "/bulan",
    features: ["1 nomor WhatsApp", "500 chat/bulan", "AI auto-reply dasar", "Dashboard analitik", "Email support"],
    popular: false,
  },
  {
    name: "Pro",
    price: "1.200.000",
    period: "/bulan",
    features: ["1 nomor WhatsApp", "Unlimited chat", "Custom AI persona", "FAQ manager", "Priority support", "Laporan bulanan"],
    popular: true,
  },
  {
    name: "Enterprise",
    price: "2.500.000",
    period: "/bulan",
    features: ["3 nomor WhatsApp", "Unlimited chat", "Custom integration", "Dedicated account manager", "SLA 99.9%", "API access"],
    popular: false,
  },
];

const testimonials = [
  { name: "Budi Santoso", role: "Owner, Toko Elektronik Jaya", text: "Sejak pakai layanan ini, CS kami bisa handle 3x lebih banyak customer tanpa tambah karyawan. Luar biasa!", rating: 5 },
  { name: "Sari Dewi", role: "Manager, Klinik Kecantikan Aura", text: "Bot AI-nya pintar banget, bisa jawab pertanyaan soal treatment dan booking jadwal otomatis. Customer puas!", rating: 5 },
  { name: "Andi Pratama", role: "CEO, PT Digital Nusantara", text: "Dashboard-nya lengkap dan mudah dipahami. Kami bisa monitor performa CS 24/7 dari mana saja.", rating: 5 },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass">
        <div className="container mx-auto flex items-center justify-between py-4 px-6">
          <Link to="/" className="flex items-center gap-2">
            <Bot className="h-7 w-7 text-primary" />
            <span className="text-xl font-bold text-foreground">ChatServis<span className="text-primary">.AI</span></span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <a href="#fitur" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Fitur</a>
            <a href="#harga" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Harga</a>
            <a href="#testimoni" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Testimoni</a>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/login">Masuk</Link>
            </Button>
            <Button size="sm" className="glow-blue-sm" asChild>
              <Link to="/register">Mulai Sekarang</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden gradient-hero">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-accent/20 rounded-full blur-3xl" />
        </div>
        <div className="container mx-auto relative z-10">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={stagger}
            className="max-w-3xl mx-auto text-center"
          >
            <motion.div variants={fadeUp} className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/10 mb-6">
              <Clock className="h-4 w-4 text-primary" />
              <span className="text-sm text-primary font-medium">Aktif 24/7 tanpa henti</span>
            </motion.div>
            <motion.h1 variants={fadeUp} className="text-4xl md:text-6xl font-extrabold leading-tight mb-6">
              CS Digital Otomatis 24/7{" "}
              <span className="text-gradient">Berbasis AI</span>
            </motion.h1>
            <motion.p variants={fadeUp} className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Tingkatkan layanan pelanggan WhatsApp Anda dengan bot AI cerdas. Respons instan, hemat biaya, dan selalu online.
            </motion.p>
            <motion.div variants={fadeUp} className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="glow-blue text-lg px-8 py-6" asChild>
                <Link to="/register">
                  Mulai Sekarang <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-6" asChild>
                <a href="#fitur">Pelajari Lebih Lanjut</a>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="fitur" className="py-24 px-6">
        <div className="container mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
            <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-4">Fitur <span className="text-gradient">Unggulan</span></motion.h2>
            <motion.p variants={fadeUp} className="text-muted-foreground max-w-xl mx-auto">Semua yang Anda butuhkan untuk mengotomatiskan layanan pelanggan WhatsApp.</motion.p>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f) => (
              <motion.div key={f.title} variants={fadeUp} className="gradient-card rounded-xl p-6 border border-border hover:border-primary/40 transition-colors group">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:glow-blue-sm transition-shadow">
                  <f.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Pricing */}
      <section id="harga" className="py-24 px-6 bg-secondary/30">
        <div className="container mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
            <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-4">Pilih <span className="text-gradient">Paket Anda</span></motion.h2>
            <motion.p variants={fadeUp} className="text-muted-foreground">Harga transparan tanpa biaya tersembunyi.</motion.p>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan) => (
              <motion.div
                key={plan.name}
                variants={fadeUp}
                className={`rounded-2xl p-8 border transition-all ${
                  plan.popular
                    ? "border-primary glow-blue gradient-card scale-105"
                    : "border-border gradient-card hover:border-primary/30"
                }`}
              >
                {plan.popular && (
                  <div className="text-xs font-bold uppercase tracking-wider text-primary mb-4">Paling Populer</div>
                )}
                <h3 className="text-xl font-bold mb-1">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-sm text-muted-foreground">Rp</span>
                  <span className="text-4xl font-extrabold">{plan.price}</span>
                  <span className="text-muted-foreground">{plan.period}</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-primary flex-shrink-0" />
                      <span className="text-muted-foreground">{f}</span>
                    </li>
                  ))}
                </ul>
                <Button className={`w-full ${plan.popular ? "glow-blue-sm" : ""}`} variant={plan.popular ? "default" : "outline"} asChild>
                  <Link to="/register">Pilih Paket</Link>
                </Button>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimoni" className="py-24 px-6">
        <div className="container mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
            <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-4">Apa Kata <span className="text-gradient">Mereka</span></motion.h2>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {testimonials.map((t) => (
              <motion.div key={t.name} variants={fadeUp} className="gradient-card rounded-xl p-6 border border-border">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-warning text-warning" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground mb-4">"{t.text}"</p>
                <div>
                  <p className="font-semibold text-sm">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6">
        <div className="container mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="gradient-blue rounded-2xl p-12 text-center max-w-4xl mx-auto relative overflow-hidden">
            <div className="absolute inset-0 opacity-30">
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-background/10 rounded-full blur-2xl" />
            </div>
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">Siap Meningkatkan Layanan Pelanggan?</h2>
              <p className="text-primary-foreground/80 mb-8 max-w-lg mx-auto">Bergabung dengan ratusan bisnis yang sudah menggunakan ChatServis.AI</p>
              <Button size="lg" variant="secondary" className="text-lg px-8 py-6" asChild>
                <Link to="/register">Mulai Sekarang <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 px-6">
        <div className="container mx-auto grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Bot className="h-6 w-6 text-primary" />
              <span className="text-lg font-bold">ChatServis<span className="text-primary">.AI</span></span>
            </div>
            <p className="text-sm text-muted-foreground">Solusi customer service WhatsApp berbasis AI untuk bisnis Anda.</p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Navigasi</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#fitur" className="hover:text-foreground transition-colors">Fitur</a></li>
              <li><a href="#harga" className="hover:text-foreground transition-colors">Harga</a></li>
              <li><a href="#testimoni" className="hover:text-foreground transition-colors">Testimoni</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Kontak</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2"><Phone className="h-4 w-4" /> +62 812 3456 7890</li>
              <li className="flex items-center gap-2"><Mail className="h-4 w-4" /> hello@chatservis.ai</li>
              <li className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Jakarta, Indonesia</li>
            </ul>
          </div>
        </div>
        <div className="container mx-auto mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          © 2026 ChatServis.AI. Hak cipta dilindungi.
        </div>
      </footer>
    </div>
  );
}
