import { useEffect, useState } from "react";
import { Users, MessageSquare, DollarSign, TrendingUp, MoreVertical, Ban, Trash2, Eye, UserPlus, Shield, Edit, Search, ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import DashboardLayout from "@/components/DashboardLayout";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface Client {
  id: string;
  full_name: string;
  email: string;
  plan: string;
  status: string;
  chats_used: number;
  chat_limit: number;
  expires_at: string;
  created_at: string;
  wa_status: string;
  subscription_id: string;
}

const PER_PAGE = 10;

export default function AdminDashboard() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalChatsToday, setTotalChatsToday] = useState(0);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [deleteClient, setDeleteClient] = useState<Client | null>(null);
  const [editSubClient, setEditSubClient] = useState<Client | null>(null);
  const [editPlan, setEditPlan] = useState("starter");
  const [editStatus, setEditStatus] = useState("active");
  const [editExpires, setEditExpires] = useState("");
  const [editChatLimit, setEditChatLimit] = useState("500");
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);

  const fetchClients = async () => {
    // Single query approach: fetch all profiles, subscriptions, wa_connections separately then join in JS
    const [profilesRes, subsRes, waRes] = await Promise.all([
      supabase.from("profiles").select("id, full_name, email, created_at"),
      supabase.from("subscriptions").select("id, user_id, plan, status, chats_used, chat_limit, expires_at"),
      supabase.from("wa_connections").select("user_id, status"),
    ]);

    const profiles = (profilesRes.data as any[]) || [];
    const subs = (subsRes.data as any[]) || [];
    const was = (waRes.data as any[]) || [];

    const subMap = new Map(subs.map(s => [s.user_id, s]));
    const waMap = new Map(was.map(w => [w.user_id, w]));

    const clientList: Client[] = profiles.map(p => {
      const sub = subMap.get(p.id);
      const wa = waMap.get(p.id);
      return {
        id: p.id,
        full_name: p.full_name || p.email,
        email: p.email,
        plan: sub?.plan || "starter",
        status: sub?.status || "active",
        chats_used: sub?.chats_used || 0,
        chat_limit: sub?.chat_limit || 500,
        expires_at: sub?.expires_at || "",
        created_at: p.created_at,
        wa_status: wa?.status || "disconnected",
        subscription_id: sub?.id || "",
      };
    });

    setClients(clientList);
    setLoading(false);
  };

  useEffect(() => {
    fetchClients();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    supabase.from("chat_logs").select("id", { count: "exact", head: true })
      .gte("created_at", today.toISOString())
      .then(({ count }) => setTotalChatsToday(count || 0));
  }, []);

  const suspendClient = async (clientId: string) => {
    await supabase.from("subscriptions").update({ status: "suspended" }).eq("user_id", clientId);
    toast.warning("Klien di-suspend");
    fetchClients();
  };

  const activateClient = async (clientId: string) => {
    await supabase.from("subscriptions").update({ status: "active" }).eq("user_id", clientId);
    toast.success("Klien diaktifkan kembali");
    fetchClients();
  };

  const makeAdmin = async (clientId: string) => {
    await supabase.from("user_roles").update({ role: "admin" }).eq("user_id", clientId);
    toast.success("Klien dijadikan admin");
  };

  const handleDeleteClient = async () => {
    if (!deleteClient) return;
    await supabase.from("profiles").delete().eq("id", deleteClient.id);
    toast.success("Klien dihapus");
    setDeleteClient(null);
    fetchClients();
  };

  const handleEditSub = async () => {
    if (!editSubClient) return;
    await supabase.from("subscriptions").update({
      plan: editPlan as any,
      status: editStatus,
      expires_at: editExpires || undefined,
      chat_limit: parseInt(editChatLimit) || 500,
    }).eq("user_id", editSubClient.id);
    toast.success("Langganan diperbarui");
    setEditSubClient(null);
    fetchClients();
  };

  const openEditSub = (c: Client) => {
    setEditSubClient(c);
    setEditPlan(c.plan);
    setEditStatus(c.status);
    setEditExpires(c.expires_at ? c.expires_at.split("T")[0] : "");
    setEditChatLimit(String(c.chat_limit));
  };

  // Filter + paginate
  const filtered = clients.filter(c =>
    c.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.email.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const totalRevenue = clients.reduce((sum, c) => {
    if (c.status !== "active") return sum;
    const prices: Record<string, number> = { starter: 500000, pro: 1200000, enterprise: 2500000 };
    return sum + (prices[c.plan] || 0);
  }, 0);

  const globalStats = [
    { label: "Total Klien", value: String(clients.length), icon: Users },
    { label: "Chat Hari Ini", value: String(totalChatsToday), icon: MessageSquare },
    { label: "Est. Revenue", value: `Rp ${(totalRevenue / 1000000).toFixed(1)}jt`, icon: DollarSign },
    { label: "Klien Aktif", value: String(clients.filter(c => c.status === "active").length), icon: TrendingUp },
  ];

  return (
    <DashboardLayout isAdmin>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <p className="text-sm text-muted-foreground">Overview seluruh klien dan platform</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {globalStats.map((s) => (
            <Card key={s.label} className="gradient-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <s.icon className="h-5 w-5 text-primary" />
                </div>
                <p className="text-2xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="gradient-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between gap-4">
              <CardTitle className="text-lg">Daftar Klien</CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Cari nama atau email..."
                  value={searchQuery}
                  onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
                  className="pl-9"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="p-8 text-center text-muted-foreground">Memuat...</div>
            ) : paginated.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">Tidak ada klien ditemukan</div>
            ) : (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left p-4 font-medium text-muted-foreground">Nama</th>
                        <th className="text-left p-4 font-medium text-muted-foreground hidden md:table-cell">Email</th>
                        <th className="text-left p-4 font-medium text-muted-foreground">Paket</th>
                        <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                        <th className="text-left p-4 font-medium text-muted-foreground hidden lg:table-cell">WA</th>
                        <th className="text-left p-4 font-medium text-muted-foreground hidden lg:table-cell">Chat</th>
                        <th className="p-4"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginated.map((c) => (
                        <tr key={c.id} className="border-b border-border hover:bg-secondary/20 transition-colors">
                          <td className="p-4 font-medium">{c.full_name}</td>
                          <td className="p-4 text-muted-foreground hidden md:table-cell">{c.email}</td>
                          <td className="p-4"><Badge variant="outline" className="text-xs capitalize">{c.plan}</Badge></td>
                          <td className="p-4">
                            <Badge variant={c.status === "active" ? "default" : "destructive"} className="text-xs">
                              {c.status === "active" ? "Aktif" : "Suspended"}
                            </Badge>
                          </td>
                          <td className="p-4 hidden lg:table-cell">
                            <Badge variant={c.wa_status === "connected" ? "default" : "secondary"} className="text-xs">
                              {c.wa_status === "connected" ? "Online" : "Offline"}
                            </Badge>
                          </td>
                          <td className="p-4 text-muted-foreground hidden lg:table-cell">{c.chats_used}</td>
                          <td className="p-4">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8"><MoreVertical className="h-4 w-4" /></Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => setSelectedClient(c)}>
                                  <Eye className="h-4 w-4 mr-2" /> Lihat Detail
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => openEditSub(c)}>
                                  <Edit className="h-4 w-4 mr-2" /> Edit Langganan
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => makeAdmin(c.id)}>
                                  <Shield className="h-4 w-4 mr-2" /> Jadikan Admin
                                </DropdownMenuItem>
                                {c.status === "active" ? (
                                  <DropdownMenuItem onClick={() => suspendClient(c.id)}>
                                    <Ban className="h-4 w-4 mr-2" /> Suspend
                                  </DropdownMenuItem>
                                ) : (
                                  <DropdownMenuItem onClick={() => activateClient(c.id)}>
                                    <UserPlus className="h-4 w-4 mr-2" /> Aktifkan
                                  </DropdownMenuItem>
                                )}
                                <DropdownMenuItem className="text-destructive" onClick={() => setDeleteClient(c)}>
                                  <Trash2 className="h-4 w-4 mr-2" /> Hapus Klien
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {totalPages > 1 && (
                  <div className="flex items-center justify-between p-4 border-t border-border">
                    <span className="text-sm text-muted-foreground">
                      {filtered.length} klien · Hal {page}/{totalPages}
                    </span>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Detail Dialog */}
        <Dialog open={!!selectedClient} onOpenChange={() => setSelectedClient(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>Detail Klien</DialogTitle></DialogHeader>
            {selectedClient && (
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><p className="text-muted-foreground">Nama</p><p className="font-medium">{selectedClient.full_name}</p></div>
                <div><p className="text-muted-foreground">Email</p><p className="font-medium">{selectedClient.email}</p></div>
                <div><p className="text-muted-foreground">Paket</p><Badge variant="outline" className="capitalize">{selectedClient.plan}</Badge></div>
                <div><p className="text-muted-foreground">Status</p><Badge variant={selectedClient.status === "active" ? "default" : "destructive"}>{selectedClient.status}</Badge></div>
                <div><p className="text-muted-foreground">WhatsApp</p><Badge variant={selectedClient.wa_status === "connected" ? "default" : "secondary"}>{selectedClient.wa_status}</Badge></div>
                <div><p className="text-muted-foreground">Chat</p><p className="font-medium">{selectedClient.chats_used} / {selectedClient.chat_limit === -1 ? "∞" : selectedClient.chat_limit}</p></div>
                <div className="col-span-2"><p className="text-muted-foreground">Bergabung</p><p className="font-medium">{new Date(selectedClient.created_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}</p></div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation */}
        <AlertDialog open={!!deleteClient} onOpenChange={() => setDeleteClient(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Hapus Klien?</AlertDialogTitle>
              <AlertDialogDescription>
                Menghapus {deleteClient?.full_name} akan menghapus semua data terkait. Tindakan ini tidak bisa dibatalkan.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Batal</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteClient} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Hapus</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Edit Subscription Dialog */}
        <Dialog open={!!editSubClient} onOpenChange={() => setEditSubClient(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>Edit Langganan — {editSubClient?.full_name}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Plan</Label>
                <Select value={editPlan} onValueChange={setEditPlan}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="starter">Starter</SelectItem>
                    <SelectItem value="pro">Pro</SelectItem>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Status</Label>
                <Select value={editStatus} onValueChange={setEditStatus}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Expires At</Label>
                <Input type="date" className="mt-1" value={editExpires} onChange={e => setEditExpires(e.target.value)} />
              </div>
              <div>
                <Label>Chat Limit (-1 = unlimited)</Label>
                <Input type="number" className="mt-1" value={editChatLimit} onChange={e => setEditChatLimit(e.target.value)} />
              </div>
              <Button className="w-full glow-blue-sm" onClick={handleEditSub}>Simpan</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
