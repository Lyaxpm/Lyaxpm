import { useEffect, useState } from "react";
import { Save, Loader2, Server, DollarSign, Brain, CreditCard, AlertTriangle, CheckCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "@/components/DashboardLayout";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const aiModels = [
  { value: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (Default)" },
  { value: "google/gemini-2.5-pro", label: "Gemini 2.5 Pro" },
  { value: "google/gemini-2.5-flash-lite", label: "Gemini 2.5 Flash Lite" },
  { value: "google/gemini-3-pro-preview", label: "Gemini 3 Pro Preview" },
  { value: "google/gemini-3-flash-preview", label: "Gemini 3 Flash Preview" },
  { value: "openai/gpt-5", label: "GPT-5" },
  { value: "openai/gpt-5-mini", label: "GPT-5 Mini" },
  { value: "openai/gpt-5-nano", label: "GPT-5 Nano" },
  { value: "openai/gpt-5.2", label: "GPT-5.2" },
];

const envChecklist = [
  { key: "OPENROUTER_API_KEY", desc: "untuk AI chat" },
  { key: "TRIPAY_API_KEY", desc: "untuk pembayaran" },
  { key: "TRIPAY_PRIVATE_KEY", desc: "untuk verifikasi" },
  { key: "TRIPAY_MERCHANT_CODE", desc: "kode merchant" },
];

export default function AdminSettings() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    supabase
      .from("platform_settings")
      .select("key, value")
      .then(({ data }) => {
        if (data) {
          const map: Record<string, string> = {};
          (data as any[]).forEach((d) => (map[d.key] = d.value));
          setSettings(map);
        }
        setLoading(false);
      });
  }, []);

  const updateSetting = (key: string, value: string) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const saveAll = async () => {
    setSaving(true);
    const entries = Object.entries(settings);
    for (const [key, value] of entries) {
      await supabase
        .from("platform_settings")
        .update({ value, updated_at: new Date().toISOString() })
        .eq("key", key);
    }
    toast.success("Pengaturan berhasil disimpan");
    setSaving(false);
  };

  if (loading) {
    return (
      <DashboardLayout isAdmin>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout isAdmin>
      <div className="space-y-6 max-w-3xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Pengaturan Platform</h1>
            <p className="text-sm text-muted-foreground">Konfigurasi AI, harga, server, dan integrasi</p>
          </div>
          <Button onClick={saveAll} disabled={saving} className="glow-blue-sm">
            {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
            Simpan Semua
          </Button>
        </div>

        {/* Tripay Sandbox Warning */}
        {settings.tripay_mode === "sandbox" && (
          <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4 flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-destructive">⚠️ Tripay masih SANDBOX</p>
              <p className="text-xs text-muted-foreground">Pembayaran tidak nyata. Ubah ke Production sebelum go live.</p>
            </div>
          </div>
        )}

        {/* AI Model */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><Brain className="h-5 w-5 text-primary" /> Model AI</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Model untuk AI Chat</Label>
              <Select value={settings.ai_model || ""} onValueChange={(v) => updateSetting("ai_model", v)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {aiModels.map((m) => (<SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Pricing */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><DollarSign className="h-5 w-5 text-primary" /> Harga Paket</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { key: "starter_price", label: "Harga Starter (Rp)" },
              { key: "pro_price", label: "Harga Pro (Rp)" },
              { key: "enterprise_price", label: "Harga Enterprise (Rp)" },
            ].map((item) => (
              <div key={item.key}>
                <Label>{item.label}</Label>
                <Input type="number" value={settings[item.key] || ""} onChange={(e) => updateSetting(item.key, e.target.value)} className="mt-1" />
              </div>
            ))}
            <Separator />
            {[
              { key: "starter_chat_limit", label: "Chat Limit Starter (-1=unlimited)" },
              { key: "pro_chat_limit", label: "Chat Limit Pro (-1=unlimited)" },
              { key: "enterprise_chat_limit", label: "Chat Limit Enterprise (-1=unlimited)" },
            ].map((item) => (
              <div key={item.key}>
                <Label>{item.label}</Label>
                <Input type="number" value={settings[item.key] || ""} onChange={(e) => updateSetting(item.key, e.target.value)} className="mt-1" />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Server Config */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><Server className="h-5 w-5 text-primary" /> Konfigurasi Server</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>GOWA API URL</Label>
              <p className="text-xs text-muted-foreground mb-1">URL server GOWA WhatsApp, contoh: http://123.45.67.89:8080</p>
              <Input value={settings.gowa_api_url || ""} onChange={(e) => updateSetting("gowa_api_url", e.target.value)} className="mt-1" placeholder="http://IP_VPS:PORT" />
            </div>
            <div>
              <Label>GOWA Basic Auth</Label>
              <p className="text-xs text-muted-foreground mb-1">Format: username:password (sesuai docker-compose)</p>
              <Input value={settings.gowa_basic_auth || ""} onChange={(e) => updateSetting("gowa_basic_auth", e.target.value)} className="mt-1" placeholder="admin:password_kuat" />
            </div>
            <Separator />
            <div>
              <Label>Discord Relay URL</Label>
              <Input value={settings.discord_relay_url || ""} onChange={(e) => updateSetting("discord_relay_url", e.target.value)} className="mt-1" placeholder="https://discord-relay.yourdomain.com" />
            </div>
            <div>
              <Label>Discord Relay Secret</Label>
              <Input type="password" value={settings.discord_relay_secret || ""} onChange={(e) => updateSetting("discord_relay_secret", e.target.value)} className="mt-1" placeholder="••••••••" />
            </div>
          </CardContent>
        </Card>

        {/* Tripay */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><CreditCard className="h-5 w-5 text-primary" /> Tripay</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Mode</Label>
              <Select value={settings.tripay_mode || "sandbox"} onValueChange={(v) => updateSetting("tripay_mode", v)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sandbox">Sandbox</SelectItem>
                  <SelectItem value="production">Production</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">API keys Tripay dikelola melalui backend secrets secara aman.</p>
            </div>
          </CardContent>
        </Card>

        {/* Environment Variables Checklist */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><CheckCircle className="h-5 w-5 text-primary" /> Required Environment Variables</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {envChecklist.map(e => (
              <div key={e.key} className="flex items-center gap-3">
                <CheckCircle className="h-4 w-4 text-accent" />
                <div>
                  <code className="text-sm font-mono text-foreground">{e.key}</code>
                  <span className="text-xs text-muted-foreground ml-2">— {e.desc}</span>
                </div>
              </div>
            ))}
            <p className="text-xs text-muted-foreground mt-2 border-t border-border pt-3">
              Variabel ini sudah dikonfigurasi melalui backend secrets.
            </p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
