import { useEffect, useState } from "react";
import { FileText, Download, Eye } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import DashboardLayout from "@/components/DashboardLayout";
import { supabase } from "@/integrations/supabase/client";

interface Invoice {
  id: string;
  user_id: string;
  amount: number;
  status: string;
  method: string | null;
  merchant_ref: string | null;
  tripay_reference: string | null;
  created_at: string;
  paid_at: string | null;
  user_name?: string;
  user_email?: string;
}

export default function AdminInvoices() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Invoice | null>(null);

  useEffect(() => {
    const fetch = async () => {
      const { data: payments } = await supabase
        .from("payments")
        .select("*")
        .order("created_at", { ascending: false });
      if (!payments) { setLoading(false); return; }

      const userIds = [...new Set((payments as any[]).map((p) => p.user_id))];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, email")
        .in("id", userIds);

      const profileMap: Record<string, any> = {};
      (profiles || []).forEach((p: any) => (profileMap[p.id] = p));

      setInvoices(
        (payments as any[]).map((p) => ({
          ...p,
          user_name: profileMap[p.user_id]?.full_name || "",
          user_email: profileMap[p.user_id]?.email || "",
        }))
      );
      setLoading(false);
    };
    fetch();
  }, []);

  const statusColor = (s: string) => {
    if (s === "paid") return "default";
    if (s === "pending") return "secondary";
    return "destructive";
  };

  return (
    <DashboardLayout isAdmin>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Invoice & Pembayaran</h1>
          <p className="text-sm text-muted-foreground">Riwayat semua transaksi klien</p>
        </div>

        <Card className="gradient-card border-border">
          <CardContent className="p-0">
            {loading ? (
              <div className="p-8 text-center text-muted-foreground">Memuat...</div>
            ) : invoices.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">Belum ada transaksi</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left p-4 font-medium text-muted-foreground">Invoice</th>
                      <th className="text-left p-4 font-medium text-muted-foreground hidden md:table-cell">Klien</th>
                      <th className="text-left p-4 font-medium text-muted-foreground">Jumlah</th>
                      <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                      <th className="text-left p-4 font-medium text-muted-foreground hidden lg:table-cell">Metode</th>
                      <th className="text-left p-4 font-medium text-muted-foreground hidden lg:table-cell">Tanggal</th>
                      <th className="p-4"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoices.map((inv) => (
                      <tr key={inv.id} className="border-b border-border hover:bg-secondary/20 transition-colors">
                        <td className="p-4 font-mono text-xs">{inv.merchant_ref || inv.id.slice(0, 8)}</td>
                        <td className="p-4 hidden md:table-cell">
                          <div>
                            <p className="font-medium text-sm">{inv.user_name}</p>
                            <p className="text-xs text-muted-foreground">{inv.user_email}</p>
                          </div>
                        </td>
                        <td className="p-4 font-semibold">Rp {inv.amount.toLocaleString("id-ID")}</td>
                        <td className="p-4">
                          <Badge variant={statusColor(inv.status)} className="text-xs capitalize">{inv.status === "paid" ? "Lunas" : inv.status === "pending" ? "Menunggu" : inv.status}</Badge>
                        </td>
                        <td className="p-4 text-muted-foreground hidden lg:table-cell">{inv.method || "-"}</td>
                        <td className="p-4 text-muted-foreground hidden lg:table-cell">
                          {new Date(inv.created_at).toLocaleDateString("id-ID")}
                        </td>
                        <td className="p-4">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelected(inv)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" /> Detail Invoice
              </DialogTitle>
            </DialogHeader>
            {selected && (
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-secondary/30 border border-border space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Merchant Ref</span>
                    <span className="font-mono text-sm">{selected.merchant_ref || "-"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Tripay Ref</span>
                    <span className="font-mono text-sm">{selected.tripay_reference || "-"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Klien</span>
                    <span className="text-sm">{selected.user_name} ({selected.user_email})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Jumlah</span>
                    <span className="font-bold">Rp {selected.amount.toLocaleString("id-ID")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Metode</span>
                    <span className="text-sm">{selected.method || "-"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Status</span>
                    <Badge variant={statusColor(selected.status)} className="capitalize">{selected.status === "paid" ? "Lunas" : selected.status}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Dibuat</span>
                    <span className="text-sm">{new Date(selected.created_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
                  </div>
                  {selected.paid_at && (
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Dibayar</span>
                      <span className="text-sm">{new Date(selected.paid_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
