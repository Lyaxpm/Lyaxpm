import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bot, Lock, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export default function ResetPassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [isRecovery, setIsRecovery] = useState(false);

  useEffect(() => {
    const hash = window.location.hash;
    if (hash.includes("type=recovery")) {
      setIsRecovery(true);
    }
    supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") {
        setIsRecovery(true);
      }
    });
  }, []);

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast.error("Password tidak cocok");
      return;
    }
    if (password.length < 8) {
      toast.error("Password minimal 8 karakter");
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Password berhasil diubah!");
    navigate("/dashboard");
  };

  if (!isRecovery) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6 gradient-hero">
        <div className="w-full max-w-md text-center space-y-4">
          <Bot className="h-12 w-12 text-primary mx-auto" />
          <h1 className="text-xl font-bold">Link Tidak Valid</h1>
          <p className="text-sm text-muted-foreground">Link reset password tidak valid atau sudah kadaluarsa.</p>
          <Link to="/forgot-password">
            <Button className="glow-blue-sm">Minta Link Baru</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 gradient-hero">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
      </div>
      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <Bot className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold">ChatServis<span className="text-primary">.AI</span></span>
          </Link>
          <h1 className="text-2xl font-bold mb-2">Buat Password Baru</h1>
          <p className="text-sm text-muted-foreground">Masukkan password baru Anda</p>
        </div>
        <form onSubmit={handleReset} className="gradient-card rounded-2xl border border-border p-8 space-y-5">
          <div className="space-y-2">
            <Label htmlFor="password">Password Baru</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input id="password" type="password" placeholder="Min. 8 karakter" className="pl-10" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirm">Konfirmasi Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input id="confirm" type="password" placeholder="Ulangi password" className="pl-10" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required minLength={8} />
            </div>
          </div>
          <Button type="submit" className="w-full glow-blue-sm" disabled={loading}>
            {loading ? "Memproses..." : "Ubah Password"} <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
