import { useState } from "react";
import { Link } from "react-router-dom";
import { Bot, Mail, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setSent(true);
    toast.success("Link reset password telah dikirim ke email Anda");
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 gradient-hero">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
      </div>
      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <Bot className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold">ChatServis<span className="text-primary">.AI</span></span>
          </Link>
          <h1 className="text-2xl font-bold mb-2">Lupa Password</h1>
          <p className="text-sm text-muted-foreground">Masukkan email untuk menerima link reset password</p>
        </div>
        {sent ? (
          <div className="gradient-card rounded-2xl border border-border p-8 text-center space-y-4">
            <div className="w-16 h-16 mx-auto bg-primary/20 rounded-full flex items-center justify-center">
              <Mail className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-lg font-semibold">Cek Email Anda</h2>
            <p className="text-sm text-muted-foreground">
              Kami telah mengirim link reset password ke <span className="text-foreground font-medium">{email}</span>
            </p>
            <Link to="/login" className="inline-flex items-center text-sm text-primary hover:underline mt-4">
              <ArrowLeft className="h-4 w-4 mr-1" /> Kembali ke Login
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="gradient-card rounded-2xl border border-border p-8 space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="email" type="email" placeholder="nama@email.com" className="pl-10" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
            </div>
            <Button type="submit" className="w-full glow-blue-sm" disabled={loading}>
              {loading ? "Mengirim..." : "Kirim Link Reset"}
            </Button>
            <p className="text-center text-sm text-muted-foreground">
              Ingat password?{" "}
              <Link to="/login" className="text-primary hover:underline">Masuk</Link>
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
