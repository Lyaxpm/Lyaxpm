import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Bot, ArrowLeft, Copy, Check, Code, Webhook, Shield, Zap, Eye, EyeOff, RefreshCw, Key } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  return (
    <div className="relative group">
      <pre className="bg-background/80 border border-border rounded-lg p-4 overflow-x-auto text-sm font-mono text-muted-foreground">
        <code>{code}</code>
      </pre>
      <Button variant="ghost" size="icon" className="absolute top-2 right-2 h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity" onClick={copy}>
        {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
      </Button>
    </div>
  );
}

const baseUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/public-api`;

const endpoints = [
  {
    method: "POST", path: "/send-message", title: "Kirim Pesan",
    desc: "Kirim pesan ke pelanggan melalui channel tertentu.",
    curl: `curl -X POST "${baseUrl}/send-message" \\
  -H "x-api-key: YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"channel":"whatsapp","contact":"628123456789","message":"Halo!"}'`,
    response: `{ "success": true, "message_id": "uuid" }`,
  },
  {
    method: "GET", path: "/chats", title: "Daftar Chat",
    desc: "Ambil daftar percakapan dengan filter dan pagination.",
    curl: `curl "${baseUrl}/chats?channel=whatsapp&status=active&page=1&limit=20" \\
  -H "x-api-key: YOUR_API_KEY"`,
    response: `{ "data": [...], "total": 100, "page": 1 }`,
  },
  {
    method: "GET", path: "/chats/:id/messages", title: "Pesan dalam Chat",
    desc: "Ambil semua pesan dalam satu percakapan.",
    curl: `curl "${baseUrl}/chats/CHAT_ID/messages" \\
  -H "x-api-key: YOUR_API_KEY"`,
    response: `{ "data": [{ "id": "...", "sender_type": "customer", "content": "Halo", "created_at": "..." }] }`,
  },
  {
    method: "POST", path: "/chats/:id/reply", title: "Balas Chat",
    desc: "Balas pesan dalam percakapan tertentu.",
    curl: `curl -X POST "${baseUrl}/chats/CHAT_ID/reply" \\
  -H "x-api-key: YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"message":"Baik, kami bantu!"}'`,
    response: `{ "success": true }`,
  },
];

export default function ApiDocs() {
  const { user } = useAuth();
  const [apiKey, setApiKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [regenerating, setRegenerating] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("api_key").eq("id", user.id).single()
      .then(({ data }) => { if (data) setApiKey((data as any).api_key || ""); });
  }, [user]);

  const regenerateKey = async () => {
    if (!user) return;
    setRegenerating(true);
    const newKey = "sk-" + crypto.randomUUID().replace(/-/g, "");
    await supabase.from("profiles").update({ api_key: newKey } as any).eq("id", user.id);
    setApiKey(newKey);
    setShowKey(true);
    toast.warning("API Key baru dibuat. Simpan sekarang, tidak bisa dilihat lagi setelah refresh.");
    setRegenerating(false);
  };

  const copyKey = () => { navigator.clipboard.writeText(apiKey); toast.success("API Key disalin"); };

  const masked = apiKey ? apiKey.substring(0, 6) + "••••••••" + apiKey.substring(apiKey.length - 4) : "";

  return (
    <DashboardLayout>
      <div className="space-y-8 max-w-4xl">
        <div>
          <h1 className="text-2xl font-bold">API Documentation</h1>
          <p className="text-sm text-muted-foreground">Dokumentasi REST API untuk integrasi dengan sistem Anda</p>
          <div className="flex gap-2 mt-3">
            <Badge className="bg-primary/20 text-primary border-primary/30"><Code className="h-3 w-3 mr-1" /> REST API</Badge>
            <Badge className="bg-primary/20 text-primary border-primary/30"><Shield className="h-3 w-3 mr-1" /> API Key Auth</Badge>
          </div>
        </div>

        {/* API Key */}
        <Card className="gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><Key className="h-5 w-5 text-primary" /> API Key</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2 items-center">
              <code className="flex-1 bg-background/80 border border-border rounded-lg px-4 py-2 text-sm font-mono text-muted-foreground">
                {showKey ? apiKey : masked}
              </code>
              <Button variant="ghost" size="icon" onClick={() => setShowKey(!showKey)}>
                {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={copyKey}><Copy className="h-4 w-4" /></Button>
            </div>
            <Button variant="outline" size="sm" onClick={regenerateKey} disabled={regenerating}>
              <RefreshCw className="h-4 w-4 mr-2" /> Generate Ulang API Key
            </Button>
            <p className="text-xs text-muted-foreground">Gunakan header <code className="text-primary">x-api-key: YOUR_API_KEY</code> pada setiap request.</p>
          </CardContent>
        </Card>

        {/* Base URL */}
        <Card className="gradient-card border-border">
          <CardHeader><CardTitle className="text-lg">Base URL</CardTitle></CardHeader>
          <CardContent>
            <CodeBlock code={`Base URL: ${baseUrl}`} />
          </CardContent>
        </Card>

        {/* Endpoints */}
        <div className="space-y-6">
          <h2 className="text-xl font-bold flex items-center gap-2"><Webhook className="h-5 w-5 text-primary" /> Endpoints</h2>
          {endpoints.map(ep => (
            <Card key={ep.path} className="gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-3">
                  <Badge className={ep.method === "POST" ? "bg-green-500/20 text-green-400 border-green-500/30" : "bg-blue-500/20 text-blue-400 border-blue-500/30"}>
                    {ep.method}
                  </Badge>
                  <code className="text-sm font-mono">{ep.path}</code>
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-1">{ep.desc}</p>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="curl">
                  <TabsList className="bg-secondary/50">
                    <TabsTrigger value="curl">cURL</TabsTrigger>
                    <TabsTrigger value="response">Response</TabsTrigger>
                  </TabsList>
                  <TabsContent value="curl" className="mt-4"><CodeBlock code={ep.curl} /></TabsContent>
                  <TabsContent value="response" className="mt-4"><CodeBlock code={ep.response} /></TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
