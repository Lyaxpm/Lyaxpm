import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

type AppRole = "admin" | "client";
type SubscriptionPlan = "starter" | "pro" | "enterprise";

interface Subscription {
  plan: SubscriptionPlan;
  status: string;
  chat_limit: number;
  wa_limit: number;
  price: number;
  chats_used: number;
  expires_at: string;
}

interface Profile {
  full_name: string;
  email: string;
  api_key?: string;
}

interface AgentRecord {
  id: string;
  workspace_owner_id: string;
  name: string;
  email: string;
  status: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  role: AppRole | null;
  subscription: Subscription | null;
  profile: Profile | null;
  agentRecord: AgentRecord | null;
  workspaceOwnerId: string | null;
  loading: boolean;
  signOut: () => Promise<void>;
  refreshSubscription: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  role: null,
  subscription: null,
  profile: null,
  agentRecord: null,
  workspaceOwnerId: null,
  loading: true,
  signOut: async () => {},
  refreshSubscription: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [agentRecord, setAgentRecord] = useState<AgentRecord | null>(null);
  const [workspaceOwnerId, setWorkspaceOwnerId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUserData = async (userId: string) => {
    try {
      const [roleRes, subRes, profileRes, agentRes] = await Promise.all([
        supabase.from("user_roles").select("role").eq("user_id", userId).single(),
        supabase.from("subscriptions").select("*").eq("user_id", userId).single(),
        supabase.from("profiles").select("full_name, email, api_key").eq("id", userId).single(),
        (supabase.from("agents" as any).select("id, workspace_owner_id, name, email, status") as any)
          .eq("agent_user_id", userId).eq("status", "active").limit(1),
      ]);

      if (roleRes.data) setRole(roleRes.data.role as AppRole);
      if (subRes.data) setSubscription(subRes.data as unknown as Subscription);
      if (profileRes.data) setProfile(profileRes.data as Profile);

      // Agent support
      const agentData = agentRes.data as any[];
      if (agentData && agentData.length > 0) {
        const agent = agentData[0] as AgentRecord;
        setAgentRecord(agent);
        setWorkspaceOwnerId(agent.workspace_owner_id);
      } else {
        setAgentRecord(null);
        setWorkspaceOwnerId(userId);
      }
    } catch (err) {
      console.error("fetchUserData error:", err);
    }
  };

  const refreshSubscription = async () => {
    if (!user) return;
    const { data } = await supabase.from("subscriptions").select("*").eq("user_id", user.id).single();
    if (data) setSubscription(data as unknown as Subscription);
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchUserData(session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription: authSub } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        if (session?.user) {
          setTimeout(() => fetchUserData(session.user.id), 0);
        } else {
          setRole(null);
          setSubscription(null);
          setProfile(null);
          setAgentRecord(null);
          setWorkspaceOwnerId(null);
        }
        setLoading(false);
      }
    );

    return () => authSub.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setRole(null);
    setSubscription(null);
    setProfile(null);
    setAgentRecord(null);
    setWorkspaceOwnerId(null);
  };

  return (
    <AuthContext.Provider
      value={{ user, session, role, subscription, profile, agentRecord, workspaceOwnerId, loading, signOut, refreshSubscription }}
    >
      {children}
    </AuthContext.Provider>
  );
}
