import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Invite from "./pages/Invite";
import ApiDocs from "./pages/ApiDocs";
import AdminLogin from "./pages/admin/AdminLogin";
import DashboardOverview from "./pages/dashboard/Overview";
import ChatLog from "./pages/dashboard/ChatLog";
import LiveChat from "./pages/dashboard/LiveChat";
import BotSettings from "./pages/dashboard/BotSettings";
import KnowledgeBase from "./pages/dashboard/KnowledgeBase";
import WAConnection from "./pages/dashboard/WAConnection";
import Subscription from "./pages/dashboard/Subscription";
import Invoices from "./pages/dashboard/Invoices";
import Channels from "./pages/dashboard/Channels";
import Agents from "./pages/dashboard/Agents";
import Profile from "./pages/dashboard/Profile";
import Widget from "./pages/dashboard/Widget";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminInvoices from "./pages/admin/AdminInvoices";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            {/* Public */}
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/invite" element={<Invite />} />
            <Route path="/api-docs" element={<ApiDocs />} />

            {/* Admin login — public */}
            <Route path="/admin/login" element={<AdminLogin />} />

            {/* Dashboard */}
            <Route path="/dashboard" element={<ProtectedRoute><DashboardOverview /></ProtectedRoute>} />
            <Route path="/dashboard/chats" element={<ProtectedRoute><ChatLog /></ProtectedRoute>} />
            <Route path="/dashboard/live-chat" element={<ProtectedRoute><LiveChat /></ProtectedRoute>} />
            <Route path="/dashboard/bot" element={<ProtectedRoute><BotSettings /></ProtectedRoute>} />
            <Route path="/dashboard/knowledge" element={<ProtectedRoute><KnowledgeBase /></ProtectedRoute>} />
            <Route path="/dashboard/connection" element={<ProtectedRoute><WAConnection /></ProtectedRoute>} />
            <Route path="/dashboard/channels" element={<ProtectedRoute><Channels /></ProtectedRoute>} />
            <Route path="/dashboard/agents" element={<ProtectedRoute><Agents /></ProtectedRoute>} />
            <Route path="/dashboard/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/dashboard/widget" element={<ProtectedRoute><Widget /></ProtectedRoute>} />
            <Route path="/dashboard/subscription" element={<ProtectedRoute><Subscription /></ProtectedRoute>} />
            <Route path="/dashboard/invoices" element={<ProtectedRoute><Invoices /></ProtectedRoute>} />
            <Route path="/dashboard/api-docs" element={<ProtectedRoute><ApiDocs /></ProtectedRoute>} />

            {/* Admin */}
            <Route path="/admin" element={<ProtectedRoute requiredRole="admin"><AdminDashboard /></ProtectedRoute>} />
            <Route path="/admin/clients" element={<ProtectedRoute requiredRole="admin"><AdminDashboard /></ProtectedRoute>} />
            <Route path="/admin/settings" element={<ProtectedRoute requiredRole="admin"><AdminSettings /></ProtectedRoute>} />
            <Route path="/admin/invoices" element={<ProtectedRoute requiredRole="admin"><AdminInvoices /></ProtectedRoute>} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
