import { ReactNode, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bot, LayoutDashboard, MessageSquare, Settings, Wifi, CreditCard, LogOut, Shield, Lock, Headphones, Globe, FileText, Radio, Receipt, Sliders, User, Users, Code, Inbox } from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, useSidebar,
} from "@/components/ui/sidebar";
import { NavLink } from "@/components/NavLink";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { supabase } from "@/integrations/supabase/client";

const allClientNav = [
  { title: "Overview", url: "/dashboard", icon: LayoutDashboard, plans: ["starter", "pro", "enterprise"] },
  { title: "Chat Log", url: "/dashboard/chats", icon: MessageSquare, plans: ["starter", "pro", "enterprise"] },
  { title: "Inbox", url: "/dashboard/live-chat", icon: Inbox, plans: ["pro", "enterprise"] },
  { title: "Bot Settings", url: "/dashboard/bot", icon: Settings, plans: ["pro", "enterprise"] },
  { title: "Knowledge Base", url: "/dashboard/knowledge", icon: Globe, plans: ["pro", "enterprise"] },
  { title: "Channel Bot", url: "/dashboard/channels", icon: Radio, plans: ["starter", "pro", "enterprise"] },
  { title: "Agent", url: "/dashboard/agents", icon: Users, plans: ["pro", "enterprise"] },
  { title: "Chat Widget", url: "/dashboard/widget", icon: Code, plans: ["pro", "enterprise"] },
  { title: "Koneksi WA", url: "/dashboard/connection", icon: Wifi, plans: ["starter", "pro", "enterprise"] },
  { title: "Langganan", url: "/dashboard/subscription", icon: CreditCard, plans: ["starter", "pro", "enterprise"] },
  { title: "Invoice", url: "/dashboard/invoices", icon: Receipt, plans: ["starter", "pro", "enterprise"] },
  { title: "API Docs", url: "/dashboard/api-docs", icon: FileText, plans: ["starter", "pro", "enterprise"] },
  { title: "Profil", url: "/dashboard/profile", icon: User, plans: ["starter", "pro", "enterprise"] },
];

const adminNav = [
  { title: "Dashboard", url: "/admin", icon: LayoutDashboard },
  { title: "Kelola Klien", url: "/admin/clients", icon: Shield },
  { title: "Invoice", url: "/admin/invoices", icon: Receipt },
  { title: "Pengaturan", url: "/admin/settings", icon: Sliders },
];

function AppSidebar({ isAdmin }: { isAdmin: boolean }) {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { signOut, subscription, user } = useAuth();
  const navigate = useNavigate();
  const plan = subscription?.plan || "starter";
  const [unreadCount, setUnreadCount] = useState(0);

  // Unread badge for Inbox
  useEffect(() => {
    if (isAdmin || !user) return;
    const fetchUnread = async () => {
      const { count } = await (supabase.rpc as any)("get_unread_count_placeholder", {}).catch(() => ({ count: 0 }));
      // Simple approach: count unread via REST
      try {
        const session = (await supabase.auth.getSession()).data.session;
        const res = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/chat_messages?select=id&user_id=eq.${user.id}&is_read=eq.false`,
          { headers: { apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${session?.access_token}`, Prefer: "count=exact" } }
        );
        const total = parseInt(res.headers.get("content-range")?.split("/")?.[1] || "0");
        setUnreadCount(total);
      } catch { setUnreadCount(0); }
    };
    fetchUnread();

    const channel = supabase.channel("unread-badge")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, () => fetchUnread())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, isAdmin]);

  const handleLogout = async () => {
    await signOut();
    navigate("/");
  };

  const items = isAdmin ? adminNav : allClientNav;

  // Subscription expiry warning
  const expiryWarning = !isAdmin && subscription?.expires_at
    ? new Date(subscription.expires_at).getTime() - Date.now() < 7 * 24 * 60 * 60 * 1000
    : false;

  return (
    <Sidebar collapsible="icon">
      <SidebarContent className="flex flex-col h-full">
        <div className="p-4 flex items-center gap-2 border-b border-sidebar-border">
          <Bot className="h-6 w-6 text-primary flex-shrink-0" />
          {!collapsed && (
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm">ChatServis<span className="text-primary">.AI</span></span>
              {!isAdmin && (
                <Badge variant="outline" className="text-[10px] capitalize px-1.5 py-0">{plan}</Badge>
              )}
            </div>
          )}
        </div>
        <SidebarGroup>
          <SidebarGroupLabel>{isAdmin ? "Admin" : "Menu"}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => {
                const locked = !isAdmin && "plans" in item && !(item as any).plans.includes(plan);
                const isInbox = item.url === "/dashboard/live-chat";
                return (
                  <SidebarMenuItem key={item.title}>
                    {locked ? (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div className="flex items-center gap-2 px-3 py-2 text-muted-foreground/50 cursor-not-allowed">
                            <item.icon className="h-4 w-4" />
                            {!collapsed && <span className="flex-1">{item.title}</span>}
                            {!collapsed && <Lock className="h-3 w-3" />}
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>Upgrade paket untuk akses fitur ini</TooltipContent>
                      </Tooltip>
                    ) : (
                      <SidebarMenuButton asChild>
                        <NavLink to={item.url} end={item.url === "/dashboard" || item.url === "/admin"} className="hover:bg-sidebar-accent" activeClassName="bg-sidebar-accent text-primary font-medium">
                          <item.icon className="mr-2 h-4 w-4" />
                          {!collapsed && <span>{item.title}</span>}
                          {isInbox && unreadCount > 0 && !collapsed && (
                            <Badge className="ml-auto text-[10px] px-1.5 py-0 bg-destructive text-destructive-foreground">{unreadCount}</Badge>
                          )}
                          {isInbox && unreadCount > 0 && collapsed && (
                            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-destructive" />
                          )}
                        </NavLink>
                      </SidebarMenuButton>
                    )}
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <div className="mt-auto p-4 border-t border-sidebar-border">
          <Button variant="ghost" size="sm" className="w-full justify-start text-muted-foreground hover:text-foreground" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            {!collapsed && "Keluar"}
          </Button>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}

export default function DashboardLayout({ children, isAdmin = false }: { children: ReactNode; isAdmin?: boolean }) {
  const { profile, subscription } = useAuth();

  const expiryWarning = !isAdmin && subscription?.expires_at
    ? new Date(subscription.expires_at).getTime() - Date.now() < 7 * 24 * 60 * 60 * 1000
    : false;

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar isAdmin={isAdmin} />
        <div className="flex-1 flex flex-col min-w-0">
          {expiryWarning && (
            <div className="bg-warning/10 border-b border-warning/30 px-4 py-2 text-sm text-warning flex items-center justify-between">
              <span>⚠️ Langganan Anda berakhir {subscription?.expires_at ? new Date(subscription.expires_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }) : "segera"}.</span>
              <Link to="/dashboard/subscription" className="text-primary font-medium underline ml-2">Perpanjang sekarang →</Link>
            </div>
          )}
          <header className="h-14 flex items-center justify-between border-b border-border px-4 bg-card/50">
            <div className="flex items-center">
              <SidebarTrigger className="mr-4" />
              <span className="text-sm text-muted-foreground">
                {isAdmin ? "Admin Panel" : "Client Dashboard"}
              </span>
            </div>
            {profile && (
              <span className="text-sm text-muted-foreground">{profile.full_name || profile.email}</span>
            )}
          </header>
          <main className="flex-1 p-6 overflow-auto">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
