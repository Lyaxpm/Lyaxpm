(function() {
  const WIDGET_VERSION = "1.0.0";

  function initChatServisWidget(config) {
    if (!config || !config.userId) {
      console.error("ChatServis Widget: userId is required");
      return;
    }

    const supabaseUrl = config.supabaseUrl || "";
    const userId = config.userId;
    const position = config.position || "bottom-right";
    const primaryColor = config.primaryColor || "#2563eb";
    const title = config.title || "Chat dengan kami";

    // Styles
    const style = document.createElement("style");
    style.textContent = `
      .cs-widget-btn {
        position: fixed;
        ${position.includes("right") ? "right: 20px" : "left: 20px"};
        ${position.includes("bottom") ? "bottom: 20px" : "top: 20px"};
        width: 56px; height: 56px;
        border-radius: 50%;
        background: ${primaryColor};
        color: white;
        border: none;
        cursor: pointer;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        z-index: 99999;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s;
      }
      .cs-widget-btn:hover { transform: scale(1.1); }
      .cs-widget-btn svg { width: 24px; height: 24px; }
      .cs-widget-container {
        position: fixed;
        ${position.includes("right") ? "right: 20px" : "left: 20px"};
        ${position.includes("bottom") ? "bottom: 86px" : "top: 86px"};
        width: 380px;
        max-width: calc(100vw - 40px);
        height: 520px;
        max-height: calc(100vh - 120px);
        background: #0f1729;
        border: 1px solid #1e293b;
        border-radius: 16px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.5);
        z-index: 99998;
        display: none;
        flex-direction: column;
        overflow: hidden;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      }
      .cs-widget-container.open { display: flex; }
      .cs-widget-header {
        padding: 16px;
        background: ${primaryColor};
        color: white;
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .cs-widget-header h3 { margin: 0; font-size: 15px; font-weight: 600; }
      .cs-widget-header p { margin: 0; font-size: 12px; opacity: 0.8; }
      .cs-widget-messages {
        flex: 1;
        overflow-y: auto;
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .cs-msg {
        max-width: 80%;
        padding: 10px 14px;
        border-radius: 12px;
        font-size: 14px;
        line-height: 1.4;
        word-wrap: break-word;
      }
      .cs-msg.bot {
        background: #1e293b;
        color: #e2e8f0;
        align-self: flex-start;
        border-bottom-left-radius: 4px;
      }
      .cs-msg.user {
        background: ${primaryColor};
        color: white;
        align-self: flex-end;
        border-bottom-right-radius: 4px;
      }
      .cs-widget-input {
        padding: 12px 16px;
        border-top: 1px solid #1e293b;
        display: flex;
        gap: 8px;
      }
      .cs-widget-input input {
        flex: 1;
        padding: 10px 14px;
        border: 1px solid #1e293b;
        border-radius: 8px;
        background: #1e293b;
        color: #e2e8f0;
        font-size: 14px;
        outline: none;
      }
      .cs-widget-input input:focus { border-color: ${primaryColor}; }
      .cs-widget-input button {
        padding: 10px 16px;
        background: ${primaryColor};
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
      }
      .cs-widget-input button:disabled { opacity: 0.5; cursor: not-allowed; }
      .cs-typing { color: #94a3b8; font-style: italic; font-size: 13px; }
    `;
    document.head.appendChild(style);

    // Button
    const btn = document.createElement("button");
    btn.className = "cs-widget-btn";
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>';
    document.body.appendChild(btn);

    // Container
    const container = document.createElement("div");
    container.className = "cs-widget-container";
    container.innerHTML = `
      <div class="cs-widget-header">
        <div>
          <h3>${title}</h3>
          <p>Powered by ChatServis.AI</p>
        </div>
      </div>
      <div class="cs-widget-messages" id="cs-messages"></div>
      <div class="cs-widget-input">
        <input type="text" id="cs-input" placeholder="Ketik pesan..." />
        <button id="cs-send">Kirim</button>
      </div>
    `;
    document.body.appendChild(container);

    let isOpen = false;
    let conversationId = null;
    let sending = false;
    const messagesEl = container.querySelector("#cs-messages");
    const inputEl = container.querySelector("#cs-input");
    const sendBtn = container.querySelector("#cs-send");

    btn.addEventListener("click", () => {
      isOpen = !isOpen;
      container.classList.toggle("open", isOpen);
      if (isOpen && messagesEl.children.length === 0) {
        addMessage("bot", "Halo! Ada yang bisa saya bantu? 😊");
      }
    });

    function addMessage(type, text) {
      const div = document.createElement("div");
      div.className = "cs-msg " + type;
      div.textContent = text;
      messagesEl.appendChild(div);
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    async function sendMessage() {
      const msg = inputEl.value.trim();
      if (!msg || sending) return;
      sending = true;
      sendBtn.disabled = true;
      inputEl.value = "";
      addMessage("user", msg);

      // Add typing indicator
      const typing = document.createElement("div");
      typing.className = "cs-typing";
      typing.textContent = "Mengetik...";
      messagesEl.appendChild(typing);
      messagesEl.scrollTop = messagesEl.scrollHeight;

      try {
        const res = await fetch(supabaseUrl + "/functions/v1/ai-chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: msg,
            user_id: userId,
            conversation_id: conversationId,
            contact_number: "widget-" + Date.now(),
          }),
        });

        typing.remove();

        if (!res.ok) {
          addMessage("bot", "Maaf, terjadi kesalahan. Silakan coba lagi.");
          sending = false;
          sendBtn.disabled = false;
          return;
        }

        // Handle SSE stream
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let botMsg = "";
        const botDiv = document.createElement("div");
        botDiv.className = "cs-msg bot";
        messagesEl.appendChild(botDiv);

        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          let idx;
          while ((idx = buffer.indexOf("\n")) !== -1) {
            const line = buffer.slice(0, idx).trim();
            buffer = buffer.slice(idx + 1);
            if (!line.startsWith("data: ") || line === "data: [DONE]") continue;
            try {
              const parsed = JSON.parse(line.slice(6));
              const content = parsed.choices?.[0]?.delta?.content;
              if (content) {
                botMsg += content;
                botDiv.textContent = botMsg;
                messagesEl.scrollTop = messagesEl.scrollHeight;
              }
            } catch {}
          }
        }

        if (!botMsg) botDiv.textContent = "...";
      } catch (err) {
        typing.remove();
        addMessage("bot", "Maaf, terjadi kesalahan koneksi.");
      }

      sending = false;
      sendBtn.disabled = false;
    }

    sendBtn.addEventListener("click", sendMessage);
    inputEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter") sendMessage();
    });
  }

  // Expose globally
  window.ChatServisWidget = { init: initChatServisWidget };
})();
