# POAP dApp Setup Guide

## 🚀 Quick Start

This is a complete POAP (Proof of Attendance Protocol) dApp template built with React, TypeScript, and Tailwind CSS. It includes vLayer ZK proof integration and smart contract support.

## 🛠️ Environment Variables

Create a `.env.local` file in the root directory:

```env
# vLayer Configuration
VITE_VLAYER_API_KEY=your_vlayer_api_key_here

# Smart Contract
VITE_POAP_CONTRACT_ADDRESS=0x_your_contract_address_here

# Blockchain Providers (Optional)
VITE_ALCHEMY_API_KEY=your_alchemy_api_key
VITE_INFURA_API_KEY=your_infura_api_key
VITE_WALLETCONNECT_PROJECT_ID=your_walletconnect_project_id
```

## 📦 Required Dependencies

Install the additional dependencies for full functionality:

```bash
# Core Web3 dependencies
npm install wagmi viem @tanstack/react-query

# Optional: Better wallet UX
npm install @rainbow-me/rainbowkit

# vLayer SDK (when available)
npm install @vlayer/sdk
```

## 🔧 Integration Steps

### 1. vLayer Integration

1. Sign up for vLayer API access
2. Update `src/lib/vlayer.ts` with actual SDK imports:

```typescript
import { VLayerSDK, generateProof, verifyProof } from '@vlayer/sdk';

export const initVLayer = (config: VLayerConfig) => {
  return new VLayerSDK(config);
};
```

3. Replace mock functions with real vLayer calls

### 2. Wallet Connect Setup

1. Uncomment the wagmi imports in `src/lib/wagmi-config.ts`
2. Wrap your app with WagmiConfig:

```typescript
import { WagmiConfig } from 'wagmi';
import { wagmiConfig } from './lib/wagmi-config';

function App() {
  return (
    <WagmiConfig config={wagmiConfig}>
      {/* Your app components */}
    </WagmiConfig>
  );
}
```

3. Update Header component to use real wallet connection:

```typescript
import { useAccount, useConnect, useDisconnect } from 'wagmi';

const Header = () => {
  const { address, isConnected } = useAccount();
  const { connect, connectors } = useConnect();
  const { disconnect } = useDisconnect();
  
  // Update wallet connect button logic
};
```

### 3. Smart Contract Deployment

Deploy the POAP contract using Hardhat or Foundry:

```solidity
// contracts/POAPContract.sol
// (See full contract code in src/contracts/POAPContract.ts)
```

Deploy commands:
```bash
# Using Hardhat
npx hardhat deploy --network polygon

# Using Foundry
forge create POAPContract --rpc-url $RPC_URL --private-key $PRIVATE_KEY
```

### 4. Update Contract Interactions

Replace mock contract calls in `src/contracts/POAPContract.ts`:

```typescript
import { useContractWrite, useContractRead } from 'wagmi';

export const useMintPOAP = () => {
  return useContractWrite({
    ...POAP_CONTRACT_CONFIG,
    functionName: 'mint',
  });
};
```

## 🎨 Customization Guide

### Design System

The app uses a comprehensive design system defined in:
- `src/index.css` - Color tokens and design variables
- `tailwind.config.ts` - Extended Tailwind configuration
- `src/components/ui/` - Reusable UI components

### Modular Components

Each page is built with modular components:
- `src/pages/Home.tsx` - Landing page with hero section
- `src/pages/CreateEvent.tsx` - Event creation with QR generation
- `src/pages/ClaimPOAP.tsx` - Identity verification and POAP minting
- `src/components/layout/` - Header and layout components

### Color Scheme Customization

Update the HSL values in `src/index.css`:

```css
:root {
  --primary: 263 70% 50%;        /* Purple theme */
  --secondary: 217 91% 60%;       /* Blue accent */
  --primary-glow: 263 70% 60%;    /* Lighter purple */
  /* Add your custom colors */
}
```

## 🧪 Testing with Mock Data

The app includes comprehensive mock data for testing:

1. **Event Creation**: Creates mock events with QR codes
2. **Identity Verification**: Simulates vLayer ZK proof generation
3. **POAP Minting**: Mock ERC-1155 minting process

## 🚀 Production Deployment

1. Build the application:
```bash
npm run build
```

2. Deploy to your preferred platform:
   - Vercel: `vercel deploy`
   - Netlify: `netlify deploy`
   - AWS/Azure/GCP static hosting

3. Configure environment variables in your deployment platform

4. Set up domain and SSL certificates

## 🔍 Key Features

- ✅ **Zero-Knowledge Verification**: Privacy-preserving identity verification
- ✅ **QR Code Generation**: Automatic event check-in QR codes
- ✅ **ERC-1155 POAP Minting**: Standard NFT minting for proof of attendance
- ✅ **Responsive Design**: Mobile-first responsive design
- ✅ **Modular Architecture**: Easy to customize and extend
- ✅ **TypeScript**: Full type safety throughout the application
- ✅ **Modern UI**: Beautiful gradients and animations

## 📚 Documentation

- **vLayer Docs**: [vLayer Documentation](https://docs.vlayer.xyz)
- **Wagmi Docs**: [Wagmi Documentation](https://wagmi.sh)
- **Tailwind CSS**: [Tailwind CSS Documentation](https://tailwindcss.com)

## 🐛 Troubleshooting

### Common Issues

1. **Build Errors**: Ensure all dependencies are installed
2. **Wallet Connection**: Check network configuration in wagmi-config
3. **Contract Interaction**: Verify contract address and ABI
4. **vLayer Integration**: Ensure API key is correctly configured

### Debug Mode

Enable debug logging by adding to your environment:
```env
VITE_DEBUG=true
```

## 🤝 Contributing

This template is designed to be easily customizable. Key areas for extension:

1. **Additional Verification Methods**: Extend vLayer integration
2. **Multi-chain Support**: Add support for more blockchain networks
3. **Advanced UI Components**: Add more interactive components
4. **Analytics Integration**: Add event tracking and analytics
5. **Backend Integration**: Connect to databases for event management

## 📄 License

This template is provided as-is for educational and development purposes. Customize as needed for your specific use case.