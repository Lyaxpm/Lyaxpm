import { Button } from "@/components/ui/button";
import { Link, useLocation } from "react-router-dom";
import { Wallet, Zap } from "lucide-react";

const Header = () => {
  const location = useLocation();

  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Zap className="h-8 w-8 text-primary glow-effect" />
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              POAP Forge
            </span>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link
              to="/"
              className={`font-medium transition-colors hover:text-primary ${
                location.pathname === "/" ? "text-primary" : "text-muted-foreground"
              }`}
            >
              Home
            </Link>
            <Link
              to="/create"
              className={`font-medium transition-colors hover:text-primary ${
                location.pathname === "/create" ? "text-primary" : "text-muted-foreground"
              }`}
            >
              Create Event
            </Link>
            <Link
              to="/claim"
              className={`font-medium transition-colors hover:text-primary ${
                location.pathname === "/claim" ? "text-primary" : "text-muted-foreground"
              }`}
            >
              Claim POAP
            </Link>
          </nav>

          {/* Wallet Connect Button */}
          <Button variant="outline" className="flex items-center gap-2">
            <Wallet className="h-4 w-4" />
            Connect Wallet
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;