import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { QrCode, Shield, Zap, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSearchParams } from "react-router-dom";

interface VerificationStatus {
  status: 'idle' | 'verifying' | 'verified' | 'failed';
  method?: 'email' | 'telegram';
  proof?: string;
}

interface EventInfo {
  id: string;
  name: string;
  date: string;
  location: string;
  organizer: string;
}

const ClaimPOAP = () => {
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const eventId = searchParams.get('event');
  
  const [email, setEmail] = useState("");
  const [telegramUsername, setTelegramUsername] = useState("");
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>({ status: 'idle' });
  const [isMinting, setIsMinting] = useState(false);
  const [mintingComplete, setMintingComplete] = useState(false);
  const [eventInfo, setEventInfo] = useState<EventInfo | null>(null);

  // Mock event data (in real app, fetch from API)
  useEffect(() => {
    if (eventId) {
      // Simulate fetching event data
      setTimeout(() => {
        setEventInfo({
          id: eventId,
          name: "Web3 Conference 2024",
          date: "2024-03-15",
          location: "San Francisco, CA",
          organizer: "Crypto Events Inc."
        });
      }, 500);
    }
  }, [eventId]);

  const handleVerification = async (method: 'email' | 'telegram') => {
    const identifier = method === 'email' ? email : telegramUsername;
    
    if (!identifier.trim()) {
      toast({
        title: "Missing Information",
        description: `Please enter your ${method === 'email' ? 'email address' : 'Telegram username'}.`,
        variant: "destructive"
      });
      return;
    }

    setVerificationStatus({ status: 'verifying', method });

    try {
      // Simulate vLayer ZK verification
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Simulate proof generation
      const mockProof = `zk_proof_${method}_${Date.now()}`;
      
      setVerificationStatus({ 
        status: 'verified', 
        method, 
        proof: mockProof 
      });
      
      toast({
        title: "Verification Successful!",
        description: "Your identity has been verified using zero-knowledge proofs.",
        variant: "default"
      });
    } catch (error) {
      setVerificationStatus({ status: 'failed', method });
      toast({
        title: "Verification Failed",
        description: "Unable to verify your identity. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleMintPOAP = async () => {
    if (verificationStatus.status !== 'verified') return;

    setIsMinting(true);
    
    try {
      // Simulate smart contract interaction
      await new Promise(resolve => setTimeout(resolve, 4000));
      
      setMintingComplete(true);
      toast({
        title: "POAP Minted Successfully!",
        description: "Your Proof of Attendance NFT has been minted to your wallet.",
        variant: "default"
      });
    } catch (error) {
      toast({
        title: "Minting Failed",
        description: "Failed to mint POAP. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsMinting(false);
    }
  };

  if (mintingComplete) {
    return (
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <div className="h-20 w-20 mx-auto bg-success/10 rounded-full flex items-center justify-center">
            <CheckCircle className="h-10 w-10 text-success" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-success to-primary bg-clip-text text-transparent">
            POAP Minted Successfully!
          </h1>
          <p className="text-xl text-muted-foreground">
            Your Proof of Attendance NFT is now in your wallet
          </p>
        </div>

        <Card className="card-glow border-success/20">
          <CardContent className="p-8 text-center space-y-6">
            <div className="p-6 bg-success/5 rounded-2xl space-y-4">
              <div className="text-6xl">🏆</div>
              <h3 className="text-2xl font-bold">{eventInfo?.name || "Event"}</h3>
              <p className="text-muted-foreground">{eventInfo?.date} • {eventInfo?.location}</p>
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Token Standard:</span>
                <span>ERC-1155</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Verification Method:</span>
                <Badge variant="outline">{verificationStatus.method}</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">ZK Proof:</span>
                <span className="font-mono text-xs truncate max-w-32">{verificationStatus.proof}</span>
              </div>
            </div>

            <Button variant="gradient" className="w-full">
              View in Wallet
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
          Claim Your POAP
        </h1>
        <p className="text-xl text-muted-foreground">
          Verify your attendance and mint your Proof of Attendance NFT
        </p>
      </div>

      {/* Event Info */}
      {eventInfo && (
        <Card className="card-glow">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 bg-primary/10 rounded-2xl flex items-center justify-center">
                <QrCode className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold">{eventInfo.name}</h3>
                <p className="text-muted-foreground">{eventInfo.date} • {eventInfo.location}</p>
                <p className="text-sm text-muted-foreground">By {eventInfo.organizer}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Verification Section */}
      <Card className="card-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Identity Verification
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              We use vLayer's zero-knowledge proofs to verify your identity without revealing personal information.
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Verification</Label>
              <div className="flex gap-2">
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={verificationStatus.status === 'verifying'}
                />
                <Button
                  variant="outline"
                  onClick={() => handleVerification('email')}
                  disabled={verificationStatus.status === 'verifying' || verificationStatus.status === 'verified'}
                >
                  {verificationStatus.status === 'verifying' && verificationStatus.method === 'email' ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : verificationStatus.status === 'verified' && verificationStatus.method === 'email' ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : (
                    "Verify"
                  )}
                </Button>
              </div>
            </div>

            <div className="text-center text-muted-foreground">OR</div>

            <div className="space-y-2">
              <Label htmlFor="telegram">Telegram Verification</Label>
              <div className="flex gap-2">
                <Input
                  id="telegram"
                  placeholder="Enter your Telegram username"
                  value={telegramUsername}
                  onChange={(e) => setTelegramUsername(e.target.value)}
                  disabled={verificationStatus.status === 'verifying'}
                />
                <Button
                  variant="outline"
                  onClick={() => handleVerification('telegram')}
                  disabled={verificationStatus.status === 'verifying' || verificationStatus.status === 'verified'}
                >
                  {verificationStatus.status === 'verifying' && verificationStatus.method === 'telegram' ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : verificationStatus.status === 'verified' && verificationStatus.method === 'telegram' ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : (
                    "Verify"
                  )}
                </Button>
              </div>
            </div>
          </div>

          {verificationStatus.status === 'verified' && (
            <Alert className="border-success/50 bg-success/5">
              <CheckCircle className="h-4 w-4 text-success" />
              <AlertDescription className="text-success">
                Verification successful! ZK proof generated: <code className="font-mono text-xs">{verificationStatus.proof}</code>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Mint POAP Section */}
      <Card className="card-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Mint Your POAP
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-muted-foreground">
            After successful verification, you can mint your Proof of Attendance NFT using our ERC-1155 smart contract.
          </p>

          <Button
            variant="gradient"
            size="lg"
            className="w-full"
            onClick={handleMintPOAP}
            disabled={verificationStatus.status !== 'verified' || isMinting}
          >
            {isMinting ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Minting POAP...
              </>
            ) : verificationStatus.status !== 'verified' ? (
              "Complete Verification First"
            ) : (
              <>
                <Zap className="h-5 w-5" />
                Mint POAP NFT
              </>
            )}
          </Button>

          {verificationStatus.status !== 'verified' && (
            <p className="text-sm text-muted-foreground text-center">
              Please complete identity verification to enable minting.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ClaimPOAP;