import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { QRCodeSVG } from "qrcode.react";
import { CalendarDays, MapPin, Users, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface EventData {
  name: string;
  date: string;
  time: string;
  location: string;
  description: string;
  capacity: string;
}

const CreateEvent = () => {
  const { toast } = useToast();
  const [eventData, setEventData] = useState<EventData>({
    name: "",
    date: "",
    time: "",
    location: "",
    description: "",
    capacity: ""
  });
  const [eventCreated, setEventCreated] = useState(false);
  const [eventId] = useState(() => `event_${Date.now()}`);
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleInputChange = (field: keyof EventData, value: string) => {
    setEventData(prev => ({ ...prev, [field]: value }));
  };

  const handleCreateEvent = async () => {
    if (!eventData.name || !eventData.date || !eventData.time) {
      toast({
        title: "Missing Information",
        description: "Please fill in at least event name, date, and time.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    
    try {
      // Simulate API call to create event
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Generate QR code URL for check-in
      const checkInUrl = `${window.location.origin}/claim?event=${eventId}`;
      setQrCodeUrl(checkInUrl);
      setEventCreated(true);
      
      toast({
        title: "Event Created Successfully!",
        description: "Your QR code has been generated for attendee check-in.",
        variant: "default"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create event. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(qrCodeUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Copied!",
        description: "Check-in URL copied to clipboard",
      });
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please copy the URL manually",
        variant: "destructive"
      });
    }
  };

  if (eventCreated) {
    return (
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Event Created Successfully!
          </h1>
          <p className="text-xl text-muted-foreground">
            Share this QR code with your attendees for check-in
          </p>
        </div>

        <Card className="card-glow">
          <CardHeader>
            <CardTitle className="text-center">Event Check-in QR Code</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex justify-center">
              <div className="p-8 bg-white rounded-2xl">
                <QRCodeSVG 
                  value={qrCodeUrl} 
                  size={256}
                  bgColor="#ffffff"
                  fgColor="#000000"
                  level="H"
                />
              </div>
            </div>
            
            <div className="space-y-4">
              <Label>Check-in URL:</Label>
              <div className="flex gap-2">
                <Input value={qrCodeUrl} readOnly className="font-mono text-sm" />
                <Button variant="outline" size="icon" onClick={copyToClipboard}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="p-4 bg-muted/50 rounded-lg space-y-2">
              <h3 className="font-semibold text-lg">{eventData.name}</h3>
              <div className="flex items-center gap-2 text-muted-foreground">
                <CalendarDays className="h-4 w-4" />
                {eventData.date} at {eventData.time}
              </div>
              {eventData.location && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  {eventData.location}
                </div>
              )}
              {eventData.capacity && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="h-4 w-4" />
                  Max {eventData.capacity} attendees
                </div>
              )}
            </div>

            <div className="flex gap-4">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => setEventCreated(false)}
              >
                Create Another Event
              </Button>
              <Button variant="gradient" className="flex-1">
                Download QR Code
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
          Create New Event
        </h1>
        <p className="text-xl text-muted-foreground">
          Set up your event and generate a QR code for attendee verification
        </p>
      </div>

      <Card className="card-glow">
        <CardHeader>
          <CardTitle>Event Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Event Name *</Label>
            <Input
              id="name"
              placeholder="Enter event name"
              value={eventData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                type="date"
                value={eventData.date}
                onChange={(e) => handleInputChange("date", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="time">Time *</Label>
              <Input
                id="time"
                type="time"
                value={eventData.time}
                onChange={(e) => handleInputChange("time", e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              placeholder="Enter event location"
              value={eventData.location}
              onChange={(e) => handleInputChange("location", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="capacity">Expected Attendees</Label>
            <Input
              id="capacity"
              type="number"
              placeholder="Enter expected number of attendees"
              value={eventData.capacity}
              onChange={(e) => handleInputChange("capacity", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe your event"
              rows={4}
              value={eventData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
            />
          </div>

          <Button 
            variant="gradient" 
            className="w-full" 
            size="lg"
            onClick={handleCreateEvent}
            disabled={isLoading}
          >
            {isLoading ? "Creating Event..." : "Create Event & Generate QR Code"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default CreateEvent;