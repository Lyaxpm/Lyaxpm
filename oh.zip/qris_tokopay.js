require("dotenv").config();
const axios = require("axios");
const {
  Order
} = require("./db");
const qs = require('qs');
const QRCode = require('qrcode');

async function createOrder(internalOrderId, amount, orderDetails, customerInfo) {
  const api_key = process.env.API_KEY_ATLANTIC;

  if (!api_key) {
    throw new Error("API_KEY_ATLANTIC is required");
  }

  const nominalAmount = parseInt(amount);
  if (isNaN(nominalAmount) || nominalAmount <= 0) {
    throw new Error("Amount harus berupa angka positif");
  }

  const data = qs.stringify({
    api_key: api_key,
    reff_id: internalOrderId,
    nominal: nominalAmount.toString(),
    type: "ewallet",
    metode: "qris"
  });

  const config = {
    method: 'post',
    maxBodyLength: Infinity,
    url: 'https://atlantich2h.com/deposit/create',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    data: data
  };

  console.log("Request to Atlantic:", {
    reff_id: internalOrderId,
    nominal: nominalAmount
  });

  try {
    const response = await axios(config);
    console.log("Atlantic Response:", JSON.stringify(response.data, null, 2));

    const result = response.data;

    if (!result.status || result.status !== true) {
      throw new Error(result.message || "AtlanticH2H API Error");
    }

    const paymentData = result.data;

    const totalBayar = parseInt(paymentData.nominal) + parseInt(paymentData.tambahan || 0) + parseInt(paymentData.fee || 0);
    const totalDiterima = parseInt(paymentData.get_balance);
    const fee = totalBayar - totalDiterima;

    console.log("Generating QR from qrString...");

    const qrDataURL = await QRCode.toDataURL(paymentData.qr_string, {
      type: 'image/png',
      width: 512,
      margin: 2,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });

    return {
      qrImage: qrDataURL,
      displayOrderId: internalOrderId,
      realOrderId: paymentData.id,
      amount: totalBayar,
      totalBayar: totalBayar,
      totalDiterima: totalDiterima,
      fee: fee,
      expiredAt: paymentData.expired_at,
      qrString: paymentData.qr_string
    };

  } catch (error) {
    if (error.response) {
      console.error("Atlantic API Error:", {
        status: error.response.status,
        data: error.response.data
      });
      throw new Error(error.response.data?.message || "AtlanticH2H API Error");
    }
    console.error("Error:", error.message);
    throw error;
  }
}

async function checkPaymentStatus(orderId, amount) {
  const order = await Order.findOne({
    orderId
  });
  if (!order) return {
    status: "NOT_FOUND"
  };

  if (["PAID", "EXPIRED", "CANCELLED"].includes(order.status)) {
    console.log(`[ATLANTIC CHECK] Order ${orderId} sudah ${order.status}`);
    return {
      status: order.status,
      order
    };
  }

  const api_key = process.env.API_KEY_ATLANTIC;

  const body = qs.stringify({
    api_key: api_key,
    id: order.internalRefId
  });

  try {
    const response = await axios.post(
      "https://atlantich2h.com/deposit/status",
      body,
      {
        maxBodyLength: Infinity
      }
    );

    const data = response.data;
    console.log("[ATLANTIC RESPONSE]", data);

    if (data.status !== "true" || !data.data) {
      console.log(`[ATLANTIC CHECK] Data tidak valid untuk ${orderId}`);
      return {
        status: "PENDING",
        order
      };
    }

    const trx = data.data;

    const paymentStatus = String(trx.status || "").toLowerCase();
    console.log(`[ATLANTIC STATUS] ${orderId} => ${paymentStatus}`);

    if (paymentStatus === "pending") {
      return {
        status: "PENDING",
        order
      };
    }

    if (paymentStatus === "success") {
      if (order.status === "PENDING") {
        order.status = "PAID";
        order.paidAt = new Date();
        order.paymentDetails = trx;
        await order.save();
      }
      return {
        status: "PAID",
        order
      };
    }

    order.status = "EXPIRED";
    order.paymentDetails = trx;
    await order.save();

    return {
      status: "EXPIRED",
      order
    };

  } catch (err) {
    console.error("[ATLANTIC ERROR]", err.response?.data || err.message);
    return {
      status: "PENDING",
      order
    };
  }
}

async function updateStokKeLaravel(sku, items) {}

module.exports = {
  init: async () => console.log("[ Tokopay Payment System Initialized (URL Method) ]"),
  createOrder,
  checkPaymentStatus,
  updateStokKeLaravel,
};