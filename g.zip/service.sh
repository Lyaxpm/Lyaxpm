#!/system/bin/sh
#
# SkiaVK-Renderer by the kazuyoo  
# Open-source powered — with appreciation to AOSP, Google Graphics Team, and all contributors.  
# Licensed under the MIT License.  
#
# Enables the Skia Vulkan (SkiaVK) rendering backend for the Android RenderEngine  
# to deliver smoother animations, reduced jank, and improved GPU efficiency.  
# SkiaVK leverages Vulkan’s low-overhead graphics pipeline, asynchronous command queues,  
# and advanced memory management for faster UI composition and frame rendering.  
#
# Optimized for both daily and gaming scenarios — offering balanced performance,  
# better thermal control, and consistent frame pacing without unnecessary GPU strain.

# ----------------- HELPER FUNCTIONS -----------------
send_notification() {
    # Notify user of optimization completion
    cmd notification post -S bigtext -t 'SkiaVK-Renderer 💀' 'tag' 'Status :  Optimization Completed!' >/dev/null 2>&1
}

# ----------------- OPTIMIZATION SECTIONS -----------------
  setprop debug.hwui.renderer skiavk
  setprop debug.renderengine.backend skiavkthreaded
  setprop debug.renderengine.capture_skia_ms 0
  setprop debug.renderengine.skia_atrace_enabled false
  setprop debug.renderengine.skia_tracing_enabled false
  setprop debug.renderengine.skia_use_perfetto_track_events false
  setprop debug.hwui.skia_use_perfetto_track_events false
  setprop debug.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_tracing_enabled false
  setprop debug.tracing.ctl.hwui.skia_use_perfetto_track_events false
  setprop debug.tracing.ctl.renderengine.skia_tracing_enabled false
  setprop debug.tracing.ctl.renderengine.skia_use_perfetto_track_events false  
  
  # From @HoyoSlave
  input keyevent 26;eval "$(cmd package list packages|grep -v ia.mo|sed "s/package:/cmd activity force-stop /g"|sed "s/$/\&/g")";input keyevent 26

# Main Execution & Exit script successfully
 sync;send_notification