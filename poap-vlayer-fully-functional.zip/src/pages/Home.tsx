import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { CalendarPlus, QrCode, Shield, Zap } from "lucide-react";
import heroImage from "@/assets/hero-poap.jpg";

const Home = () => {
  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={heroImage} 
            alt="POAP Hero" 
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/80 to-background/40" />
        </div>
        
        <div className="relative text-center py-24 space-y-8">
          <h1 className="text-6xl md:text-7xl font-bold leading-tight">
            <span className="bg-gradient-to-r from-primary via-primary-glow to-secondary bg-clip-text text-transparent">
              Mint Your Proof
            </span>
            <br />
            <span className="text-foreground">of Attendance</span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Create verifiable POAPs with zero-knowledge proofs using vLayer. 
            Secure, private, and fully decentralized event attendance verification.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/create">
              <Button variant="gradient" size="lg" className="w-full sm:w-auto">
                <CalendarPlus className="h-5 w-5" />
                Create Event
              </Button>
            </Link>
            <Link to="/claim">
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                <QrCode className="h-5 w-5" />
                Claim POAP
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl font-bold">Why Choose POAP Forge?</h2>
          <p className="text-xl text-muted-foreground">
            Built with cutting-edge Web3 technology for seamless event management
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <Card className="card-glow border-border/50">
            <CardContent className="p-8 text-center space-y-4">
              <div className="h-16 w-16 mx-auto bg-primary/10 rounded-2xl flex items-center justify-center">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-semibold">ZK Verification</h3>
              <p className="text-muted-foreground">
                Privacy-preserving identity verification using vLayer's zero-knowledge proofs.
                Verify attendance without revealing personal data.
              </p>
            </CardContent>
          </Card>

          <Card className="card-glow border-border/50">
            <CardContent className="p-8 text-center space-y-4">
              <div className="h-16 w-16 mx-auto bg-secondary/10 rounded-2xl flex items-center justify-center">
                <QrCode className="h-8 w-8 text-secondary" />
              </div>
              <h3 className="text-2xl font-semibold">QR Code System</h3>
              <p className="text-muted-foreground">
                Seamless check-in process with automatically generated QR codes.
                Simple scan-to-verify attendance system.
              </p>
            </CardContent>
          </Card>

          <Card className="card-glow border-border/50">
            <CardContent className="p-8 text-center space-y-4">
              <div className="h-16 w-16 mx-auto bg-primary-glow/10 rounded-2xl flex items-center justify-center">
                <Zap className="h-8 w-8 text-primary-glow" />
              </div>
              <h3 className="text-2xl font-semibold">Instant Minting</h3>
              <p className="text-muted-foreground">
                Mint your POAP NFT instantly after verification. 
                ERC-1155 standard for maximum compatibility.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="text-center space-y-8 py-16">
        <div className="gradient-border rounded-2xl max-w-4xl mx-auto">
          <div className="p-12 space-y-6">
            <h2 className="text-4xl font-bold">Ready to Get Started?</h2>
            <p className="text-xl text-muted-foreground">
              Join the future of event verification with POAP Forge
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/create">
                <Button variant="gradient" size="lg">
                  Create Your First Event
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;