import cmd from "./map.js";
import { procMsg } from "../utils/msg.js";
class CommandHandler {
  async handleCommand(processedMessage, socket, store, Scrapers, db) {
    const ownerNumbers = process.env.OWNER
      ? process.env.OWNER.split(",").map((o) => o.trim() + "@s.whatsapp.net")
      : [];
    await db.main(processedMessage);
    if (
      db.list().settings.self &&
      !ownerNumbers.includes(processedMessage.sender) &&
      !db.list().settings.whitelist.includes(processedMessage.chat)
    )
      return;
    let src = Scrapers.result;
    let messageText = (processedMessage.body || "").trim();
    let parseResult = this.parseCommand(messageText);
    let commandName = parseResult[0];
    let args = parseResult[1];
    let text = args.join(" ") || "";
    const context = {
      m: processedMessage,
      sock: socket,
      store: store,
      text,
      db,
      args,
      src,
      command: commandName,
      isCmd: this.isCommand(messageText),
    };
    for (const command of cmd.values()) {
      if (command.middleware) {
        await Promise.resolve(command.middleware(context));
      }
    }
    if (context.isCmd) {
      const foundCommand = cmd.values().find((plugin) => {
        if (!plugin) return false;
        const nameMatch =
          typeof plugin.name === "string" &&
          plugin.name.toLowerCase().trim() === commandName;
        const aliasMatch =
          Array.isArray(plugin.alias) &&
          plugin.alias.map((a) => a.toLowerCase().trim()).includes(commandName);
        return nameMatch || aliasMatch;
      });
      if (foundCommand) {
        if (!foundCommand.run) return;
        try {
          if (!this.checkPermissions(foundCommand, processedMessage, socket)) {
            processedMessage.reply(
              "You do not have permission to use this command.",
            );
            return;
          }
          await Promise.resolve(foundCommand.run(context));
        } catch (error) {
          console.error(`Error executing command '${commandName}':`, error);
          processedMessage.reply(
            `An error occurred while executing the command: ${error.message}`,
          );
        }
      }
    }
  }
  isCommand(text) {
    return /^(!|\/|\.)/.test(text);
  }
  parseCommand(text) {
    const args = text.slice(1).trim().split(/\s+/);
    const commandName = args.shift()?.toLowerCase() || "";
    return [commandName, args];
  }
  checkPermissions(command, message, sock) {
    const ownerNumbers = process.env.OWNER
      ? process.env.OWNER.split(",").map((o) => o.trim())
      : [];
    const owners = [...ownerNumbers, sock?.user?.id?.split(":")[0]].filter(
      Boolean,
    );
    console.log(owners);
    if (
      command.isOwner &&
      !owners.includes((message.sender || "").split("@")[0])
    ) {
      return false;
    }
    if (command.isGroup && !message.isGroup) {
      return false;
    }
    if (command.isPrivate && message.isGroup) {
      return false;
    }
    if (command.isSelf && !message.fromMe) {
      return false;
    }
    return true;
  }
}
export default new CommandHandler();
