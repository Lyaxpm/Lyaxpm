import { readdir } from "fs/promises";
import path from "path";
import { pathToFileURL } from "url";
import chokidar from "chokidar";
import fs from "fs";
class Scrapers {
  constructor(dir) {
    this.basePath = path.resolve(process.cwd(), dir);
    this.result = {};
  }
  async load() {
    const files = await readdir(this.basePath);
    for (const file of files) {
      if (!file.endsWith(".js")) continue;
      try {
        const fileUrl =
          pathToFileURL(path.join(this.basePath, file)).href +
          `?update=${Date.now()}`;
        const module = await import(fileUrl);
        this.result[file.replace(/\.js$/, "")] = module.default ?? module;
      } catch (e) {
        console.error(`[SCRAPER ERROR] ${file}`, e.message);
      }
    }
  }
  async watch() {
    if (!fs.existsSync(this.basePath)) {
      console.log(`Scraper directory does not exist: ${this.basePath}`);
      console.log(`Creating directory: ${this.basePath}`);
      fs.mkdirSync(this.basePath, { recursive: true });
    }
    console.log(`Watching Scraper directory: ${this.basePath}`);
    chokidar
      .watch(this.basePath, { ignoreInitial: true })
      .on("add", async (path) => {
        console.log(
          `\x1b[33m[WATCH]\x1b[0m New Scraper file detected: ${path}`,
        );
        await this.load();
      })
      .on("change", async (path) => {
        console.log(`\x1b[33m[WATCH]\x1b[0m Scraper file changed: ${path}`);
        await this.load();
      })
      .on("unlink", async (path) => {
        console.log(`\x1b[33m[WATCH]\x1b[0m Scraper file deleted: ${path}`);
        await this.load();
      })
      .on("error", (error) => {
        console.error(
          `\x1b[31m[ERROR]\x1b[0m Error watching directory:`,
          error,
        );
      });
  }
}
export default new Scrapers("./src/scrapers/src");
