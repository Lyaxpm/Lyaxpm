import axios from "axios";
import * as cheerio from "cheerio";
import https from "https";
import moment from "moment-timezone";

const agent = new https.Agent({
  rejectUnauthorized: true,
  maxVersion: "TLSv1.3",
  minVersion: "TLSv1.2",
});

class Pinterest {
  getCookies = async () => {
    const { data, headers } = await axios
      .get("https://www.pinterest.com/")
      .catch((e) => e.response);
    return headers["set-cookie"].map((a) => a.split(";")[0]).join("; ");
  };
  search = async function (query) {
    const cookies = await this.getCookies();
    if (!cookies) {
      console.log("Failed to retrieve cookies. Exiting.");
      return [];
    }

    const url = "https://www.pinterest.com/resource/BaseSearchResource/get/";
    const params = {
      source_url: `/search/pins/?q=${query}`,
      data: JSON.stringify({
        options: {
          isPrefetch: false,
          query: query,
          scope: "pins",
          no_fetch_context_on_resource: false,
        },
        context: {},
      }),
      _: Date.now(),
    };

    const headers = {
      accept: "application/json, text/javascript, */*, q=0.01",
      "accept-encoding": "gzip, deflate",
      "accept-language": "en-US,en;q=0.9",
      cookie: cookies,
      dnt: "1",
      referer: "https://www.pinterest.com/",
      "sec-ch-ua":
        '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133"',
      "sec-ch-ua-full-version-list":
        '"Not(A:Brand";v="99.0.0.0", "Microsoft Edge";v="133.0.3065.92", "Chromium";v="133.0.6943.142"',
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-model": '""',
      "sec-ch-ua-platform": '"Windows"',
      "sec-ch-ua-platform-version": '"10.0.0"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0",
      "x-app-version": "c056fb7",
      "x-pinterest-appstate": "active",
      "x-pinterest-pws-handler": "www/[username]/[slug].js",
      "x-pinterest-source-url": "/hargr003/cat-pictures/",
      "x-requested-with": "XMLHttpRequest",
    };

    const { data } = await axios
      .get(url, {
        httpsAgent: agent,
        headers: headers,
        params: params,
      })
      .catch((e) => e.response);
    try {
      return data.resource_response.data.results
        .filter((a) => a.title !== "")
        .map((a) => ({
          title: a.title,
          id: a.id,
          create_at: moment(new Date(a.created_at) * 1).format(
            "DD/MM/YYYY HH:mm:ss",
          ),
          author: a.pinner.username,
          followers: a.pinner.follower_count.toLocaleString(),
          source: "https://www.pinterest.com/pin/" + a.id,
          image: a.images["orig"].url,
        }));
    } catch (e) {
      return [];
    }
  };
  download = async function (url) {
    let response = await axios
      .get(url, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
        },
      })
      .catch((e) => e.response);
    let $ = cheerio.load(response.data);
    let tag = $('script[data-test-id="video-snippet"]');
    return tag.text();
  };
}

export default new Pinterest();
