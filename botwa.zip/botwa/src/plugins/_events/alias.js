import cmd from "../../commands/map.js";
import { generateWAMessage, areJidsSameUser, proto } from "baileys";
import { format } from "util";
import { procMsg } from "../../utils/msg.js";

function isBase64(str) {
  const base64Regex = /^[a-zA-Z0-9+/=]+$/;
  return base64Regex.test(str) && str.length % 4 === 0;
}

cmd.add({
  middleware: async ({ m, sock, src, store }) => {
    console.log("[ALIAS MODE] Menunggu Reply kamuh");
    if (m.quoted && m.quoted.text.includes("metadata:")) {
      console.log("[ALIAS MODE] Yatta ada reply dari kamuh");
      const input = m.quoted.text.split("metadata:").pop().trim();
      const decode = isBase64(input) ? atob(input) : false;
      if (!decode) return;
      const commands = decode.split("|");
      const userCommand = m.text.toLowerCase().trim();
      const selected = commands.find(
        (a) => a.split("-")[0].toLowerCase().trim() === userCommand,
      );
      if (!selected) {
        return;
      }
      const parts = selected.split(/-(.*)/s);
      const value = parts[1];
      if (value) {
        let messages = await generateWAMessage(
          m.chat,
          {
            text: value,
            mentions: m.mentioned,
          },
          {
            quoted: m.quoted,
          },
        );
        messages.key.fromMe = areJidsSameUser(m.sender, sock.user.id);
        messages.key.id = m.key.id;
        messages.pushName = m.pushName;
        if (m.isGroup) messages.participant = m.sender;
        return sock.ev.emit("messages.upsert", {
          messages: [
            {
              key: m.key,
              pushName: m.pushName,
              message: messages.message,
            },
          ],
          type: "notify",
        });
      }
    }
  },
});
