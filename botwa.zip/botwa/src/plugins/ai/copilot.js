import cmd from "../../commands/map.js";
cmd.add({
  name: "copilot",
  alias: ["cpilot"],
  category: ["ai"],
  desc: "Answer questions and find information with Copilot",
  run: async ({ m, text, sock, src }) => {
    if (!text) return m.reply("Mau nanya apa?");
    await m.reply("Tunggu bentar");
    const data = await src.copilot
      .chat(text)
      .catch((e) => ({ text: e.message || "Gagal ambil respon dari AI" }));
    m.reply(data.text);
  },
});
