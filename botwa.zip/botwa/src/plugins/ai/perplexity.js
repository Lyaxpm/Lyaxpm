import cmd from "../../commands/map.js";
cmd.add({
  name: "perplexityai",
  alias: ["perplexity", "perple"],
  category: ["ai"],
  desc: "Answer questions and search in real-time with Perplexity AI",
  run: async ({ m, text, src }) => {
    if (!text) return m.reply("Apa yang ingin kamu tanyakan?");
    await m.reply("Tunggu Sebentar...");
    const data = await src.perplexity({
      query: text,
      source: { web: true, social: true },
    });
    if (!data?.answer) return m.reply("Gagal dapetin respon AI");
    if (!Array.isArray(data.search_results)) {
      return m.reply("Search result kosong");
    }
    let caption = data.answer;
    caption += `\n\n*## Search Result*\n`;
    caption += data.search_results
      .map((a, i) => `*\`${i + 1}\`.* ${a.name}\n> ${a.url}`)
      .join("\n\n");
    m.reply(caption);
  },
});
function format(a, m) {
  return m.reply(`*${a.name}*
> ${a.url}
${a.snippet || ""}`);
}
