import cmd from "../../commands/map.js";
import { GoogleGenAI } from "@google/genai";

const TOOLS = {
  "--search": {
    googleSearch: {},
  },
};

cmd.add({
  name: "gemini",
  alias: ["ai", "gm"],
  category: ["ai"],
  desc: "Start Chatting with Gemini!",
  run: async ({ m, sock, text }) => {
    const question = m.quoted ? m.quoted.text : text
    if (!question)
      return m.reply(
        `Masukan Pertanyaannya

Gunakan tools berikut:
${Object.keys(TOOLS).map((a, i) => `${i + 1}. \`${a}\``).join("\n")}`
      );

    await m.reply("Tunggu sebentar...");

    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_APIKEY,
    });

    const who = m.quoted ? m.quoted : m;

    if (who.isMedia) {
      const { mimetype } = who.message[who.type];
      const buffer = await who.download();

      const contents = [
        { 
         text: m.quoted ? `${m.quoted.text}\n${'-'.repeat(40)}\n${text}` : question 
          },
        {
          inlineData: {
            mimeType: mimetype,
            data: buffer.toString("base64"),
          },
        },
      ];

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents,
        config: {
          thinkingConfig: { thinkingBudget: 0 },
        },
      });

      const result =
        response.candidates?.[0]?.content?.parts?.[0]?.text;

      if (!result)
        return m.reply("Gemini ngambek, coba lagi nanti");

      return sock.sendMessage(m.chat, { text: result }, { quoted: m });
    }

    const selectTool = Object.keys(TOOLS).find(t =>
      question.toLowerCase().startsWith(t)
    );

    const cleanText = selectTool
      ? question.slice(selectTool.length).trim()
      : question;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ text: m.quoted ? `${m.quoted.text}\n${'-'.repeat(40)}\n${cleanText}` : cleanText }],
      config: {
        thinkingConfig: { thinkingBudget: 0 },
        ...(selectTool && { tools: [TOOLS[selectTool]] }),
      },
    });

    const result =
      response.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!result)
      return m.reply("Gemini ga jawab, mungkin lagi males");

    await sock.sendMessage(m.chat, { text: result }, { quoted: m });
  },
});