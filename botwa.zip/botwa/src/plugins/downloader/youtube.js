import cmd from "../../commands/map.js";
import axios from "axios";
import yts from "yt-search";
import { generateProfilePicture } from "baileys";
import { format } from "util";

function extractYouTubeUrl(text) {
  const match = text.match(
    /(https?:\/\/(www\.)?(youtube\.com\/watch\?v=[\w-]+|youtu\.be\/[\w-]+))/,
  );
  return match ? match[1] : null;
}
cmd.add({
  name: "youtube",
  alias: ["yt", "ytdl"],
  category: ["downloader"],
  desc: "Search & Download YouTube Audio / Video",
  async run({ m, sock, args }) {
    const text = args.join(" ").trim();
    if (!text) return m.reply("Masukin keyword atau link YouTube");
    await m.reply("Tunggu bentar...");
    try {
      const ytUrl = extractYouTubeUrl(text);
      if (!ytUrl) {
        const res = await yts.search(text);
        const videos = res.videos.slice(0, 10);
        if (!videos.length) return m.reply("Ga ketemu, keyword lu aneh banget");
        const alias = videos
          .map((v, i) => `${i + 1}-.yt ${v.url} __audio`)
          .join("|");
        const caption = `*– YOUTUBE SEARCH –*
        
Pilih dari angka *\`1\`* → *\`${videos.length}\`* untuk saya download 

*Keyword:* ${text}

${videos
  .map(
    (v, i) => `*\`${i + 1}\`* ${v.title}\n> ${v.timestamp} | ${v.author.name}`,
  )
  .join("\n\n")}
metadata: ${btoa(alias)}`;
        return m.reply(caption);
      }
      const isAudio = text.includes("__audio");
      const isVideo = text.includes("__video");
      const endpoint = isAudio ? "ytmp3" : "ytmp4";
      const apiURL = `https://api.iyayn.web.id/api/downloader/${endpoint}?url=${encodeURIComponent(ytUrl)}${isAudio ? "" : "&quality=360"}`;
      const api = await axios.get(apiURL);
      if (api.status !== 200)
        return m.reply("Downloader error, coba lagi besok");
      const data = api.data;
      if (data.error) return m.reply("Downloader error, coba lagi besok");
      const media = await axios.get(data.downloadUrl, {
        responseType: "arraybuffer",
      });
      const switchAlias = btoa(
        `1-.yt ${ytUrl} ${isAudio ? "__video" : "__audio"}|2-.menu downloader`,
      );
      const caption = `*– YOUTUBE DOWNLOADER –*
      
${Object.entries(data)
  .filter(([_, v]) => typeof v !== "object")
  .map(([k, v]) => `- *${k.charAt(0).toUpperCase() + k.slice(1)}:* ${v}`)
  .join("\n")}
  
Mau ganti ke versi ${isAudio ? "video" : "audio"}?
1️⃣ Download ${isAudio ? "video" : "audio"}
2️⃣ Back to Menu

metadata: ${switchAlias}`;
      const quoted = await sock.sendMessage(
        m.chat,
        {
          text: caption,
          contextInfo: {
            externalAdReply: {
              title: data.title,
              body: ytUrl,
              mediaType: 1,
              thumbnailUrl: data.thumbnail,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: m },
      );
      if (isVideo) {
        const videoQ = await sock.sendMessage(
          m.chat,
          {
            video: Buffer.from(media.data),
          },
          { quoted },
        );
        await sock.sendMessage(
          m.chat,
          {
            document: Buffer.from(media.data),
            mimetype: "video/mp4",
            fileName: `${data.title}.mp4`,
            caption: "Versi dokumen (biar aman)",
          },
          { quoted: videoQ },
        );
      } else {
        const audioQ = await sock.sendMessage(
          m.chat,
          {
            audio: Buffer.from(media.data),
            mimetype: "audio/mpeg",
          },
          { quoted },
        );
        await sock.sendMessage(
          m.chat,
          {
            document: Buffer.from(media.data),
            mimetype: "audio/mpeg",
            fileName: `${data.title}.mp3`,
            jpegThumbnail: await axios
              .get(data.thumbnail, { responseType: "arraybuffer" })
              .then((r) =>
                generateProfilePicture(Buffer.from(r.data), {
                  width: 200,
                  height: 200,
                }),
              )
              .catch(() => null),
            caption: "Versi dokumen (buat yang ribet)",
          },
          { quoted: audioQ },
        );
      }
    } catch (err) {
      console.error(err);
      m.reply(
        "Service Error, Hubungi owner bot:\n> " +
          (format(err) || "Unknown Error"),
      );
    }
  },
});
