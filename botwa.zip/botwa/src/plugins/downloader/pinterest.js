import cmd from "../../commands/map.js";

cmd.add({
  name: "pinterest",
  alias: ["pin", "pterest"],
  category: ["downloader"],
  desc: "Search and download content from Pinterest!",
  example: ".pin [keyword]/[url pinterest]",
  usage: ".pin Hatsune miku/https://pin.it/xxx",
  run: async ({ m, sock, text, src }) => {
    if (!text) return m.reply("Masukan Keyword atau url dari pinterest!");
    await m.reply("Tunggu bentar...");
    const data = await src.pinterest.search(text).catch((e) => []);
    if (!data) return m.reply("Keyword tidak ditemukan, coba pake yang lain");
    const random = data[Math.floor(Math.random() * data.length)];
    let caption = "*– PINTEREST SEARCH –*\n\n";
    caption += Object.entries(random)
      .map(
        ([a, b]) =>
          `- *${(a.charAt(0).toUpperCase() + a.slice(1)).split("_").join(" ")} :* ${b}`,
      )
      .join("\n");

    await sock.sendMessage(
      m.chat,
      {
        image: {
          url: random.image,
        },
        caption,
      },
      { quoted: m },
    );
  },
});
