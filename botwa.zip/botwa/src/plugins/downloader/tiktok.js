import cmd from "../../commands/map.js";

cmd.add({
  name: "tiktok",
  alias: ["tt", "ttdl"],
  category: ["downloader"],
  desc: "Search and download your favorite TikTok content",
  usage: ".tiktok (url/keyword)",
  example: ".tiktok",
  run: async ({ m, sock, src, text }) => {
    sock.tiktok = sock.tiktok || {};
    if (!text) return m.reply("Masukan Keyword atau link dari TikTok!");
    await m.reply("Tunggu bentar...");
    let mode = "none";
    try {
      new URL(text);
      mode = "download";
    } catch (e) {
      mode = "search";
    }
    if (mode === "search") {
      if (sock.tiktok[m.sender]) {
        const parts = text.split("&");
        const keyword = parts[0];
        const id = parts[1];
        if (!id) {
          delete sock.tiktok[m.sender];
          return m.reply(
            "ID TikTok tidak ditemukan. Silakan pilih nomor dari hasil pencarian sebelumnya.",
          );
        }
        const data = sock.tiktok[m.sender].find(
          (a) => a.metadata.video_id === id.trim(),
        );
        if (!data) {
          delete sock.tiktok[m.sender];
          return m.reply(
            "Data TikTok tidak ditemukan. Silakan lakukan pencarian ulang.",
          );
        }
        delete sock.tiktok[m.sender];
        let caption = "*– TIKTOK DOWNLOADER –*\n\n";
        caption += Object.entries(data.metadata)
          .map(
            ([a, b]) =>
              `- *${(a.charAt(0).toUpperCase() + a.slice(1)).split("_").join(" ")} :* ${b}`,
          )
          .join("\n");
        caption += "\n\n_Media sedang di unduh mohon tunggu sebentar..._";
        const quoted = await sock.sendMessage(
          m.chat,
          {
            text: caption,
            contextInfo: {
              externalAdReply: {
                title: data.metadata.title,
                mediaType: 1,
                thumbnailUrl: data.metadata.thumbnail,
                renderLargerThumbnail: true,
              },
            },
          },
          { quoted: m },
        );
        const content = {
          video: { url: data.media.no_watermark },
        };
        await sock.sendMessage(m.chat, content, { quoted });
      } else {
        const search = await src.tiktok.search(text).catch((e) => []);
        if (search.length < 1) return m.reply("Keyword tidak ditemukan");
        const alias = search
          .map((a, i) => `${i + 1}-.tiktok ${text} & ${a.metadata.video_id}`)
          .join("|");
        let caption = "*– TIKTOK SEARCH –*\n";
        caption += `Pilih angka *\`1\`* sampai *\`${search.length}\`* untuk mengunduh konten Tiktok\n\n`;
        caption += `*- Keyword:* ${text}\n\n`;
        caption += search
          .map(
            (a, i) =>
              `*\`${i + 1}\`* ${a.metadata.title.slice(0, 100) + "..."}\n> ${a.metadata.video_id}`,
          )
          .join("\n\n");
        caption += `\n\nmetadata: ${Buffer.from(alias).toString("base64")}`;
        await sock.sendMessage(
          m.chat,
          {
            text: caption,
          },
          {
            quoted: m,
          },
        );
        sock.tiktok[m.sender] = search;
      }
    } else if (mode === "download") {
      const result = await src.tiktok.download(text).catch((e) => {
        console.error("TikTok download error:", e);
        return null;
      });
      if (!result) {
        return m.reply("Gagal mengunduh video dari URL TikTok yang diberikan.");
      }
      if (result.images) {
        for (const url of result.images) {
          await sock.sendMessage(
            m.chat,
            {
              image: { url },
            },
            { quoted: m },
          );
        }
      }
      await sock.sendMessage(
        m.chat,
        {
          video: { url: result.play },
          caption: result.title,
        },
        { quoted: m },
      );
    }
  },
});
