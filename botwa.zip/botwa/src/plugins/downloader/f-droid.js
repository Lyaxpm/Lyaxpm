import cmd from "../../commands/map.js";

cmd.add({
  name: "f-droid",
  alias: ["apk", "droid"],
  category: ["downloader"],
  desc: "Search and download apps from F-Droid",
  run: async ({ m, sock, text, src }) => {
    if (!text) return m.reply("Masukkan keyword/URL dari F-droid!");
    await m.reply("Tunggu bentar...");
    if (text.includes("--download")) {
      const [url, fileName, mimetype] = text
        .replace("--download", "")
        .trim()
        .split("&");
      return sock.sendMessage(
        m.chat,
        {
          document: { url },
          fileName,
          mimetype,
        },
        { quoted: m },
      );
    } else if (isURL(text)) {
      const data = await src.fdroid.detail(text).catch((e) => ({}));
      if (!data) return m.reply("Gagal Download, coba lagi besok");
      const alias = data.versions
        .map(
          (a, i) =>
            `${i + 1}-.apk --download ${a.download}&${data.name.split("-")[0].toUpperCase().trim()}.apk&application/vnd.android.package-archive`,
        )
        .join("|");
      let caption = "*– FDROID - DOWNLOADER –*\n\n";
      caption += `- *Name* : ${data?.name}\n`;
      caption += `- *Latest Version* : ${data?.versions[0].version}\n`;
      caption += `\nPilih angka *\`1\`* → *\`${data?.versions.length}\`* untuk memilih versi\n\n`;
      caption += data.versions
        .map(
          (a, i) =>
            `*\`${i + 1}\`*. ${a.version} ${i < 1 ? "*[Latest]*" : ""}\n> *${a.added}* | *${a.size}*`,
        )
        .join("\n\n");
      caption += `\n\nmetadata: ${btoa(alias)}`;
      await sock.sendMessage(
        m.chat,
        {
          text: caption,
          contextInfo: {
            externalAdReply: {
              title: data.name,
              body: data.summary,
              mediaType: 1,
              thumbnailUrl: data.icon,
            },
          },
        },
        { quoted: m },
      );
    } else {
      const search = await src.fdroid.search(text).catch((e) => false);
      const alias = search.results
        .map((a, i) => `${i + 1}-.apk ${a.link}`)
        .join("|");
      if (!search) return m.reply("Pencarian tidak ditemukan!");
      let caption = "*— FDROID SEARCH —*\n";
      caption += `Pilih angka *\`1\`* → *\`${search.results.length}\`* untuk memilih aplikasi yang ingin kamu unduh\n\n`;
      caption += `- *Keyword* : ${text}\n\n`;
      caption += search.results
        .map((a, i) => `*\`${i + 1}\`*. ${a.name}\n> ${a.summary}`)
        .join("\n");
      caption += `\n\nmetadata: ${btoa(alias)}`;

      await sock.sendMessage(
        m.chat,
        {
          text: caption,
          contextInfo: {
            externalAdReply: {
              title: search.results[0].name,
              body: search.results[0].summary,
              mediaType: 1,
              thumbnailUrl:
                "https://f-droid.org/assets/fdroid-logo_bfHl7nsLHOUQxzdU8-rGIhn4bAgl6z7k2mA3fWoCyT4=.png",
            },
          },
        },
        { quoted: m },
      );
    }
  },
});

function isURL(str) {
  try {
    new URL(str);
    return true;
  } catch (e) {
    return false;
  }
}
