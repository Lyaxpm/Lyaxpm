import cmd from "../../commands/map.js";
import { readdir, unlink } from "fs/promises";
import { resolve } from "path";
const SESSIONS_DIR = resolve("./baileys_auth_info");
cmd.add({
  name: "clearsessions",
  alias: ["csessi", "cs"],
  category: ["owner"],
  desc: "delete unused sessions trash",
  example: ".csessi (Auto Clear Sessions)",
  usage: "Just type .csessi",
  isOwner: true,
  run: async ({ m }) => {
    const files = await readdir(SESSIONS_DIR).catch((e) => []);
    const transh = files.filter((a) => !a.includes("creds.json"));
    await m.reply("Membersihkan sampah sessions");
    if (transh.length < 100)
      return m.reply(`Masih dikit ini mah \`${transh.length}\` ga perlu dihapus
${transh.map((a, i) => `*${i + 1}.* ${a}`).join("\n")}`);
    let total = transh.length;
    for (const file of transh) {
      try {
        await unlink(SESSIONS_DIR + "/" + file);
        total -= 1;
      } catch (e) {}
    }
    m.reply(`Berhasil Membersihkan sampah sessions ✓
> Sebelum *\`${transh.length}\`* → Sesudah *\`${total}\`*`);
  },
});
