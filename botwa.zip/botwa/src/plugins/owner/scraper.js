import cmd from "../../commands/map.js";
import { join, resolve, dirname } from "path";
import { readFile, writeFile, readdir, unlink } from "fs/promises";
import { existsSync } from "fs";
import { spawn } from "child_process";
const scraper_DIR = resolve("./src/scrapers/src");
cmd.add({
  name: "scraper",
  alias: ["skrep", "src"],
  category: ["owner"],
  desc: "Manage scrape files (CRUD operations with auto-compilation) - owner only",
  usage:
    ".scraper (listing) | .scraper --save [path] [code] | .scraper --delete [path]",
  example:
    ".scraper\n.scraper --save tools/new-tool.ts `console.log('New tool');`\n.scraper --delete tools/new-tool.ts",
  isOwner: true,
  async run({ m, sock, text }) {
    if (!text) {
      try {
        const getAllTsFiles = async (dir, fileList = []) => {
          const files = await readdir(dir);
          for (const file of files) {
            if (!file) continue;
            const filePath = join(dir, file);
            const { stat } = await import("fs/promises");
            const fileStat = await stat(filePath);
            if (fileStat.isDirectory()) {
              await getAllTsFiles(filePath, fileList);
            } else if (file.endsWith(".js")) {
              fileList.push(filePath.replace(scraper_DIR + "/", ""));
            }
          }
          return fileList;
        };
        const tsFiles = await getAllTsFiles(scraper_DIR);
        if (tsFiles.length === 0) {
          return m.reply("No scrape files found in the scraper directory.");
        }
        const validSubdirs = (
          await readdir(scraper_DIR, { withFileTypes: true })
        )
          .filter((dirent) => dirent.isDirectory())
          .map((dirent) => dirent.name);
        const fileList = tsFiles
          .map((file, i) => `${i + 1}. ${file}`)
          .join("\n");
        m.reply(
          `scrape files in directory (${tsFiles.length}):\n\n${fileList}\n\nValid directories: ${validSubdirs.join(", ")}\n\nUse .scraper --get [path] to get scraper content\nUse .scraper --save [path] [code] to create/save scraper\nUse .scraper --delete [path] to delete scraper`,
        );
      } catch (error) {
        console.error("Error listing scraper:", error);
        m.reply("Failed to list scrape files.");
      }
      return;
    }
    if (text.includes("--save".toLowerCase())) {
      const fileName = text.replace("--save", "")?.trim();
      if (!fileName) {
        return m.reply("File name is required for --save command");
      }
      let typedFileName = fileName;
      const code = m?.quoted ? m?.quoted?.text?.trim() : "";
      if (!m.quoted && !code) return m.reply("Reply code to save");
      if (typedFileName.includes("..")) {
        return m.reply("Invalid path. '..' is not allowed.");
      }
      if (typedFileName.includes("/")) {
        const parts = typedFileName.split("/");
        const subdirectory = parts[0];
        const validSubdirs = (
          await readdir(scraper_DIR, { withFileTypes: true })
        )
          .filter((dirent) => dirent.isDirectory())
          .map((dirent) => dirent.name);
        if (!validSubdirs.includes(subdirectory)) {
          return m.reply(
            `Invalid subdirectory. Valid subdirectories are: ${validSubdirs.join(", ")}`,
          );
        }
      }
      if (!typedFileName) {
        return m.reply(
          "File name is required for --save command (internal check)",
        );
      }
      const filePath = join(scraper_DIR, typedFileName);
      const dirPath = dirname(filePath);
      try {
        await import("fs").then(({ promises }) =>
          promises.mkdir(dirPath, { recursive: true }),
        );
      } catch (error) {}
      try {
        if (existsSync(filePath)) {
          await unlink(filePath);
        }
        await writeFile(filePath, code || "");
        m.reply(
          `scrape ${fileName} saved successfully in the scraper directory.`,
        );
      } catch (error) {
        console.error("Error saving scrape:", error);
        m.reply("Failed to save scrape file.");
      }
      return;
    }
    if (text.includes("--delete".toLowerCase())) {
      const fileName = text.replace("--delete", "")?.trim();
      if (!fileName) {
        return m.reply("File name is required for --delete command");
      }
      let typedFileName = fileName;
      if (typedFileName.includes("..")) {
        return m.reply("Invalid path. '..' is not allowed.");
      }
      if (typedFileName.includes("/")) {
        const parts = typedFileName.split("/");
        const subdirectory = parts[0];
        const validSubdirs = (
          await readdir(scraper_DIR, { withFileTypes: true })
        )
          .filter((dirent) => dirent.isDirectory())
          .map((dirent) => dirent.name);
        if (!validSubdirs.includes(subdirectory)) {
          return m.reply(
            `Invalid subdirectory. Valid subdirectories are: ${validSubdirs.join(", ")}`,
          );
        }
      }
      if (!typedFileName) {
        return m.reply(
          "File name is required for --delete command (internal check)",
        );
      }
      const filePath = join(scraper_DIR, typedFileName);
      if (!existsSync(filePath)) {
        return m.reply(`File ${typedFileName} does not exist!`);
      }
      try {
        const content = await readFile(filePath, "utf-8");
        const preview =
          content.length > 100 ? content.substring(0, 100) + "..." : content;
        await unlink(filePath);
        m.reply(
          `scrape ${fileName} deleted successfully!\n\nDeleted content preview:\n\`\`\`js\n${preview}\n\`\`\``,
        );
        try {
          m.reply("🔄 Commands reloaded successfully after deletion!");
        } catch (reloadError) {
          console.error("Error reloading commands:", reloadError);
          m.reply(
            "⚠️ scrape deleted but failed to reload commands. Please restart the bot.",
          );
        }
      } catch (error) {
        console.error("Error deleting scrape:", error);
        m.reply("Failed to delete scrape file.");
      }
      return;
    }
    if (text.includes("--get".toLowerCase())) {
      const fileName = text.replace("--get", "")?.trim();
      if (!fileName) return m.reply("Input file .ts/.js to get content");
      const filePath = join(scraper_DIR, fileName);
      if (!existsSync(filePath)) return m.reply(`File ${fileName} not found`);
      const buffer = await readFile(filePath);
      sock.sendMessage(
        m.chat,
        {
          document: buffer,
          fileName: fileName.split("/").pop(),
          mimetype: `application/${fileName.endsWith(".ts") ? "typescript" : "javascript"}`,
          caption: `\`\`\`STDOUT:\n ${buffer.toString("utf-8")}\`\`\``,
        },
        { quoted: m },
      );
      return;
    }
    m.reply(
      "Usage:\n• .scraper --get [path] - to get scraper content\n• .scraper - List all scraper\n• .scraper --save [path] [code] - Save/create a scrape\n• .scraper --delete [path] - Delete a scrape",
    );
  },
});
