import cmd from "../../commands/map.js";
import { spawn } from "child_process";
import util from "util";

cmd.add({
  name: "exec",
  alias: ["shell", "$"],
  category: ["owner"],
  desc: "Execute shell command (owner only)",
  isOwner: true,
  async run({ m, args }) {
    const command = (args || []).join(" ").trim();
    if (!command) return m.reply("Masukkan command untuk dijalankan.");
    const commandParts = command.split(" ");
    const cmdName = commandParts[0];
    const cmdArgs = commandParts.slice(1);
    if (!cmdName) return m.reply("Invalid command.");
    const execProcess = spawn(cmdName, cmdArgs, {
      cwd: process.cwd(),
      shell: false,
      stdio: ["pipe", "pipe", "pipe"],
    });
    let stdout = "";
    let stderr = "";
    execProcess.stdout.on("data", (data) => {
      stdout += data.toString();
    });
    execProcess.stderr.on("data", (data) => {
      stderr += data.toString();
    });
    execProcess.on("close", (code) => {
      let output = "";
      if (code === 0 && stdout.trim()) {
        output = stdout.trim();
      } else if (stderr.trim()) {
        output = stderr.trim();
      } else {
        output = "No output.";
      }
      m.reply("```" + output + "```");
    });
    execProcess.on("error", (err) => {
      m.reply("Error menjalankan command:\n```" + err.message + "```");
    });
  },
});

cmd.add({
  name: "eval",
  alias: ["ev", "="],
  category: ["owner"],
  desc: "Execute JavaScript/TypeScript code (owner only)",
  usage: ".eval [code]",
  example: ".eval 2 + 2",
  isOwner: true,
  async run({ m, sock, store, args, src, db }) {
    const fullText = m.body || m.text || "";
    const commandEndIndex = fullText.indexOf(" ");
    const code =
      commandEndIndex === -1 ? "" : fullText.substring(commandEndIndex + 1);
    if (!code.trim()) return m.reply("Mana code nya woi");
    const AsyncFunction = Object.getPrototypeOf(
      async function () {},
    ).constructor;
    try {
      const func = new AsyncFunction(
        "m",
        "sock",
        "store",
        "args",
        "cmd",
        "global",
        "src",
        "db",
        code,
      );
      const result = await func(m, sock, store, args, cmd, global, src, db);
      await m.reply(util.format(result));
    } catch (e) {
      await m.reply(util.format(e));
    }
  },
});
