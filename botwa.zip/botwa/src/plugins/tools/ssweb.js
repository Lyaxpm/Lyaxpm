import cmd from "../../commands/map.js";
cmd.add({
  name: "screenshotweb",
  alias: ["ssweb", "ss"],
  category: ["tools"],
  desc: "Take Screenshot from website",
  run: async ({ m, text, src, sock }) => {
    if (!text) return m.reply("Mana link website nya");
    await m.reply("Tunggu bentar...");
    const url = await src.ssweb(text);
    await sock.sendMessage(
      m.chat,
      { image: { url }, caption: `Scrennshot dari: ${text}` },
      { quoted: m },
    );
  },
});
