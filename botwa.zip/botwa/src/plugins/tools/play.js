import cmd from "../../commands/map.js";
import axios from "axios";
import yts from "yt-search";
import { spawn } from "child_process";
import { format } from "util";
import * as cheerio from "cheerio";
import { generateProfilePicture } from "baileys";

cmd.add({
  name: "play",
  alias: ["musik"],
  category: ["downloader"],
  desc: "Search & Download Musicon SoundCloud audio ",
  usage: "Reply to an audio message with .whatmusic",
  example: "Reply to an audio file with .whatmusic",
  async run({ m, sock, args }) {
    const text = args.join(" ");
    if (!text) return m.reply("Masukan Pencarian nya");
    await m.reply("Tunggu Bentar....");
    try {
      const search = await yts
        .search(text)
        .then((a) => a.videos)
        .catch((e) => []);
      if (search.length < 1) return m.reply("Musik tidak ditemukan!");
      const { data, status } = await axios
        .get(
          `https://api.iyayn.web.id/api/downloader/ytmp3?url=${search[0].url}`,
        )
        .catch((e) => e.response);
      if (status !== 200) return m.reply("Gagal download musik");
      const dl = await axios
        .get(data.downloadUrl, { responseType: "arraybuffer" })
        .catch((e) => e.response);
      let caption = "*– MUSIC DOWNLOADER –*\n\n- *Source:* YouTube\n";
      caption += Object.entries(search[0])
        .filter(([key, value]) => typeof value !== "object")
        .map(([a, b]) => `- *${a.charAt(0).toUpperCase() + a.slice(1)}:* ${b}`)
        .join("\n");
      caption += "\n\n_Sedang di unduh bentar yah_\n";
      await m.reply(caption);
      const q = await sock.sendMessage(
        m.chat,
        {
          audio: { url: data.downloadUrl },
          mimetype: "audio/mpeg",
          contextInfo: {
            externalAdReply: {
              title: search[0].title,
              body: "Nih musiknya ganteng",
              mediaType: 1,
              thumbnailUrl: search[0].image,
              sourceUrl: search[0].url,
              renderLargerThumbnailUrl: true,
            },
          },
        },
        { quoted: m },
      );
      await sock.sendMessage(
        m.chat,
        {
          document: { url: data.downloadUrl },
          mimetype: "audio/mpeg",
          fileName: search[0].title + ".mp3",
          jpegThumbnail: await axios
            .get(search[0].image, {
              respone: "arraybuffer",
            })
            .then(
              async (a) =>
                await generateProfilePicture(Buffer.from(a.data), {
                  width: 100,
                  height: 100,
                }),
            )
            .catch((e) => null),
          caption: "Versi Dokumen nya",
        },
        { quoted: q },
      );
    } catch (error) {
      m.reply("Semua Service error, Hubungi owner bot!");
    }
  },
});
