import cmd from "../../commands/map.js";
import { fetch } from "undici";
import * as cheerio from "cheerio";
import pkg from "js-beautify";
import { format } from "util";
import mime from "mime-types";

const { html: beautifyHTML } = pkg;

cmd.add({
  name: "get",
  alias: ["fetch", "curl"],
  category: ["tools"],
  desc: "Get any content from URL",
  usage: ".get [url]",
  run: async ({ m, sock, text }) => {
    if (!text) return m.reply("Masukan URL nya");

    try {
      new URL(text);
    } catch {
      return m.reply("URL gak valid, jangan goblok");
    }

    await m.reply("Tunggu bentar...");

    const res = await fetch(text);
    const mimetype =
      res.headers.get("content-type")?.split(";")[0] || "text/plain";
    const type = mimetype.split("/")[0];

    const buffer = Buffer.from(await res.arrayBuffer());
    const content = buffer.toString();

    let thumbnail = "";
    if (mimetype.includes("html")) {
      const $ = cheerio.load(content);
      thumbnail =
        $('meta[property="og:image"]').attr("content") ||
        $('meta[name="og:image"]').attr("content") ||
        "";

      if (thumbnail && !/^https?:\/\//.test(thumbnail)) {
        thumbnail = new URL(thumbnail, text).href;
      }
    }

    let caption = `*– FETCH URL –*\n\n`;
    caption += `- *URL:* ${text}\n`;
    caption += `- *Status:* ${res.status}\n`;
    caption += `- *MIME:* ${mimetype}\n`;
    caption += `- *Thumbnail:* ${thumbnail || "-"}\n\n`;
    caption += `*HEADER RESPONSE*\n\`\`\``;

    res.headers.forEach((v, k) => (caption += `\n${k}: ${v}`));
    caption += `\n\`\`\``;

    const quoted = await sock.sendMessage(
      m.chat,
      thumbnail ? { image: { url: thumbnail }, caption } : { text: caption },
      { quoted: m },
    );

    if (["image", "video", "audio"].includes(type)) {
      return sock.sendMessage(m.chat, { [type]: buffer, mimetype }, { quoted });
    }

    if (mimetype.includes("html")) {
      return sock.sendMessage(
        m.chat,
        {
          document: Buffer.from(beautifyHTML(content)),
          mimetype,
          fileName: `${Date.now()}.html`,
        },
        { quoted },
      );
    }

    if (mimetype.includes("json")) {
      return sock.sendMessage(
        m.chat,
        { text: format(JSON.parse(content)) },
        { quoted },
      );
    }

    if (mimetype.includes("text")) {
      await sock.sendMessage(
        m.chat,
        {
          text: content,
        },
        {
          quoted,
        },
      );
    }

    return sock.sendMessage(
      m.chat,
      {
        document: buffer,
        mimetype,
        fileName: `${Date.now()}.${mime.extension(mimetype) || "txt"}`,
      },
      { quoted },
    );
  },
});
