import cmd from "../../commands/map.js";
cmd.add({
  name: "q",
  alias: ["quoted", "forward"],
  category: ["tools"],
  desc: "Forward someone's message.",
  usage: ".q [quoted message]",
  example: ".q",
  async run({ m, args, sock }) {
    if (!m.quoted) return m.reply("Balas pesan nya!");
    if (!m.quoted?.quoted) return m.reply("Pesan nya ga mengandung balasan!");
    await sock.sendMessage(
      m.chat,
      { forward: m.quoted?.quoted },
      { quoted: m },
    );
  },
});
