import cmd from "../../commands/map.js";

import { Sticker, createSticker, StickerTypes } from "wa-sticker-formatter";

cmd.add({
  name: "sticker",
  alias: ["s"],
  category: ["tools"],
  desc: "Convert images and videos into stickers",
  run: async ({ m, sock }) => {
    const who = m.quoted ? m.quoted : m;
    if (!who || !who.isMedia)
      return m.reply(
        "Balas/Kirim Pesan yang mengandung media untuk dirubah menjadi sticker",
      );
    if (!/image|video/.test(who.type)) return m.reply("Media type gak valid");
    await m.reply("Tunggu bentar...");
    const buffer = await who.download();
    const data = new Sticker(buffer, {
      pack: "Create by",
      author: m.pushName,
      type: StickerTypes.FULL,
      categories: ["🤩", "🎉"],
      id: m.id,
      quality: 50,
    });
    await sock.sendMessage(m.chat, await data.toMessage(), { quoted: m });
  },
});
