import cmd from "../commands/map.js";
import os from "os";
function formatBytes(bytes) {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}
function formatUptime(seconds) {
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor((seconds % (3600 * 24)) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  let uptimeString = "";
  if (d > 0) uptimeString += `${d} hari, `;
  if (h > 0) uptimeString += `${h} jam, `;
  if (m > 0) uptimeString += `${m} menit, `;
  uptimeString += `${s} detik`;
  return uptimeString.trim().replace(/,$/, "");
}
cmd.add({
  name: "menu",
  alias: ["help", "list"],
  category: ["info"],
  desc: "Show all commands or filter by category with detailed information.",
  usage: ".menu [category]",
  example: ".menu info",
  async run({ m, args, sock }) {
    const commands = [...cmd.values()];
    const osType = os.type();
    const osPlatform = os.platform();
    const osArch = os.arch();
    const osHostname = os.hostname();
    const osUptime = formatUptime(os.uptime());
    const osTotalMem = formatBytes(os.totalmem());
    const osFreeMem = formatBytes(os.freemem());
    const totalCommands = commands.length;
    if (args.length > 0) {
      const targetCategory = args[0].toLowerCase();
      const filteredCommands = commands.filter(
        (cmd) =>
          cmd.name &&
          cmd.category &&
          Array.isArray(cmd.category) &&
          cmd.category.map((c) => c.toLowerCase()).includes(targetCategory),
      );
      if (filteredCommands.length === 0) {
        return m.reply(`No commands found in category: ${targetCategory}`);
      }
      let response = `╭─╽「 *\`${targetCategory.toUpperCase()} MENU\`* 」╽─╮\n│\n`;
      filteredCommands.forEach((cmd, index) => {
        const isLastCommand = index === filteredCommands.length - 1;
        const commandPrefix = isLastCommand ? "╰─" : "├─";
        response += `${commandPrefix}╽ *${cmd.name.toUpperCase()}*\n`;
        const details = [];
        if (cmd.alias && cmd.alias.length > 0) {
          details.push({ key: "aliases", value: cmd.alias.join(", ") });
        }
        if (cmd.desc) {
          details.push({ key: "desc", value: cmd.desc });
        }
        if (cmd.usage) {
          details.push({ key: "usage", value: cmd.usage });
        }
        if (cmd.example) {
          details.push({ key: "example", value: cmd.example });
        }
        const permissions = [];
        if (cmd.isOwner) permissions.push("Owner");
        if (cmd.isGroup) permissions.push("Group Only");
        if (cmd.isPrivate) permissions.push("Private Only");
        if (permissions.length > 0) {
          details.push({ key: "perms", value: permissions.join(", ") });
        }
        details.forEach((detail, i) => {
          const isLastDetail = i === details.length - 1;
          const detailPrefix = isLastDetail ? "╰─" : "├─";
          response += `│  ${detailPrefix} ${detail.key}: ${detail.value}\n`;
        });
        if (!isLastCommand) {
          response += "│\n";
        }
      });
      response += `╰─ ╽ Total command: *${filteredCommands.length}*`;
      return sock.sendMessage(
        m.chat,
        {
          text: response,
          mentions: [m.sender, sock.user.id.split(":")[0] + "@s.whatsapp.net"],
          contextInfo: {
            mentionedJid: [
              m.sender,
              sock.user.id.split(":")[0] + "@s.whatsapp.net",
            ],
            externalAdReply: {
              title: "BOT WHATSAPP BY BANG SYAII",
              body: "dibuat alakadarnya penting jadi",
              mediaType: 1,
              thumbnailUrl: "https://files.catbox.moe/yupd7z.jpg",
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: m },
      );
    }
    const commandsByCategory = {};
    commands.forEach((command) => {
      const category = command.category?.[0] || false;
      if (category) {
        if (!commandsByCategory[category]) {
          commandsByCategory[category] = [];
        }
        commandsByCategory[category].push(command);
      }
    });
    let menuText =
      `Hai @${m.sender.split("@")[0]} Selamat datang di menu kami
╭─╽「 *\`OS INFO\`* 」   
├─╼ *OS Type*: ${osType}
├─╼ *Platform*: ${osPlatform} (${osArch})
├─╼ *Hostname*: ${osHostname}
├─╼ *Uptime*: ${osUptime}
├─╼ *Total Mem*: ${osTotalMem}
├─╼ *Free Mem*: ${osFreeMem}
╰─────────────────
╭─╽「 *\`BOT INFO\`* 」   
├─╼ *Total Commands*: ${totalCommands}
├─╼ *Uptime*: ${formatUptime(process.uptime())}
├─╼ *Number Bot*: @${sock.user.id.split(":")[0]}
╰─╽ For details, type: *.menu [category]*

If you find a bug, just contact:
${process.env.OWNER}

` + "╭─╽「 *ALL MENU* 」╽─╮\n│\n";
    const sortedCategories = Object.keys(commandsByCategory).sort();
    sortedCategories.forEach((category, index) => {
      const isLastCategory = index === sortedCategories.length - 1;
      const categoryPrefix = isLastCategory ? "╰─" : "├─";
      const categoryCommands = commandsByCategory[category];
      menuText += `${categoryPrefix}╽ *${category.toUpperCase()}* \`(${categoryCommands.length})\`\n`;
      categoryCommands.forEach((command, cmdIndex) => {
        const isLastCommand = cmdIndex === categoryCommands.length - 1;
        const commandPrefix = isLastCategory ? "  " : "│ ";
        const connector = isLastCommand ? "╰─▸" : "├─▸";
        menuText += `${commandPrefix}${connector} ${command.name}\n`;
      });
      if (!isLastCategory) menuText += "│\n";
    });
    menuText += `\n> _Copyright ${new Date().getFullYear()} by Bang syaii_`;
    await sock.sendMessage(
      m.chat,
      {
        text: menuText,
        mentions: [m.sender, sock.user.id.split(":")[0] + "@s.whatsapp.net"],
        contextInfo: {
          mentionedJid: [
            m.sender,
            sock.user.id.split(":")[0] + "@s.whatsapp.net",
          ],
          externalAdReply: {
            title: "BOT WHATSAPP BY BANG SYAII",
            body: "dibuat alakadarnya penting jadi",
            mediaType: 1,
            thumbnailUrl: "https://files.catbox.moe/yupd7z.jpg",
            renderLargerThumbnail: true,
          },
        },
      },
      { quoted: m },
    );
  },
});
