import dotenv from "dotenv";
dotenv.config();
import NodeCache from "@cacheable/node-cache";
import * as readline from "readline";
import fs from "fs/promises";
import path from "path";
import {
  DisconnectReason,
  jidNormalizedUser,
  fetchLatestBaileysVersion,
  getAggregateVotesInPollMessage,
  makeCacheableSignalKeyStore,
  proto,
  useMultiFileAuthState,
} from "baileys";
import makeWASocket from "./src/utils/socket.js";
import * as P from "pino";
import { procMsg } from "./src/utils/msg.js";
import { prMsg } from "./src/utils/fmt.js";
import Scrapers from "./src/scrapers/index.js";
const { default: CmdRegis } = await import("./src/commands/register.js");
import Database from "./src/utils/database.js";
const db = new Database("db.json");

try {
  await db.init();
  await CmdRegis.watch();
  await Scrapers.watch();
setInterval(async () => {
    await db.save();
    await CmdRegis.load();
    await Scrapers.load();
  }, 200);
} catch (error) {
  console.error("Error loading or watching commands:", error);
}
import handler from "./src/commands/handler.js";
const LocalStore = {
  messages: {},
  groupMetadata: {},
  contacts: {},
};
const saveStore = async () => {
  try {
    const storePath = path.join(process.cwd(), "store.json");
    let fileSize = 0;
    try {
      const stats = await fs.stat(storePath);
      fileSize = stats.size;
    } catch (error) {
      if (error.code !== "ENOENT") {
        console.error("Error checking store file size:", error);
      }
    }
    const MAX_FILE_SIZE = 100 * 1048576;
    if (fileSize >= MAX_FILE_SIZE) {
      console.log(
        `Store file size is ${Math.round(fileSize / 1048576)}MB, exceeding 100MB limit. Resetting store data...`,
      );
      LocalStore.messages = {};
      LocalStore.groupMetadata = {};
      LocalStore.contacts = {};
    }

    const cleanedMessages = {};
    for (const [jid, messages] of Object.entries(LocalStore.messages)) {
      if (Array.isArray(messages)) {
        const MAX_MESSAGES_PER_JID = 100;
        if (messages.length > MAX_MESSAGES_PER_JID) {
          cleanedMessages[jid] = messages.slice(-MAX_MESSAGES_PER_JID);
        } else {
          cleanedMessages[jid] = messages;
        }
      }
    }
    const storeData = {
      messages: cleanedMessages,
      groupMetadata: LocalStore.groupMetadata,
      contacts: LocalStore.contacts,
    };
    await fs.writeFile(
      storePath,
      JSON.stringify(
        storeData,
        (key, value) => {
          if (typeof value === "function") {
            return undefined;
          }
          if (value && typeof value === "object" && value.toJSON) {
            return value.toJSON();
          }
          return value;
        },
        2,
      ),
    );
    console.log("Store data saved to store.json");
  } catch (error) {
    console.error("Error saving store data:", error);
  }
};
const loadStore = async () => {
  try {
    const storePath = path.join(process.cwd(), "store.json");

    // Check if file exists and get its size
    let fileSize = 0;
    try {
      const stats = await fs.stat(storePath);
      fileSize = stats.size;
    } catch (error) {
      // File doesn't exist, starting with empty store
      if (error.code === "ENOENT") {
        console.log("No store.json file found, starting with empty store");
        return;
      } else {
        console.error("Error checking store file size:", error);
        return;
      }
    }

    const MAX_FILE_SIZE = 100 * 1048576; // 100MB in bytes

    if (fileSize >= MAX_FILE_SIZE) {
      console.log(
        `Store file size is ${Math.round(fileSize / 1048576)}MB, exceeding 100MB limit. Resetting store data...`,
      );
      // Reset to empty store instead of loading large file
      LocalStore.messages = {};
      LocalStore.groupMetadata = {};
      LocalStore.contacts = {};
      // Remove the large file
      await fs.unlink(storePath);
      console.log("Large store file removed and store reset");
      return;
    }

    const storeData = await fs.readFile(storePath, "utf8");
    const parsedData = JSON.parse(storeData);
    const cleanedMessages = {};
    for (const [jid, messages] of Object.entries(parsedData.messages || {})) {
      if (Array.isArray(messages)) {
        const MAX_MESSAGES_PER_JID = 100;
        if (messages.length > MAX_MESSAGES_PER_JID) {
          cleanedMessages[jid] = messages.slice(-MAX_MESSAGES_PER_JID);
        } else {
          cleanedMessages[jid] = messages;
        }
      }
    }
    LocalStore.messages = cleanedMessages;
    LocalStore.groupMetadata = { ...(parsedData.groupMetadata || {}) };
    LocalStore.contacts = { ...(parsedData.contacts || {}) };
    console.log("Store data loaded from store.json");
  } catch (error) {
    if (error.code === "ENOENT") {
      console.log("No store.json file found, starting with empty store");
    } else {
      console.error("Error loading store data:", error);
    }
  }
};
const logger = P.pino({
  level: "silent",
});
const msgRetryCounterCache = new NodeCache();
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
rl.on("close", () => {
  console.log("Readline interface closed");
});
const question = (text) =>
  new Promise((resolve, reject) => {
    try {
      rl.question(text, resolve);
    } catch (error) {
      console.error("Error with readline question:", error);
      reject(error);
    }
  });
const startWhatsApp = async () => {
  async function getMessage(key) {
    if (!key.remoteJid || !key.id) return undefined;
    return proto.Message.fromObject({ conversation: "test" });
  }
  const { state, saveCreds } = await useMultiFileAuthState("baileys_auth_info");
  const { version, isLatest } = await fetchLatestBaileysVersion();
  console.log(`using WA v${version.join(".")}, isLatest: ${isLatest}`);
  global.groupCache = new NodeCache({ stdTTL: 5 * 60, useClones: false });
  const config = {
    version,
    printQRInTerminal: false,
    logger,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    msgRetryCounterCache,
    generateHighQualityLinkPreview: true,
    getMessage,
    cachedGroupMetadata: async (jid) => Promise.resolve(groupCache.get(jid)),
  };
  const whatsapp = await makeWASocket(config);
  if (!whatsapp.authState.creds.registered) {
    try {
      const phoneNumber = await question("Please enter your phone number:\n");
      const code = await whatsapp.requestPairingCode(phoneNumber);
      console.log(`Pairing code: ${code}`);
    } catch (error) {
      console.error("Error getting phone number:", error.message);
      console.log("Continuing without phone number registration...");
    }
  }
  whatsapp.ev.process(async (events) => {
    if (events["connection.update"]) {
      const update = events["connection.update"];
      const { connection, lastDisconnect } = update;
      if (connection === "close") {
        if (
          lastDisconnect?.error?.output?.statusCode !==
          DisconnectReason.loggedOut
        ) {
          console.log("Restarting...");
          setTimeout(() => {
            startWhatsApp();
          }, 5000);
        } else {
          console.log("Connection closed. You are logged out.");
        }
      }
      if (connection === "open") {
        console.log("Success Connect to WhatsApp");
      }
    }
    if (events["creds.update"]) {
      await saveCreds();
    }
    if (events["labels.association"]) {
      console.log(events["labels.association"]);
    }
    if (events["labels.edit"]) {
      console.log(events["labels.edit"]);
    }
    if (events["messaging-history.set"]) {
      const { chats, contacts, messages, isLatest, progress, syncType } =
        events["messaging-history.set"];
      if (syncType === proto.HistorySync.HistorySyncType.ON_DEMAND) {
        console.log("received on-demand history sync, messages=", messages);
      }
      console.log(
        `recv ${chats.length} chats, ${contacts.length} contacts, ${messages.length} msgs (is latest: ${isLatest}, progress: ${progress}%), type: ${syncType}`,
      );
    }
    const ID = new Map();
    if (events["messages.upsert"]) {
      const upsert = events["messages.upsert"];
      if (upsert.type === "notify") {
        if (
          LocalStore.groupMetadata &&
          Object.keys(LocalStore.groupMetadata).length < 1
        )
          LocalStore.groupMetadata = await whatsapp
            .groupFetchAllParticipating()
            .catch((e) => {});
        if (!!upsert.requestId) {
          console.log(
            "placeholder message received for request of id=" +
              upsert.requestId,
            upsert,
          );
        }
        const msg = upsert.messages[0];
        const processedMessage = await procMsg(msg, whatsapp, LocalStore);
        const jid = processedMessage.chat;
        if (jid) {
          if (jid && !LocalStore.messages[jid])
            LocalStore.messages[jid] = [processedMessage];
          else LocalStore.messages[jid].push(processedMessage);
          if (
            LocalStore.messages[jid] &&
            Array.isArray(LocalStore.messages[jid])
          ) {
            const MAX_MESSAGES_PER_JID = 100;
            if (LocalStore.messages[jid].length > MAX_MESSAGES_PER_JID) {
              LocalStore.messages[jid] =
                LocalStore.messages[jid].slice(-MAX_MESSAGES_PER_JID);
            }
          }
        }
        if (!processedMessage) return;
        if (!processedMessage.message) return;
        if (processedMessage.type === "protocolMessage") return;
        if (ID.has(processedMessage?.id)) return;
        ID.set(processedMessage?.id, processedMessage);
        const oldSock = whatsapp;
        const originalSendMessage = whatsapp.sendMessage.bind(whatsapp);
        whatsapp.sendMessage = async (jid, content, options = {}) => {
          return originalSendMessage(jid, content, {
            ...options,
            ephemeralExpiration: processedMessage.isGroup
              ? (processedMessage.metadata &&
                  processedMessage.metadata.ephemeralDuration) ||
                null
              : processedMessage.message?.[processedMessage.type]?.contextInfo
                  ?.expiration || null,
          });
        };
        await whatsapp.readMessages([processedMessage.key]);
        await handler.handleCommand(
          processedMessage,
          whatsapp,
          LocalStore,
          Scrapers,
          db
        );
        prMsg(processedMessage);
      } else if (upsert.type === "append") {
        const msg = upsert.messages[0];
        const processedMessage = await procMsg(msg, whatsapp, LocalStore);
        console.log("[NOTIFICATION] BOT RESPONDING...");
        console.log(JSON.stringify(upsert, null, 0));
        const jid = processedMessage.chat;
        if (jid) {
          if (jid && !LocalStore.messages[jid])
            LocalStore.messages[jid] = [processedMessage];
          else LocalStore.messages[jid].push(processedMessage);
          if (
            LocalStore.messages[jid] &&
            Array.isArray(LocalStore.messages[jid])
          ) {
            const MAX_MESSAGES_PER_JID = 100;
            if (LocalStore.messages[jid].length > MAX_MESSAGES_PER_JID) {
              LocalStore.messages[jid] =
                LocalStore.messages[jid].slice(-MAX_MESSAGES_PER_JID);
            }
          }
        }
      }
    }
    if (events["messages.update"]) {
      for (const { update } of events["messages.update"]) {
        console.log(update);
        if (update.pollUpdates) {
          const pollCreation = {};
          if (pollCreation) {
            console.log(
              "got poll update, aggregation: ",
              getAggregateVotesInPollMessage({
                message: pollCreation,
                pollUpdates: update.pollUpdates,
              }),
            );
          }
        }
      }
    }
    if (events["contacts.upsert"]) {
      const update = events["contacts.upsert"];
      for (let contact of update) {
        let id = jidNormalizedUser(contact.id);
        if (LocalStore && LocalStore.contacts)
          LocalStore.contacts[id] = { ...(contact || {}), isContact: true };
        const MAX_CONTACTS = 5000;
        const contactKeys = Object.keys(LocalStore.contacts);
        if (contactKeys.length > MAX_CONTACTS) {
          const oldestKeys = contactKeys.slice(
            0,
            contactKeys.length - MAX_CONTACTS,
          );
          oldestKeys.forEach((key) => delete LocalStore.contacts[key]);
        }
      }
    }
    if (events["contacts.update"]) {
      for (const contact of events["contacts.update"]) {
        if (typeof contact.imgUrl !== "undefined") {
          const newUrl =
            contact.imgUrl === null
              ? null
              : await whatsapp.profilePictureUrl(contact.id).catch(() => null);
          console.log(`contact ${contact.id} has a new profile pic: ${newUrl}`);
        }
        let id = jidNormalizedUser(contact.id);
        if (LocalStore && LocalStore.contacts)
          LocalStore.contacts[id] = {
            ...(LocalStore.contacts?.[id] || {}),
            ...(contact || {}),
          };
        const MAX_CONTACTS = 5000;
        const contactKeys = Object.keys(LocalStore.contacts);
        if (contactKeys.length > MAX_CONTACTS) {
          const oldestKeys = contactKeys.slice(
            0,
            contactKeys.length - MAX_CONTACTS,
          );
          oldestKeys.forEach((key) => delete LocalStore.contacts[key]);
        }
      }
    }
    if (events["groups.upsert"]) {
      const newGroups = events["groups.upsert"];
      for (const groupMetadata of newGroups) {
        try {
          groupCache.set(groupMetadata.id, groupMetadata);
          LocalStore.groupMetadata[groupMetadata.id] = groupMetadata;
          const MAX_GROUPS = 1000;
          const groupKeys = Object.keys(LocalStore.groupMetadata);
          if (groupKeys.length > MAX_GROUPS) {
            const oldestKeys = groupKeys.slice(
              0,
              groupKeys.length - MAX_GROUPS,
            );
            oldestKeys.forEach((key) => delete LocalStore.groupMetadata[key]);
          }
        } catch (error) {
          console.error(
            `[GROUPS.UPSERT] Error adding group ${groupMetadata.id}:`,
            error,
          );
        }
      }
    }
    if (events["groups.update"]) {
      const updates = events["groups.update"];
      for (const update of updates) {
        const id = update.id;
        if (!id) continue;
        try {
          const metadata = await whatsapp.groupMetadata(id).catch((e) => {});
          if (!metadata) return;
          groupCache.set(id, metadata);
          if (LocalStore.groupMetadata[id]) {
            LocalStore.groupMetadata[id] = {
              ...(LocalStore.groupMetadata[id] || {}),
              ...metadata,
            };
          } else {
            LocalStore.groupMetadata[id] = metadata;
          }
        } catch (error) {
          console.error(`[GROUPS.UPDATE] Error updating group ${id}:`, error);
        }
      }
    }
    if (events["group-participants.update"]) {
      const { id, participants, action } = events["group-participants.update"];
      if (id) {
        try {
          const metadata = await whatsapp.groupMetadata(id).catch((e) => {});
          if (!metadata) return;
          groupCache.set(id, metadata);
          LocalStore.groupMetadata[id] = metadata;
          if (
            LocalStore.groupMetadata[id] &&
            LocalStore.groupMetadata[id].participants
          ) {
            switch (action) {
              case "add":
                LocalStore.groupMetadata[id].participants.push(
                  ...participants.map((jid) => ({
                    id: jidNormalizedUser(jid),
                    admin: null,
                  })),
                );
                break;
              case "demote":
                for (const participant of LocalStore.groupMetadata[id]
                  .participants) {
                  let participantId = jidNormalizedUser(participant.id);
                  if (participants.includes(participantId)) {
                    participant.admin = null;
                  }
                }
                break;
              case "promote":
                for (const participant of LocalStore.groupMetadata[id]
                  .participants) {
                  let participantId = jidNormalizedUser(participant.id);
                  if (participants.includes(participantId)) {
                    participant.admin = "admin";
                  }
                }
                break;
              case "remove":
                LocalStore.groupMetadata[id].participants =
                  LocalStore.groupMetadata[id].participants.filter(
                    (p) => !participants.includes(jidNormalizedUser(p.id)),
                  );
                break;
            }
          }
        } catch (error) {
          console.error(
            `[GROUP-PARTICIPANTS.UPDATE] Error processing group ${id}:`,
            error,
          );
        }
      }
    }
    if (events["chats.delete"]) {
      console.log("chats deleted ", events["chats.delete"]);
    }
  });
  const cleanupStore = () => {
    for (const [jid, messages] of Object.entries(LocalStore.messages)) {
      if (Array.isArray(messages)) {
        const MAX_MESSAGES_PER_JID = 100;
        if (messages.length > MAX_MESSAGES_PER_JID) {
          LocalStore.messages[jid] = messages.slice(-MAX_MESSAGES_PER_JID);
        }
      }
    }
  };
  setInterval(cleanupStore, 5 * 60 * 1000);
  setInterval(async () => {
    await saveStore();
  }, 60000);
  return whatsapp;
};
loadStore()
  .then(() => {
    startWhatsApp();
  })
  .catch((error) => {
    console.error("Error loading store, starting with empty store:", error);
    startWhatsApp();
  });
