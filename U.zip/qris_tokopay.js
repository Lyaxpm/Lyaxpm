require("dotenv").config();
const axios = require("axios");
const { Order } = require("./db");

async function createOrder(internalOrderId, amount) {
  const merchant_id = process.env.MERCHANT_ID_TOKOPAY;
  const secret_key = process.env.SECRET_KEY_TOKOPAY;
  const apiUrl = `https://api.tokopay.id/v1/order?merchant=${merchant_id}&secret=${secret_key}&ref_id=${internalOrderId}&nominal=${amount}&metode=QRIS`;
  const response = await axios.get(apiUrl);
  const dataResponse = response.data;

  if (dataResponse && dataResponse.status === "Success") {
    const paymentData = dataResponse.data;
    const fee = paymentData.total_bayar - paymentData.total_diterima;
    return {
      qrImage: paymentData.qr_link,
      displayOrderId: internalOrderId,
      realOrderId: paymentData.trx_id,
      totalBayar: parseInt(paymentData.total_bayar),
      totalDiterima: parseInt(paymentData.total_diterima),
      fee: fee,
    };
  } else {
    throw new Error(dataResponse.message || "Tokopay API Error");
  }
}

async function checkPaymentStatus(orderId, amount) {
  const order = await Order.findOne({ orderId: orderId });
  if (!order) return { status: "NOT_FOUND" };

  if (["PAID", "EXPIRED", "CANCELLED"].includes(order.status)) {
    console.log(`[TOKOPAY CHECK] Order ${orderId} sudah ${order.status}`);
    return { status: order.status, order };
  }

  const merchant_id = process.env.MERCHANT_ID_TOKOPAY;
  const secret_key = process.env.SECRET_KEY_TOKOPAY;
  const url = `https://api.tokopay.id/v1/order?merchant=${merchant_id}&secret=${secret_key}&ref_id=${order.internalRefId}&nominal=${amount}&metode=QRIS`;
  const response = await axios.get(url);
  const data = response.data;

  console.log(`[TOKOPAY RESPONSE] ${orderId}:`, data);

  if (data.status === "Success" && data.data) {
    const paymentStatus = data.data.status.toLowerCase();
    console.log(`[TOKOPAY STATUS] ${orderId} => ${paymentStatus}`);

    if (paymentStatus === "unpaid") {
      return { status: "PENDING", order };
    } else if (paymentStatus === "success") {
      if (order.status === "PENDING") {
        order.status = "PAID";
        order.paidAt = new Date();
        order.paymentDetails = data.data;
        await order.save();

 //       await updateStokKeLaravel(order.sku, order.items);
      }
      return { status: "PAID", order };
    } else {
      order.status = "EXPIRED";
      await order.save();
      return { status: "EXPIRED", order };
    }
  } else {
    console.log(`[TOKOPAY CHECK] Tidak ada data valid untuk ${orderId}`);
    return { status: "PENDING", order };
  }
}

async function updateStokKeLaravel(sku, items) {
  try {
    if (!sku || !items || !Array.isArray(items) || items.length === 0) {
      console.log("[Webhook Laravel] SKU atau items kosong, abaikan...");
      return;
    }

    const apiUrl = "https://exlupay.com/api/webhook/stok-terjual";
    const payload = { sku, items };

    console.log("[Webhook Laravel] Mengirim data:", payload);
    const response = await axios.post(apiUrl, payload, {
      headers: { "Content-Type": "application/json" },
    });
    console.log(`[Webhook Laravel] Stok terjual (${sku}):`, response.data);
  } catch (err) {
    console.error("[Webhook Laravel] Gagal update stok:", err.response?.data || err.message);
  }
}

module.exports = {
  init: async () => console.log("[ Tokopay Payment System Initialized (URL Method) ]"),
  createOrder,
  checkPaymentStatus,
  updateStokKeLaravel,
};
