// qris_tokopay.js (FINAL - MongoDB Ready)
require("dotenv").config();
const axios = require("axios");
const moment = require("moment-timezone");
// REVISI: Impor Model 'Order' dari Mongoose, bukan file-based DB
const { Order } = require('./db');

/**
 * Membuat order pembayaran QRIS baru melalui Tokopay.
 * Fungsi ini HANYA berinteraksi dengan API Tokopay dan mengembalikan hasilnya.
 * Penyimpanan pesanan ke DB dilakukan di `bot.js` dalam sebuah transaksi.
 */
async function createOrder(
    internalOrderId,
    amount,
) {
    const merchant_id = process.env.MERCHANT_ID_TOKOPAY;
    const secret_key = process.env.SECRET_KEY_TOKOPAY;
    const apiUrl = `https://api.tokopay.id/v1/order?merchant=${merchant_id}&secret=${secret_key}&ref_id=${internalOrderId}&nominal=${amount}&metode=QRIS`;

    try {
        console.log(`[Tokopay] Creating order with GET request to: ${apiUrl}`);
        const response = await axios.get(apiUrl);
        const dataResponse = response.data;

        if (dataResponse && dataResponse.status === "Success") {
            const paymentData = dataResponse.data;
            const fee = paymentData.total_bayar - paymentData.total_diterima;
            
            // Mengembalikan detail yang diperlukan untuk membuat pesanan di bot.js
            return {
                qrImage: paymentData.qr_link,
                displayOrderId: internalOrderId, // Ini akan menjadi orderId di DB kita
                realOrderId: paymentData.trx_id,
                amount: parseInt(paymentData.total_diterima),
                fee: fee,
            };
        } else {
            const errorMessage = dataResponse.message || "Tokopay API returned an unsuccessful status.";
            throw new Error(`Tokopay API Error: ${errorMessage}`);
        }
    } catch (error) {
        let detailedError = "Gagal membuat pembayaran Tokopay.";
        if (error.response && error.response.data) {
            const apiErrorData = error.response.data;
            detailedError = `Tokopay API Error (${error.response.status}): ${apiErrorData.message || JSON.stringify(apiErrorData)}`;
        } else {
            detailedError = `Network error while contacting Tokopay: ${error.message}`;
        }
        throw new Error(detailedError);
    }
}

/**
 * Memeriksa status pembayaran sebuah order di Tokopay dan mengupdate DB jika perlu.
 */
// GANTI SELURUH FUNGSI INI DENGAN VERSI DI BAWAH
async function checkPaymentStatus(orderId) {
    const order = await Order.findOne({ orderId: orderId });
    if (!order) return { status: "NOT_FOUND" };
    if (order.status === "PAID" || order.status === "EXPIRED" || order.status === "CANCELLED") {
        return { status: order.status, order: order };
    }

    const merchant_id = process.env.MERCHANT_ID_TOKOPAY;
    const secret_key = process.env.SECRET_KEY_TOKOPAY;
    const url = `https://api.tokopay.id/v1/order?merchant=${merchant_id}&secret=${secret_key}&ref_id=${order.internalRefId}`;

    try {
        const response = await axios.get(url);
        const data = response.data;

        // [LOG 1] Tampilkan seluruh respons mentah dari API ke konsol
        console.log(`[Tokopay Polling] Full API Response for ref_id ${order.internalRefId}:`, JSON.stringify(data, null, 2));

        if (data.status === "Success" && data.data) {
            const paymentStatus = data.data.status.trim().toLowerCase();

            // [LOG 2] Tampilkan status yang sudah dibersihkan dan siap diperiksa
            console.log(`[Tokopay Polling] Cleaned status to check: "${paymentStatus}"`);

            if (paymentStatus === "success") { 
                if (order.status === "PENDING") {
                    order.status = "PAID";
                    order.paidAt = new Date();
                    order.paymentDetails = data.data;
                    await order.save();
                }
                return { status: "PAID", order: order };
            } else if (paymentStatus === "unpaid") {
                return { status: "PENDING", order: order };
            } else { 
                return { status: "EXPIRED", order: order };
            }
        } else {
            return { status: "PENDING", order: order };
        }
    } catch (error) {
        console.error("Check Tokopay status error:", error.message);
        return { status: "API_ERROR" };
    }
}

/**
 * Mengambil data order dari database berdasarkan orderId.
 */
async function getOrderData(orderId) {
    // REVISI: Menggunakan Mongoose untuk mencari pesanan dengan efisien
    return await Order.findOne({ orderId: orderId }).lean();
}

/**
 * Membatalkan order di database.
 */
async function cancelOrder(orderId) {
    // REVISI: Menggunakan Mongoose untuk membatalkan pesanan
    await Order.findOneAndUpdate(
        { orderId: orderId, status: 'PENDING' },
        { $set: { status: 'CANCELLED', cancelledAt: new Date() } }
    );
}

module.exports = {
    init: async () => {
        console.log("[ Tokopay Payment System Initialized (URL Method) ]");
    },
    createOrder,
    checkPaymentStatus,
    getOrderData,
    cancelOrder,
};