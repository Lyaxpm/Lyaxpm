'use strict';

/**
 * AI Agent — Groq (llama-3.1-8b-instant)
 * Menangani pesan bebas (tanpa prefix command) dari user.
 * Hemat token: system prompt ringkas + tool calling terstruktur.
 * Hanya menampilkan produk yang AKTIF (active !== false).
 */

const axios = require('axios');
const db = require('../models/db');
const { formatRupiah } = require('../utils/helper');

const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const GROQ_MODEL   = process.env.GROQ_MODEL || 'llama-3.1-8b-instant';

// ── Riwayat percakapan per user (max 6 pesan terakhir) ────────────────────
const conversationHistory = {};
const MAX_HISTORY = 6;

function getHistory(jid) {
  if (!conversationHistory[jid]) conversationHistory[jid] = [];
  return conversationHistory[jid];
}

function addHistory(jid, role, content) {
  const hist = getHistory(jid);
  hist.push({ role, content: String(content) });
  if (hist.length > MAX_HISTORY) hist.splice(0, hist.length - MAX_HISTORY);
}

function clearHistory(jid) {
  conversationHistory[jid] = [];
}

// ── Definisi tools yang bisa dipanggil AI ─────────────────────────────────
const TOOLS = [
  {
    type: 'function',
    function: {
      name: 'cari_produk',
      description:
        'Cari produk AKTIF berdasarkan kata kunci. ' +
        'Gunakan untuk menjawab pertanyaan harga, stok, atau daftar produk.',
      parameters: {
        type: 'object',
        properties: {
          keyword: {
            type: 'string',
            description:
              'Kata kunci pencarian, contoh: "diamond ml", "pulsa telkomsel", "token pln"'
          }
        },
        required: ['keyword']
      }
    }
  },
  {
    type: 'function',
    function: {
      name: 'lihat_kategori',
      description: 'Tampilkan semua kategori produk AKTIF yang tersedia.',
      parameters: { type: 'object', properties: {} }
    }
  },
  {
    type: 'function',
    function: {
      name: 'cek_pesanan_user',
      description: 'Cek riwayat pesanan milik user ini.',
      parameters: { type: 'object', properties: {} }
    }
  }
];

// ── Eksekusi tool ──────────────────────────────────────────────────────────
function executeTool(name, args, buyerJid) {
  const storeName = process.env.STORE_NAME || 'Toko';

  // ── cari_produk ──────────────────────────────────────────────────────────
  if (name === 'cari_produk') {
    const keyword = (args.keyword || '').toLowerCase().trim();
    if (!keyword) return 'Kata kunci pencarian kosong.';

    const results = [];

    // Produk manual: hanya yang active !== false
    Object.values(db.getProducts())
      .filter(p => p.active !== false)
      .forEach(p => {
        const haystack = [p.name, p.category, p.id, p.description]
          .join(' ')
          .toLowerCase();
        if (haystack.includes(keyword)) {
          results.push({
            kode:  p.id,
            nama:  p.name,
            harga: formatRupiah(p.price),
            kategori: p.category || '-'
          });
        }
      });

    // Produk Digiflazz: hanya yang active !== false DAN stock === 'available'
    const margin = db.getProfitMargin();
    Object.values(db.getDigiProducts())
      .filter(p => p.active !== false && p.stock === 'available')
      .forEach(p => {
        const haystack = [p.product_name, p.category, p.buyer_sku_code, p.brand]
          .join(' ')
          .toLowerCase();
        if (haystack.includes(keyword)) {
          // Gunakan sellPrice kustom jika ada, fallback ke price + margin
          const hargaJual = p._customPrice && p.sellPrice
            ? p.sellPrice
            : Math.ceil((p.price || 0) * (1 + margin / 100));
          results.push({
            kode:  p.buyer_sku_code,
            nama:  p.product_name,
            harga: formatRupiah(hargaJual),
            kategori: p.category || '-'
          });
        }
      });

    if (!results.length) {
      return `Tidak ada produk aktif yang cocok dengan "${args.keyword}".`;
    }

    const limited = results.slice(0, 8);
    const rows = limited
      .map(r => `- ${r.nama} | ${r.harga} | kode: ${r.kode}`)
      .join('\n');
    const more =
      results.length > 8 ? `\n...dan ${results.length - 8} produk lainnya.` : '';
    return `Hasil pencarian "${args.keyword}":\n${rows}${more}`;
  }

  // ── lihat_kategori ───────────────────────────────────────────────────────
  if (name === 'lihat_kategori') {
    const cats = {};

    // Hanya produk aktif
    Object.values(db.getDigiProducts())
      .filter(p => p.active !== false && p.stock === 'available')
      .forEach(p => {
        const c = p.category || 'Lainnya';
        cats[c] = (cats[c] || 0) + 1;
      });

    Object.values(db.getProducts())
      .filter(p => p.active !== false)
      .forEach(p => {
        const c = p.category || 'Lainnya';
        cats[c] = (cats[c] || 0) + 1;
      });

    if (!Object.keys(cats).length) return 'Belum ada produk aktif tersedia.';

    const list = Object.entries(cats)
      .sort((a, b) => b[1] - a[1])
      .map(([c, n]) => `- ${c} (${n} produk)`)
      .join('\n');
    return `Kategori produk aktif di ${storeName}:\n${list}`;
  }

  // ── cek_pesanan_user ─────────────────────────────────────────────────────
  if (name === 'cek_pesanan_user') {
    const orders = db.getUserOrders(buyerJid);
    if (!orders.length) return 'Kamu belum punya pesanan.';
    const recent = orders.slice(-5).reverse();
    const rows = recent
      .map(o => `- ID: ${o.id} | ${o.productName || o.productId} | ${o.status}`)
      .join('\n');
    return `5 pesanan terakhirmu:\n${rows}`;
  }

  return 'Tool tidak dikenal.';
}

// ── System prompt ringkas (hemat token) ───────────────────────────────────
function buildSystemPrompt() {
  const store = process.env.STORE_NAME || 'Toko Digital';
  return (
    `Kamu CS (customer service) ${store} di WhatsApp. ` +
    `Jawab singkat, ramah, pakai bahasa Indonesia informal.\n\n` +
    `Tugasmu: bantu user tanya produk/harga, arahkan beli pakai command !beli <kode>.\n` +
    `Jangan tampilkan produk yang nonaktif. ` +
    `Jangan buat janji yang tidak ada di data. Kalau tidak tahu, jujur saja.\n` +
    `Untuk beli: user ketik !beli <kode_produk>\n` +
    `Untuk cek order: user ketik !cekpesanan <id_order>`
  );
}

// ── Panggil Groq API ───────────────────────────────────────────────────────
async function callGroq(messages, withTools) {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) throw new Error('GROQ_API_KEY belum diset di .env');

  const body = {
    model:       GROQ_MODEL,
    messages,
    max_tokens:  400,
    temperature: 0.5
  };
  if (withTools) {
    body.tools       = TOOLS;
    body.tool_choice = 'auto';
  }

  const res = await axios.post(GROQ_API_URL, body, {
    headers: {
      Authorization:  `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    timeout: 15000
  });
  return res.data.choices[0].message;
}

// ── Entry point: dipanggil dari messageHandler ────────────────────────────
async function handle(sock, msg, userText) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;

  // Reset history
  if (/^(reset|clear|mulai ulang)$/i.test(userText.trim())) {
    clearHistory(buyerJid);
    await sock.sendMessage(
      jid,
      { text: 'Percakapan direset. Ada yang bisa saya bantu?' },
      { quoted: msg }
    );
    return;
  }

  try {
    addHistory(buyerJid, 'user', userText);

    const messages = [
      { role: 'system', content: buildSystemPrompt() },
      ...getHistory(buyerJid)
    ];

    // Putaran pertama — dengan tools
    let aiMsg = await callGroq(messages, true);

    // Kalau AI memanggil tool
    if (aiMsg.tool_calls && aiMsg.tool_calls.length) {
      const toolResults = [];

      for (const tc of aiMsg.tool_calls) {
        let args = {};
        try { args = JSON.parse(tc.function.arguments || '{}'); } catch (_) {}
        const result = executeTool(tc.function.name, args, buyerJid);
        toolResults.push({
          role:         'tool',
          tool_call_id: tc.id,
          content:      result
        });
      }

      // Putaran kedua — tanpa tools, biarkan AI merangkai jawaban
      const messages2 = [
        { role: 'system', content: buildSystemPrompt() },
        ...getHistory(buyerJid),
        aiMsg,
        ...toolResults
      ];
      aiMsg = await callGroq(messages2, false);
    }

    const replyText =
      (aiMsg.content || '').trim() ||
      'Maaf, saya tidak bisa memproses permintaan ini.';

    addHistory(buyerJid, 'assistant', replyText);
    await sock.sendMessage(jid, { text: replyText }, { quoted: msg });

  } catch (err) {
    console.error('[aiAgent] Error:', err.response?.data || err.message);
    const fallback =
      'Maaf, asisten AI sedang sibuk. Gunakan command:\n' +
      '!menu - lihat semua menu\n' +
      '!cari <produk> - cari produk\n' +
      '!beli <kode> - beli produk';
    await sock.sendMessage(jid, { text: fallback }, { quoted: msg });
  }
}

module.exports = { handle, clearHistory };
