const axios   = require('axios');
const moment  = require('moment');
require('moment/locale/id');
moment.locale('id');

const db           = require('../models/db');
const { formatRupiah, formatDate, orderStatusEmoji, orderStatusText, isAdmin } = require('../utils/helper');
const { header, LINE } = require('../utils/template');
const orderService = require('../services/orderService');
const { sendToAdmin } = require('../utils/sender');

const buyState = {};
const send = (sock, jid, text, msg) =>
  sock.sendMessage(jid, { text }, msg ? { quoted: msg } : undefined);

// ── Label input per tipe ───────────────────────────────────────────────────
const INPUT_LABEL = {
  phone:          { q: '📱 Masukkan nomor HP tujuan:', ex: '08123456789' },
  game_id:        { q: '🎮 Masukkan ID Game:', ex: '123456789' },
  game_id_server: { q: '🎮 Masukkan ID Game & Server (pisah spasi):', ex: '123456789 1234' },
  pln:            { q: '⚡ Masukkan ID Pelanggan PLN / nomor meter:', ex: '123456789012' },
  customer_id:    { q: '🆔 Masukkan nomor ID Pelanggan:', ex: '123456789' },
};

// ═══════════════════════════════════════════════════════════════════════════
// MENU
// ═══════════════════════════════════════════════════════════════════════════
async function handleMenu(sock, msg) {
  const jid = msg.key.remoteJid;
  const text =
    `${header(sock)}\n` +
    ` *MENU ${(process.env.STORE_NAME || 'CASSIE STORE').toUpperCase()}*\n\n` +
    `🛍️⊹ 𝗽𝗿𝗼𝗱𝘂𝗰𝘁 ⦂\n` +
    `  !pricelist — Lihat daftar kategori\n` +
    `  !pricelist <kategori> — Produk per kategori\n` +
    `  !cari <kata kunci> — Cari produk\n\n` +
    `🛍️⊹ 𝗯𝗲𝗹𝗶 ⦂\n` +
    `  !beli <kode> — Beli produk (semua jenis)\n` +
    `  #buy <kode> — Sama dengan !beli\n\n` +
    `🛍️⊹ 𝗽𝗲𝘀𝗮𝗻𝗮𝗻 ⦂\n` +
    `  !pesanan — Riwayat pesananku\n` +
    `  !cekpesanan <ID> — Cek status pesanan\n` +
    `  #komplain <ID> <pesan> — Komplain pesanan\n\n` +
    `_Prefix: !, ., #_`;
  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// PRICELIST — per kategori + pagination
// Produk manual tampil dengan kategorinya sendiri (bukan label "manual")
// ═══════════════════════════════════════════════════════════════════════════
async function handlePricelist(sock, msg, args) {
  const jid   = msg.key.remoteJid;
  const input = args.join(' ').trim().toLowerCase();

  const digiAll = db.getDigiProducts();
  const manuals = Object.values(db.getProducts()).filter(p => p.active !== false);

  // ── Tanpa argumen: daftar kategori ────────────────────────────────────
  if (!input) {
    // Kategori dari Digiflazz
    const digiCats = {};
    Object.values(digiAll).forEach(p => {
      if (p.active === false || p.stock !== 'available') return;
      const c = p.category || 'Lainnya';
      digiCats[c] = (digiCats[c] || 0) + 1;
    });

    // Kategori dari produk manual
    const manualCats = {};
    manuals.forEach(p => {
      const c = p.category || 'Lainnya';
      manualCats[c] = (manualCats[c] || 0) + 1;
    });

    let text =
      `${header(sock)}\n` +
      ` *📋 DAFTAR KATEGORI*\n` +
      `${LINE}\n\n`;

    // Gabung semua kategori
    const allCats = {};
    Object.entries(manualCats).forEach(([c, n]) => allCats[c] = (allCats[c] || 0) + n);
    Object.entries(digiCats).forEach(([c, n])   => allCats[c] = (allCats[c] || 0) + n);

    if (!Object.keys(allCats).length) {
      text += `_Belum ada produk._\n_Admin ketik: .getservice_\n`;
    } else {
      Object.entries(allCats)
        .sort((a, b) => b[1] - a[1])
        .forEach(([cat, count]) => {
          text += `📁 *${cat}* — ${count} produk\n`;
          text += `   › !pricelist ${cat.toLowerCase()}\n`;
        });
    }
    text += `\n${LINE}\n🔍 *!cari <kata>*  •  🛒 *!beli <kode>*`;
    return await send(sock, jid, text, msg);
  }

  // ── Cari produk yang cocok kategori/brand (manual + digi) ─────────────
  const matchedManual = manuals.filter(p => {
    const cat = (p.category || 'Lainnya').toLowerCase();
    return cat.includes(input);
  });

  const matchedDigi = Object.values(digiAll).filter(p => {
    if (p.active === false || p.stock !== 'available') return false;
    return (
      p.category?.toLowerCase().includes(input) ||
      p.brand?.toLowerCase().includes(input)
    );
  });

  if (!matchedManual.length && !matchedDigi.length)
    return await send(sock, jid,
      `${header(sock)}\n❌ Kategori *${input}* tidak ditemukan.\n` +
      `Ketik *!pricelist* untuk lihat semua kategori.`, msg);

  const catTitle = input.toUpperCase();
  const totalCount = matchedManual.length + matchedDigi.length;
  const LIMIT = 1800;

  let chunk = `${header(sock)}\n *📁 ${catTitle}* — ${totalCount} produk\n${LINE}\n\n`;
  let chunks = [];

  // Tampilkan produk manual dulu (kalau ada)
  if (matchedManual.length) {
    let block = `🏪 *PRODUK ${catTitle}*\n`;
    matchedManual.forEach(p => {
      block += `  🩰 ${p.name}\n`;
      block += `     𝗸𝗼𝗱𝗲 ⦂ \`${p.id}\`  𝗵𝗮𝗿𝗴𝗮 ⦂ ${formatRupiah(p.price)}\n`;
      if (p.description) block += `     ℹ️ ${p.description}\n`;
      if (p.stock !== undefined) block += `     stok ⦂ ${p.stock > 0 ? p.stock : '❌ Habis'}\n`;
    });
    block += '\n';

    if (chunk.length + block.length > LIMIT) { chunks.push(chunk); chunk = ` *📁 ${catTitle}* (lanjutan)\n${LINE}\n\n`; }
    chunk += block;
  }

  // Tampilkan produk Digiflazz, group by brand
  const brands = {};
  matchedDigi.forEach(p => {
    const b = p.brand || 'Lainnya';
    if (!brands[b]) brands[b] = [];
    brands[b].push(p);
  });

  Object.entries(brands).forEach(([brand, prods]) => {
    let block = `📱 *${brand}*\n`;
    prods.forEach(p => {
      // Fix NaN: sellPrice bisa 0 untuk pasca, fallback ke buyerPrice
      const harga = p.sellPrice > 0 ? p.sellPrice : (p.buyerPrice || 0);
      const hargaStr = harga > 0 ? formatRupiah(harga) : '_Cek tagihan_';
      block += `  🩰 ${p.name}\n`;
      block += `     𝗸𝗼𝗱𝗲 ⦂ \`${p.sku}\`  𝗵𝗮𝗿𝗴𝗮 ⦂ ${hargaStr}\n`;
    });
    block += '\n';

    if (chunk.length + block.length > LIMIT) { chunks.push(chunk); chunk = ` *📁 ${catTitle}* (lanjutan)\n${LINE}\n\n`; }
    chunk += block;
  });
  chunks.push(chunk);

  const total = chunks.length;
  for (let i = 0; i < chunks.length; i++) {
    let page = chunks[i];
    if (total > 1) page += `📄 _Halaman ${i + 1}/${total}_\n`;
    if (i === chunks.length - 1) {
      page += `${LINE}\n💡 *!beli <kode>*  •  🔍 *!cari <kata>*`;
    }
    await send(sock, jid, page, i === 0 ? msg : null);
    if (total > 1 && i < chunks.length - 1) await new Promise(r => setTimeout(r, 700));
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// CARI
// ═══════════════════════════════════════════════════════════════════════════
async function handleSearch(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args.length)
    return await send(sock, jid, `❌ Format: *!cari <kata kunci>*\nContoh: !cari xl 5000`, msg);

  const kw      = args.join(' ').toLowerCase();
  const digi    = db.getDigiProducts();
  const manuals = Object.values(db.getProducts()).filter(p => p.active !== false);

  const results = [];
  manuals.forEach(p => {
    if (p.name.toLowerCase().includes(kw) || p.id.toLowerCase().includes(kw) ||
        (p.category || '').toLowerCase().includes(kw))
      results.push({ _type: 'manual', kode: p.id, nama: p.name, harga: p.price, cat: p.category });
  });
  Object.values(digi).forEach(p => {
    if (p.active === false) return;
    if (p.name.toLowerCase().includes(kw) || p.sku.toLowerCase().includes(kw) ||
        p.brand?.toLowerCase().includes(kw) || p.category?.toLowerCase().includes(kw)) {
      const harga = p.sellPrice > 0 ? p.sellPrice : (p.buyerPrice || 0);
      results.push({ _type: 'digi', kode: p.sku, nama: p.name, harga, cat: p.category });
    }
  });

  if (!results.length)
    return await send(sock, jid,
      `${header(sock)}\n🔍 Produk "*${kw}*" tidak ditemukan.\nCoba: *!pricelist*`, msg);

  let text =
    `${header(sock)}\n` +
    ` *🔍 HASIL: "${kw}"*\n` +
    `${LINE}\n_${results.length} produk ditemukan_\n\n`;

  results.slice(0, 25).forEach(p => {
    text += `${p._type === 'manual' ? '🏪' : '🩰'} *${p.nama}*\n`;
    text += `   𝗸𝗼𝗱𝗲 ⦂ \`${p.kode}\`  𝗵𝗮𝗿𝗴𝗮 ⦂ ${p.harga > 0 ? formatRupiah(p.harga) : '_Cek tagihan_'}\n\n`;
  });
  if (results.length > 25) text += `_... +${results.length - 25} lainnya_\n\n`;
  text += `${LINE}\n💡 *!beli <kode>*`;
  await send(sock, jid, text, msg);
}

// ═══════════════════════════════════════════════════════════════════════════
// BELI — deteksi otomatis, tanya info sesuai jenis produk
// ═══════════════════════════════════════════════════════════════════════════
async function handleBuy(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;

  if (!args[0]) {
    return await send(sock, jid,
      `${header(sock)}\n *🛒 CARA BELI*\n${LINE}\n\n` +
      `Cukup ketik: *!beli <kode_produk>*\n\n` +
      `Bot akan otomatis tanya info yang diperlukan\n` +
      `(nomor HP, ID game, nomor meter, dll)\n\n` +
      `${LINE}\n📋 *!pricelist*  •  🔍 *!cari <kata>*`, msg);
  }

  const kode = args[0].toUpperCase();

  // ── Cek manual dulu ───────────────────────────────────────────────────
  const manualProd = db.getProduct(kode);
  if (manualProd && manualProd.active !== false) {
    if (manualProd.stock !== undefined && manualProd.stock <= 0)
      return await send(sock, jid, `❌ Stok *${manualProd.name}* habis`, msg);

    // Produk manual — langsung ke pilih pembayaran (tidak butuh nomor tujuan)
    buyState[buyerJid] = {
      productId: kode, productType: 'manual',
      productName: manualProd.name, amount: manualProd.price,
      customerNo: '', inputType: 'manual',
      step: 'select_payment'
    };
    return await showPaymentMenu(sock, jid, msg, manualProd.name, manualProd.price);
  }

  // ── Cek Digiflazz ─────────────────────────────────────────────────────
  const digiProd = db.getDigiProducts()[kode];
  if (digiProd && digiProd.active !== false) {
    if (digiProd.stock === 'empty')
      return await send(sock, jid, `❌ Produk *${digiProd.name}* sedang kosong`, msg);

    const inputType = digiProd.inputType || 'phone';

    // Simpan state, lanjut ke step tanya nomor/ID
    buyState[buyerJid] = {
      productId: kode, productType: 'digiflazz',
      productName: digiProd.name, amount: digiProd.sellPrice || digiProd.buyerPrice || 0,
      inputType, customerNo: '', customerNo2: '',
      step: 'input_customer'
    };

    return await askCustomerInput(sock, jid, msg, digiProd, inputType);
  }

  await send(sock, jid,
    `${header(sock)}\n❌ Kode *${kode}* tidak ditemukan.\n\n` +
    `🔍 *!cari ${args[0]}*  •  📋 *!pricelist*`, msg);
}

// ── Tanya nomor / ID sesuai tipe produk ───────────────────────────────────
async function askCustomerInput(sock, jid, msg, prod, inputType) {
  const info = INPUT_LABEL[inputType] || INPUT_LABEL['phone'];
  const harga = prod.sellPrice > 0 ? prod.sellPrice : (prod.buyerPrice || 0);

  let text =
    `${header(sock)}\n` +
    ` 🩰 *${prod.name}*\n${LINE}\n` +
    `   𝗵𝗮𝗿𝗴𝗮 ⦂ *${harga > 0 ? formatRupiah(harga) : 'Cek tagihan'}*\n\n` +
    `${info.q}\n` +
    `_Contoh: ${info.ex}_\n\n`;

  if (inputType === 'game_id_server') {
    text += `💡 Format: *ID_game spasi ID_server*\n`;
    text += `Contoh ML: *123456789 1234*\n\n`;
  }
  text += `Ketik *batal* untuk membatalkan`;
  await send(sock, jid, text, msg);
}

// ── Tampil menu pilih pembayaran ───────────────────────────────────────────
async function showPaymentMenu(sock, jid, msg, productName, amount, customerNo = '') {
  const hargaStr = amount > 0 ? formatRupiah(amount) : 'Sesuai tagihan';
  const text =
    `${header(sock)}\n` +
    ` *🛒 DETAIL PEMBELIAN*\n${LINE}\n` +
    `🩰 𝗽𝗿𝗼𝗱𝘂𝗸      ⦂ ${productName}\n` +
    (customerNo ? `📱 𝗻𝗼./𝗜𝗗     ⦂ ${customerNo}\n` : '') +
    `💰 𝘁𝗼𝘁𝗮𝗹       ⦂ *${hargaStr}*\n` +
    `${LINE}\n\n` +
    `*Pilih metode pembayaran:*\n\n` +
    `1️⃣  QRIS _(scan QR)_\n` +
    `2️⃣  BCA Virtual Account\n` +
    `3️⃣  BRI Virtual Account\n` +
    `4️⃣  Mandiri Virtual Account\n` +
    `5️⃣  OVO\n` +
    `6️⃣  GoPay\n` +
    `7️⃣  DANA\n\n` +
    `Balas *1-7* atau ketik *batal*`;
  await send(sock, jid, text, msg);
}

const PAY_MAP = {
  '1':'QRIS','2':'BCAVA','3':'BRIVA','4':'MANDIRIVA',
  '5':'OVO','6':'GOPAY','7':'DANA',
  'qris':'QRIS','bca':'BCAVA','bri':'BRIVA','mandiri':'MANDIRIVA',
  'ovo':'OVO','gopay':'GOPAY','dana':'DANA'
};
const PAY_LABEL = {
  QRIS:'QRIS', BCAVA:'BCA Virtual Account', BRIVA:'BRI Virtual Account',
  MANDIRIVA:'Mandiri Virtual Account', OVO:'OVO', GOPAY:'GoPay', DANA:'DANA'
};

// ═══════════════════════════════════════════════════════════════════════════
// STATE MACHINE PEMBELIAN
// ═══════════════════════════════════════════════════════════════════════════
async function handleBuyState(sock, msg, rawText) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  const state    = buyState[buyerJid];
  if (!state) return false;

  const input = rawText.trim();
  const lower = input.toLowerCase();

  if (lower === 'batal') {
    delete buyState[buyerJid];
    await send(sock, jid, `❌ Pembelian dibatalkan.`, msg);
    return true;
  }

  // ── Step: input_customer — tanya nomor/ID tujuan ───────────────────────
  if (state.step === 'input_customer') {
    if (!input || input.length < 3) {
      await send(sock, jid, `❌ Input tidak valid. Coba lagi atau ketik *batal*.`, msg);
      return true;
    }

    if (state.inputType === 'game_id_server') {
      // Pisah ID dan Server
      const parts = input.split(/\s+/);
      if (parts.length < 2) {
        await send(sock, jid,
          `❌ Format salah! Pisahkan ID Game dan Server dengan spasi.\n` +
          `Contoh: *123456789 1234*\n\nAtau ketik *batal*`, msg);
        return true;
      }
      state.customerNo  = parts[0];
      state.customerNo2 = parts[1];
      state.customerNoFull = `${parts[0]}|${parts[1]}`; // format untuk digiflazz
    } else {
      state.customerNo = input.replace(/\D/g, '') || input; // hapus non-digit untuk nomor HP
      if (state.inputType === 'phone' || state.inputType === 'pln' || state.inputType === 'customer_id') {
        state.customerNo = input.replace(/[^0-9]/g, '');
        if (!state.customerNo) {
          await send(sock, jid, `❌ Masukkan angka saja. Contoh: *08123456789*\n\nAtau ketik *batal*`, msg);
          return true;
        }
      } else {
        state.customerNo = input; // game_id boleh alphanumeric
      }
    }

    state.step = 'select_payment';
    const displayNo = state.inputType === 'game_id_server'
      ? `${state.customerNo} (ID) / ${state.customerNo2} (Server)`
      : state.customerNo;
    await showPaymentMenu(sock, jid, msg, state.productName, state.amount, displayNo);
    return true;
  }

  // ── Step: select_payment ───────────────────────────────────────────────
  if (state.step === 'select_payment') {
    const method = PAY_MAP[lower];
    if (!method) {
      await send(sock, jid, `❌ Pilihan tidak valid. Ketik *1-7* atau *batal*.`, msg);
      return true;
    }
    state.paymentMethod = method;
    state.step = 'confirm';

    const displayNo = state.inputType === 'game_id_server'
      ? `${state.customerNo} (ID) / ${state.customerNo2} (Server)`
      : state.customerNo;

    const confirmText =
      `${header(sock)}\n` +
      ` *✅ KONFIRMASI PESANAN*\n${LINE}\n` +
      `🩰 𝗽𝗿𝗼𝗱𝘂𝗸     ⦂ ${state.productName}\n` +
      (displayNo ? `📱 𝗻𝗼./𝗜𝗗    ⦂ ${displayNo}\n` : '') +
      `💰 𝘁𝗼𝘁𝗮𝗹      ⦂ *${state.amount > 0 ? formatRupiah(state.amount) : 'Sesuai tagihan'}*\n` +
      `💳 𝗽𝗮𝘆𝗺𝗲𝗻𝘁   ⦂ ${PAY_LABEL[method] || method}\n` +
      `${LINE}\n\n` +
      `Ketik *ya* untuk lanjut atau *batal*`;
    await send(sock, jid, confirmText, msg);
    return true;
  }

  // ── Step: confirm ──────────────────────────────────────────────────────
  if (state.step === 'confirm') {
    if (lower !== 'ya' && lower !== 'yes') {
      await send(sock, jid, `❌ Ketik *ya* untuk lanjut atau *batal*.`, msg);
      return true;
    }
    const snap = { ...state };
    delete buyState[buyerJid];

    await send(sock, jid, `⏳ _Membuat invoice pembayaran..._`, msg);

    try {
      const user  = db.getUser(buyerJid);
      // Untuk game ML dll: customerNo = ID|Server
      const customerNoFinal = snap.customerNoFull || snap.customerNo;

      const order = await orderService.createOrder({
        buyerJid,
        buyerName:     user.name || buyerJid.replace('@s.whatsapp.net', ''),
        productId:     snap.productId,
        productType:   snap.productType,
        customerNo:    customerNoFinal,
        paymentMethod: snap.paymentMethod
      });

      const exp = new Date(order.tripayExpiredTime * 1000);
      const displayNo = snap.inputType === 'game_id_server'
        ? `${snap.customerNo} (ID) / ${snap.customerNo2} (Server)`
        : snap.customerNo;

      let invoiceText =
        `${header(sock)}\n` +
        ` *🧾 INVOICE PEMBAYARAN*\n${LINE}\n` +
        `📦 𝗼𝗿𝗱𝗲𝗿     ⦂ \`${order.id}\`\n` +
        `🩰 𝗽𝗿𝗼𝗱𝘂𝗸     ⦂ ${order.productName}\n` +
        (displayNo ? `📱 𝗻𝗼./𝗜𝗗    ⦂ ${displayNo}\n` : '') +
        `💰 𝘁𝗼𝘁𝗮𝗹      ⦂ *${formatRupiah(order.amount)}*\n` +
        `💳 𝗺𝗲𝘁𝗼𝗱𝗲     ⦂ ${PAY_LABEL[order.paymentMethod] || order.paymentMethod}\n` +
        `⏰ 𝗯𝗲𝗿𝗹𝗮𝗸𝘂    ⦂ ${formatDate(exp)}\n` +
        `${LINE}\n\n`;

      if (order.tripayPayCode) invoiceText += `🔢 *Nomor Bayar:*\n\`${order.tripayPayCode}\`\n\n`;
      if (order.tripayPayUrl)  invoiceText += `🔗 *Link Bayar:*\n${order.tripayPayUrl}\n\n`;
      invoiceText += `_Cek status: *!cekpesanan ${order.id}*_`;

      await send(sock, jid, invoiceText, msg);

      if (snap.paymentMethod === 'QRIS' && order.tripayQrUrl)
        await sendQrisImage(sock, jid, order);

    } catch (e) {
      await send(sock, jid,
        `${header(sock)}\n❌ *Gagal membuat pesanan*\n${LINE}\n\n` +
        `${e.message}\n\n_Hubungi admin atau coba lagi_`, msg);
    }
    return true;
  }

  return false;
}

// ── Kirim gambar QRIS ──────────────────────────────────────────────────────
async function sendQrisImage(sock, jid, order) {
  try {
    const resp = await axios.get(order.tripayQrUrl, { responseType: 'arraybuffer', timeout: 10000 });
    await sock.sendMessage(jid, {
      image:   Buffer.from(resp.data),
      caption:
        `📱 *Scan QRIS untuk membayar*\n\n` +
        `Order : \`${order.id}\`\n` +
        `Total : *${formatRupiah(order.amount)}*\n\n` +
        `_Berlaku hingga ${formatDate(new Date(order.tripayExpiredTime * 1000))}_`
    });
  } catch {
    await sock.sendMessage(jid, { text: `📱 *Link QRIS:*\n${order.tripayQrUrl}` });
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// RIWAYAT & CEK PESANAN
// ═══════════════════════════════════════════════════════════════════════════
async function handleOrderHistory(sock, msg) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  const orders   = db.getUserOrders(buyerJid);

  if (!orders.length)
    return await send(sock, jid, `${header(sock)}\n📋 Belum ada riwayat pesanan.`, msg);

  let text = `${header(sock)}\n *📋 RIWAYAT PESANANKU*\n${LINE}\n_10 terakhir_\n\n`;
  orders.slice(-10).reverse().forEach(o => {
    text += `${orderStatusEmoji(o.status)} *${o.id}*\n`;
    text += `   🩰 ${o.productName}\n`;
    text += `   💰 ${formatRupiah(o.amount)} — ${orderStatusText(o.status)}\n`;
    text += `   🕐 ${formatDate(o.createdAt)}\n\n`;
  });
  text += `${LINE}\n_Detail: *!cekpesanan <ID>*_`;
  await send(sock, jid, text, msg);
}

async function handleCheckOrder(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;

  if (!args[0]) return await send(sock, jid, `❌ Format: *!cekpesanan <ID_ORDER>*`, msg);

  const order = db.getOrder(args[0].toUpperCase());
  if (!order) return await send(sock, jid, `❌ Order \`${args[0]}\` tidak ditemukan.`, msg);
  if (order.buyerJid !== buyerJid && !isAdmin(buyerJid))
    return await send(sock, jid, `❌ Kamu tidak punya akses ke order ini.`, msg);

  let text =
    `${header(sock)}\n *📦 DETAIL PESANAN*\n${LINE}\n` +
    `📋 𝗜𝗗       ⦂ \`${order.id}\`\n` +
    `${orderStatusEmoji(order.status)} 𝘀𝘁𝗮𝘁𝘂𝘀   ⦂ ${orderStatusText(order.status)}\n` +
    `🩰 𝗽𝗿𝗼𝗱𝘂𝗸   ⦂ ${order.productName}\n` +
    `💰 𝘁𝗼𝘁𝗮𝗹   ⦂ ${formatRupiah(order.amount)}\n` +
    `🕐 𝘁𝗮𝗻𝗴𝗴𝗮𝗹  ⦂ ${formatDate(order.createdAt)}\n`;
  if (order.customerNo)  text += `📱 𝗻𝗼./𝗜𝗗   ⦂ ${order.customerNo}\n`;
  if (order.digiflazzSn) text += `🔑 𝗦𝗡/𝗧𝗼𝗸𝗲𝗻 ⦂ ${order.digiflazzSn}\n`;
  if (order.adminNote)   text += `📝 𝗰𝗮𝘁𝗮𝘁𝗮𝗻  ⦂ ${order.adminNote}\n`;
  text += LINE + '\n';
  if (order.status === 'pending_payment' && order.tripayPayUrl)
    text += `🔗 *Link Bayar:* ${order.tripayPayUrl}\n`;
  if (order.status === 'failed')
    text += `💬 *#komplain ${order.id} <pesan>*`;
  await send(sock, jid, text, msg);
}

async function handleKomplain(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const buyerJid = msg.key.participant || jid;
  if (!args[0]) return await send(sock, jid, `❌ Format: *#komplain <ID_ORDER> <pesan>*`, msg);

  const orderId = args[0].toUpperCase();
  const pesan   = args.slice(1).join(' ') || '(tanpa pesan)';
  const order   = db.getOrder(orderId);
  if (!order) return await send(sock, jid, `❌ Order \`${orderId}\` tidak ditemukan.`, msg);
  if (order.buyerJid !== buyerJid) return await send(sock, jid, `❌ Bukan ordermu.`, msg);

  await sendToAdmin(
    `⚠️ *KOMPLAIN*\n${LINE}\n` +
    `👤 WA    ⦂ ${buyerJid.replace('@s.whatsapp.net','')}\n` +
    `📦 Order ⦂ ${orderId}\n` +
    `🩰 Produk ⦂ ${order.productName}\n` +
    `💰 Total ⦂ ${formatRupiah(order.amount)}\n` +
    `📝 Pesan ⦂ ${pesan}\n` +
    `📋 Status ⦂ ${orderStatusText(order.status)}`
  );
  await send(sock, jid,
    `✅ Komplain *${orderId}* sudah dikirim ke admin!\nKami segera menghubungimu 🩰`, msg);
}

module.exports = {
  handleMenu, handlePricelist, handleSearch,
  handleBuy, handleBuyState,
  handleOrderHistory, handleCheckOrder, handleKomplain,
  PAY_MAP
};
