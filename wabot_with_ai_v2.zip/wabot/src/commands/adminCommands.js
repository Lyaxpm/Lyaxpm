'use strict';

const db           = require('../models/db');
const { formatRupiah, formatDate, orderStatusText, orderStatusEmoji, isAdmin, isOwner } =
  require('../utils/helper');
const orderService = require('../services/orderService');
const digiflazz   = require('../services/digiflazz');
const { v4: uuidv4 } = require('uuid');

// =====================
// PRODUCT MANAGEMENT
// =====================

async function handleAddProduct(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (args.length < 4) {
    await sock.sendMessage(jid, {
      text:
        '*Format:*\n!addproduk <ID> <kategori> <harga> <nama>\n\n' +
        '*Contoh:*\n' +
        '!addproduk JOKI-ML Joki 50000 Joki Mobile Legends\n' +
        '!addproduk TOPUP-FF Game 25000 Free Fire 355 Diamond\n\n' +
        '*Input type (opsional, tambah di akhir):*\n' +
        '  type=phone          - Nomor HP (default)\n' +
        '  type=game_id        - ID Game saja\n' +
        '  type=game_id_server - ID + Server (ML, Genshin, dll)\n' +
        '  type=pln            - No Meter PLN\n' +
        '  type=customer_id    - ID Pelanggan\n\n' +
        '_Contoh dengan type:_\n' +
        '!addproduk JOKI-ML Joki 50000 Joki ML type=game_id_server'
    }, { quoted: msg });
    return;
  }

  const id       = args[0].toUpperCase();
  const category = args[1];
  const price    = parseInt(args[2]);

  let inputType    = 'customer_id';
  const remainArgs = args.slice(3);
  const typeArg    = remainArgs.find(a => a.startsWith('type='));
  const nameArgs   = remainArgs.filter(a => !a.startsWith('type='));
  if (typeArg) inputType = typeArg.split('=')[1];
  const name = nameArgs.join(' ');

  if (!name) {
    await sock.sendMessage(jid, { text: 'Nama produk tidak boleh kosong' }, { quoted: msg });
    return;
  }
  if (isNaN(price) || price <= 0) {
    await sock.sendMessage(jid, { text: 'Harga harus berupa angka positif' }, { quoted: msg });
    return;
  }
  if (db.getProduct(id)) {
    await sock.sendMessage(jid, {
      text: 'ID `' + id + '` sudah ada. Gunakan !editproduk untuk mengubah.'
    }, { quoted: msg });
    return;
  }

  db.addProduct(id, { name, category, price, inputType, active: true, stock: undefined, description: '' });

  const inputTypeLabel = {
    phone: 'Nomor HP', game_id: 'ID Game',
    game_id_server: 'ID + Server', pln: 'No Meter PLN', customer_id: 'ID Pelanggan'
  };
  await sock.sendMessage(jid, {
    text:
      '*Produk berhasil ditambahkan!*\n\n' +
      'ID        : `' + id + '`\n' +
      'Kategori  : ' + category + '\n' +
      'Nama      : ' + name + '\n' +
      'Harga     : ' + formatRupiah(price) + '\n' +
      'Input type: ' + (inputTypeLabel[inputType] || inputType)
  }, { quoted: msg });
}

async function handleEditProduct(sock, msg, args) {
  const jid = msg.key.remoteJid;
  // Format: !editproduk <id> <field> <value>
  // Fields: nama, harga, stok, deskripsi, status (aktif/nonaktif), kategori, type
  if (args.length < 3) {
    await sock.sendMessage(jid, {
      text:
        'Format: !editproduk <id> <field> <nilai>\n' +
        'Field: nama, harga, stok, deskripsi, status, kategori, type\n' +
        'Contoh: !editproduk JOKI-ML harga 75000'
    }, { quoted: msg });
    return;
  }

  const id    = args[0].toUpperCase();
  const field = args[1].toLowerCase();
  const value = args.slice(2).join(' ');

  const product = db.getProduct(id);
  if (!product) {
    await sock.sendMessage(jid, { text: 'Produk `' + id + '` tidak ditemukan' }, { quoted: msg });
    return;
  }

  const updates = {};
  switch (field) {
    case 'nama':
      updates.name = value;
      break;

    case 'harga': {
      const price = parseInt(value);
      if (isNaN(price)) {
        await sock.sendMessage(jid, { text: 'Harga tidak valid' }, { quoted: msg });
        return;
      }
      updates.price = price;
      break;
    }

    case 'stok': {
      const stock = value.toLowerCase() === 'unlimited' ? undefined : parseInt(value);
      updates.stock = stock;
      break;
    }

    case 'deskripsi':
      updates.description = value;
      break;

    case 'status':
      updates.active = value.toLowerCase() === 'aktif';
      break;

    case 'kategori':
      updates.category = value;
      break;

    case 'type':
    case 'inputtype':
      updates.inputType = value;
      break;

    default:
      await sock.sendMessage(jid, {
        text:
          'Field tidak dikenal: ' + field + '\n' +
          'Field: nama, harga, stok, deskripsi, status, kategori, type'
      }, { quoted: msg });
      return;
  }

  db.updateProduct(id, updates);
  await sock.sendMessage(jid, {
    text: 'Produk `' + id + '` berhasil diupdate!\n' + field + ': ' + value
  }, { quoted: msg });
}

async function handleDeleteProduct(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args[0]) {
    await sock.sendMessage(jid, { text: 'Format: !hapusproduk <id>' }, { quoted: msg });
    return;
  }
  const id = args[0].toUpperCase();
  if (!db.getProduct(id)) {
    await sock.sendMessage(jid, { text: 'Produk `' + id + '` tidak ditemukan' }, { quoted: msg });
    return;
  }
  db.deleteProduct(id);
  await sock.sendMessage(jid, { text: 'Produk `' + id + '` berhasil dihapus' }, { quoted: msg });
}

async function handleListProducts(sock, msg, args) {
  const jid      = msg.key.remoteJid;
  const products = Object.values(db.getProducts());
  if (!products.length) {
    await sock.sendMessage(jid, { text: 'Belum ada produk manual.' }, { quoted: msg });
    return;
  }
  let text = '*DAFTAR PRODUK MANUAL (' + products.length + ')*\n\n';
  products.forEach(function(p) {
    text += (p.active !== false ? 'Aktif' : 'Nonaktif') + ' *' + p.name + '*\n';
    text += '   ID: `' + p.id + '` | Harga: ' + formatRupiah(p.price) + '\n';
    if (p.stock !== undefined) text += '   Stok: ' + p.stock + '\n';
    if (p.description)         text += '   ' + p.description + '\n';
    text += '\n';
  });
  await sock.sendMessage(jid, { text: text }, { quoted: msg });
}

// =====================
// BULK TOGGLE DIGIFLAZZ
// =====================

async function handleBulkToggleDigi(sock, msg, args) {
  const jid = msg.key.remoteJid;

  if (!args[0]) {
    await sock.sendMessage(jid, {
      text:
        'Format: !digisemua <aktif|nonaktif> [kategori:<nama>]\n\n' +
        'Contoh:\n' +
        '!digisemua nonaktif                  - nonaktifkan semua\n' +
        '!digisemua aktif                     - aktifkan semua\n' +
        '!digisemua nonaktif kategori:Pulsa   - hanya kategori Pulsa'
    }, { quoted: msg });
    return;
  }

  const targetActive = args[0].toLowerCase() === 'aktif';
  const label        = targetActive ? 'AKTIF' : 'NONAKTIF';

  var filterKategori = null;
  var katArg = args.find(function(a) { return a.toLowerCase().startsWith('kategori:'); });
  if (katArg) filterKategori = katArg.split(':').slice(1).join(':').toLowerCase();

  const existing = db.getDigiProducts();
  const skuList  = Object.keys(existing);

  if (!skuList.length) {
    await sock.sendMessage(jid, {
      text: 'Belum ada produk Digiflazz. Jalankan .getservice dulu.'
    }, { quoted: msg });
    return;
  }

  let count = 0;
  skuList.forEach(function(sku) {
    var p = existing[sku];
    if (filterKategori && (p.category || '').toLowerCase() !== filterKategori) return;
    existing[sku].active = targetActive;
    count++;
  });

  db.setDigiProducts(existing);

  var filterInfo = filterKategori ? ' (kategori: ' + filterKategori + ')' : '';
  await sock.sendMessage(jid, {
    text:
      'Berhasil mengubah status ' + count + ' produk Digiflazz' + filterInfo + '\n\n' +
      'Status baru: *' + label + '*\n' +
      'Total diproses: ' + count + ' dari ' + skuList.length + ' produk\n\n' +
      'Gunakan .getservice list untuk melihat kategori yang tersedia.'
  }, { quoted: msg });
}

// =====================
// ORDER MANAGEMENT
// =====================

async function handleAdminOrders(sock, msg, args) {
  const jid    = msg.key.remoteJid;
  const filter = args[0] ? args[0].toLowerCase() : null;
  let orders   = Object.values(db.getOrders());

  if (filter && filter !== 'semua') {
    orders = orders.filter(function(o) {
      return o.status === filter || o.status.includes(filter);
    });
  }

  orders = orders.sort(function(a, b) { return b.createdAt - a.createdAt; }).slice(0, 20);

  if (!orders.length) {
    await sock.sendMessage(jid, { text: 'Tidak ada pesanan.' }, { quoted: msg });
    return;
  }

  let text = '*DAFTAR PESANAN (' + orders.length + ' terakhir)*\n\n';
  orders.forEach(function(o) {
    text += orderStatusEmoji(o.status) + ' `' + o.id + '`\n';
    text += '   ' + o.buyerJid.replace('@s.whatsapp.net', '') + '\n';
    text += '   ' + o.productName + '\n';
    text += '   ' + formatRupiah(o.amount) + ' | ' + orderStatusText(o.status) + '\n';
    text += '   ' + formatDate(o.createdAt) + '\n\n';
  });
  text += '\nFilter: !pesananadmin pending_admin/paid/success/failed';
  await sock.sendMessage(jid, { text: text }, { quoted: msg });
}

async function handleConfirmOrder(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args[0]) {
    await sock.sendMessage(jid, { text: 'Format: !selesai <ID_ORDER> [catatan]' }, { quoted: msg });
    return;
  }
  const orderId = args[0].toUpperCase();
  const note    = args.slice(1).join(' ');
  try {
    await orderService.adminConfirmOrder(orderId, 'success', note);
    await sock.sendMessage(jid, {
      text: 'Order `' + orderId + '` dikonfirmasi *SUKSES*!\nCatatan: ' + (note || '-')
    }, { quoted: msg });
  } catch (e) {
    await sock.sendMessage(jid, { text: 'Error: ' + e.message }, { quoted: msg });
  }
}

async function handleFailOrder(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args[0]) {
    await sock.sendMessage(jid, { text: 'Format: !gagal <ID_ORDER> <alasan>' }, { quoted: msg });
    return;
  }
  const orderId = args[0].toUpperCase();
  const reason  = args.slice(1).join(' ') || 'Pesanan gagal diproses';
  try {
    await orderService.adminConfirmOrder(orderId, 'failed', reason);
    await sock.sendMessage(jid, {
      text: 'Order `' + orderId + '` dikonfirmasi *GAGAL*!\nAlasan: ' + reason
    }, { quoted: msg });
  } catch (e) {
    await sock.sendMessage(jid, { text: 'Error: ' + e.message }, { quoted: msg });
  }
}

// =====================
// USER MANAGEMENT
// =====================

async function handleBanUser(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args[0]) {
    await sock.sendMessage(jid, {
      text: 'Format: !ban <nomor>\nContoh: !ban 6281234567890'
    }, { quoted: msg });
    return;
  }
  const targetJid = args[0].replace(/\D/g, '') + '@s.whatsapp.net';
  db.banUser(targetJid);
  await sock.sendMessage(jid, { text: 'User ' + args[0] + ' telah di-ban' }, { quoted: msg });
}

async function handleUnbanUser(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args[0]) {
    await sock.sendMessage(jid, { text: 'Format: !unban <nomor>' }, { quoted: msg });
    return;
  }
  const targetJid = args[0].replace(/\D/g, '') + '@s.whatsapp.net';
  db.unbanUser(targetJid);
  await sock.sendMessage(jid, { text: 'User ' + args[0] + ' telah di-unban' }, { quoted: msg });
}

async function handleListUsers(sock, msg, args) {
  const jid   = msg.key.remoteJid;
  const users = Object.values(db.get().users);
  let text    = '*DAFTAR USER (' + users.length + ')*\n\n';
  users.slice(0, 20).forEach(function(u) {
    var banned = db.isBanned(u.jid);
    text += (banned ? '[BANNED] ' : '') + u.jid.replace('@s.whatsapp.net', '') + '\n';
    text += '   Pesanan: ' + (u.totalOrders || 0) + ' | Belanja: ' + formatRupiah(u.totalSpent || 0) + '\n';
  });
  if (users.length > 20) text += '\n...dan ' + (users.length - 20) + ' user lainnya';
  await sock.sendMessage(jid, { text: text }, { quoted: msg });
}

// =====================
// SETTINGS
// =====================

async function handleSettings(sock, msg, args) {
  const jid = msg.key.remoteJid;
  if (!args[0]) {
    const settings = db.getSettings();
    const text =
      '*PENGATURAN BOT*\n\n' +
      'Profit Margin: ' + settings.profitMargin + '%\n' +
      'Maintenance Mode: ' + (settings.maintenanceMode ? 'ON' : 'OFF') + '\n' +
      'Welcome Message: ' + settings.welcomeMessage + '\n\n' +
      '*Perintah:*\n' +
      '!setting margin <persen> - Ubah margin keuntungan\n' +
      '!setting maintenance <on/off> - Mode maintenance\n' +
      '!setting welcome <pesan> - Ubah pesan sambutan';
    await sock.sendMessage(jid, { text: text }, { quoted: msg });
    return;
  }

  const field = args[0].toLowerCase();
  const value = args.slice(1).join(' ');

  switch (field) {
    case 'margin': {
      const margin = parseFloat(value);
      if (isNaN(margin) || margin < 0) {
        await sock.sendMessage(jid, { text: 'Margin tidak valid' }, { quoted: msg });
        return;
      }
      db.updateSettings({ profitMargin: margin });
      await sock.sendMessage(jid, {
        text: 'Profit margin diubah ke ' + margin + '%\n\nGunakan !refreshpricelist untuk update harga Digiflazz'
      }, { quoted: msg });
      break;
    }
    case 'maintenance': {
      const on = value.toLowerCase() === 'on';
      db.updateSettings({ maintenanceMode: on });
      await sock.sendMessage(jid, {
        text: 'Maintenance mode: ' + (on ? 'ON' : 'OFF')
      }, { quoted: msg });
      break;
    }
    case 'welcome': {
      db.updateSettings({ welcomeMessage: value });
      await sock.sendMessage(jid, { text: 'Welcome message diubah' }, { quoted: msg });
      break;
    }
    default:
      await sock.sendMessage(jid, { text: 'Field tidak dikenal: ' + field }, { quoted: msg });
  }
}

async function handleRefreshPricelist(sock, msg, args) {
  const jid = msg.key.remoteJid;
  await sock.sendMessage(jid, {
    text: 'Mengambil pricelist terbaru dari Digiflazz...'
  }, { quoted: msg });
  try {
    const products = await digiflazz.refreshPricelist();
    const count    = Object.keys(products).length;
    await sock.sendMessage(jid, {
      text:
        'Pricelist berhasil diupdate!\n' +
        'Total: ' + count + ' produk\n' +
        'Margin keuntungan: ' + db.getProfitMargin() + '%'
    }, { quoted: msg });
  } catch (e) {
    await sock.sendMessage(jid, {
      text: 'Gagal refresh pricelist: ' + e.message
    }, { quoted: msg });
  }
}

async function handleBalance(sock, msg, args) {
  const jid = msg.key.remoteJid;
  try {
    const balance = await digiflazz.getBalance();
    await sock.sendMessage(jid, {
      text: '*Saldo Digiflazz*\n\nSaldo: ' + formatRupiah(balance.deposit)
    }, { quoted: msg });
  } catch (e) {
    await sock.sendMessage(jid, { text: 'Gagal cek saldo: ' + e.message }, { quoted: msg });
  }
}

async function handleAdminMenu(sock, msg, args) {
  const jid  = msg.key.remoteJid;
  const text =
    '*MENU ADMIN*\n\n' +
    '*Produk Manual*\n' +
    '  !addproduk <id> <harga> <nama> - Tambah produk\n' +
    '  !editproduk <id> <field> <nilai> - Edit produk\n' +
    '  !hapusproduk <id> - Hapus produk\n' +
    '  !listproduk - Daftar produk manual\n\n' +
    '*Produk Digiflazz (Massal)*\n' +
    '  !digisemua nonaktif               - Nonaktifkan semua produk Digiflazz\n' +
    '  !digisemua aktif                  - Aktifkan semua produk Digiflazz\n' +
    '  !digisemua nonaktif kategori:Pulsa - Per kategori\n\n' +
    '*Pesanan*\n' +
    '  !pesananadmin [filter] - Lihat pesanan\n' +
    '  !selesai <id> [catatan] - Konfirmasi sukses\n' +
    '  !gagal <id> <alasan> - Konfirmasi gagal\n\n' +
    '*User*\n' +
    '  !listuser - Lihat semua user\n' +
    '  !ban <nomor> - Ban user\n' +
    '  !unban <nomor> - Unban user\n\n' +
    '*Pengaturan*\n' +
    '  !setting - Lihat pengaturan\n' +
    '  !setting margin <persen> - Ubah margin\n' +
    '  !setting maintenance <on/off>\n' +
    '  !refreshpricelist - Update harga Digiflazz\n' +
    '  !saldo - Cek saldo Digiflazz\n' +
    '  !broadcast <pesan> - Kirim pesan ke semua user\n\n' +
    '*Layanan Digiflazz*\n' +
    '  .getservice - Import semua layanan Digiflazz\n' +
    '  .getservice list - Lihat daftar kategori\n' +
    '  .getservice kategori:Pulsa - Import per kategori\n' +
    '  .getservice brand:Telkomsel - Import per brand\n' +
    '  .getservice tersedia - Hanya yang stok ada\n' +
    '  .editdigi <SKU> harga <nilai> - Edit harga satu produk\n' +
    '  .editdigi <SKU> status nonaktif - Nonaktifkan satu produk';
  await sock.sendMessage(jid, { text: text }, { quoted: msg });
}

// =====================
// GET SERVICE (IMPORT DARI DIGIFLAZZ)
// =====================

async function handleGetService(sock, msg, args) {
  const jid = msg.key.remoteJid;

  if (!args.length || args[0] === '--help' || args[0] === 'help') {
    const text =
      '*GETSERVICE - Import Layanan Digiflazz*\n\n' +
      '*Penggunaan:*\n' +
      '- .getservice               - Import semua layanan\n' +
      '- .getservice list          - Lihat daftar kategori\n' +
      '- .getservice kategori:Pulsa - Import kategori tertentu\n' +
      '- .getservice brand:Telkomsel - Filter by brand\n' +
      '- .getservice tersedia       - Hanya produk tersedia\n' +
      '- .getservice kategori:Pulsa tersedia - Kombinasi filter\n\n' +
      '*Edit produk Digiflazz setelah import:*\n' +
      '- .editdigi <SKU> harga <nilai>       - Ubah harga jual\n' +
      '- .editdigi <SKU> status nonaktif     - Nonaktifkan satu produk\n' +
      '- .editdigi <SKU> deskripsi <teks>    - Edit deskripsi\n\n' +
      '*Nonaktifkan massal:*\n' +
      '- !digisemua nonaktif                 - Semua produk Digiflazz\n' +
      '- !digisemua nonaktif kategori:Pulsa  - Per kategori';
    await sock.sendMessage(jid, { text: text }, { quoted: msg });
    return;
  }

  if (args[0] === 'list' || args[0] === '--list') {
    const existing = db.getDigiProducts();
    const cats     = {};
    Object.values(existing).forEach(function(p) {
      var c = p.category || 'Lainnya';
      cats[c] = (cats[c] || 0) + 1;
    });
    if (!Object.keys(cats).length) {
      await sock.sendMessage(jid, {
        text: 'Belum ada layanan Digiflazz. Jalankan .getservice dulu.'
      }, { quoted: msg });
      return;
    }
    let text = '*KATEGORI LAYANAN DIGIFLAZZ*\n(' + Object.keys(cats).length + ' kategori)\n\n';
    Object.entries(cats).sort(function(a, b) { return b[1] - a[1]; }).forEach(function(entry) {
      text += '- *' + entry[0] + '* - ' + entry[1] + ' produk\n';
    });
    text += '\nFilter import: .getservice kategori:<nama>';
    await sock.sendMessage(jid, { text: text }, { quoted: msg });
    return;
  }

  const opts = { onlyAvailable: false };
  args.forEach(function(a) {
    var lower = a.toLowerCase();
    if (lower === 'tersedia' || lower === 'available') {
      opts.onlyAvailable = true;
    } else if (lower.startsWith('kategori:')) {
      opts.category = a.split(':').slice(1).join(':');
    } else if (lower.startsWith('brand:')) {
      opts.brand = a.split(':').slice(1).join(':');
    } else if (lower.startsWith('type:')) {
      opts.type = a.split(':').slice(1).join(':');
    }
  });

  let infoText = 'Mengambil layanan dari Digiflazz...\n';
  if (opts.category)      infoText += 'Kategori: ' + opts.category + '\n';
  if (opts.brand)         infoText += 'Brand: ' + opts.brand + '\n';
  if (opts.type)          infoText += 'Type: ' + opts.type + '\n';
  if (opts.onlyAvailable) infoText += 'Hanya produk tersedia\n';
  infoText += '\nMargin aktif: *' + db.getProfitMargin() + '%*\nMohon tunggu...';
  await sock.sendMessage(jid, { text: infoText }, { quoted: msg });

  try {
    const result = await digiflazz.importServicesFromDigiflazz(opts);

    let text = '*IMPORT LAYANAN SELESAI!*\n\n';
    text += 'Total diproses: *' + result.total + '* produk\n';
    text += 'Baru ditambahkan: *' + result.imported + '* produk\n';
    text += 'Diupdate: *' + result.skipped + '* produk\n\n';

    if (result.categories.length) {
      text += '*Kategori yang masuk (' + result.categories.length + '):*\n';
      result.categories.slice(0, 20).forEach(function(c) { text += '  - ' + c + '\n'; });
      if (result.categories.length > 20) {
        text += '  ...dan ' + (result.categories.length - 20) + ' lainnya\n';
      }
      text += '\n';
    }

    text += '*Langkah selanjutnya:*\n';
    text += '- Lihat pricelist: !pricelist\n';
    text += '- Edit harga: .editdigi <SKU> harga <nilai>\n';
    text += '- Nonaktifkan satu: .editdigi <SKU> status nonaktif\n';
    text += '- Nonaktifkan semua: !digisemua nonaktif\n';
    text += '- Lihat kategori: .getservice list\n';
    text += '- Ubah margin global: !setting margin <persen>';

    await sock.sendMessage(jid, { text: text }, { quoted: msg });
  } catch (e) {
    await sock.sendMessage(jid, {
      text: 'Gagal import layanan Digiflazz:\n' + e.message + '\n\nPastikan kredensial DIGIFLAZZ di .env sudah benar.'
    }, { quoted: msg });
  }
}

async function handleEditDigiProduct(sock, msg, args) {
  const jid = msg.key.remoteJid;

  if (args.length < 3) {
    await sock.sendMessage(jid, {
      text:
        'Format: .editdigi <SKU> <field> <nilai>\n\n' +
        '*Field yang bisa diedit:*\n' +
        '- harga     - harga jual ke customer\n' +
        '- status    - aktif / nonaktif\n' +
        '- deskripsi - deskripsi produk\n\n' +
        '*Contoh:*\n' +
        '.editdigi XL5 harga 7500\n' +
        '.editdigi XL5 status nonaktif\n' +
        '.editdigi XL5 deskripsi Pulsa XL 5.000\n\n' +
        'Untuk nonaktifkan semua sekaligus: !digisemua nonaktif'
    }, { quoted: msg });
    return;
  }

  const sku      = args[0].toUpperCase();
  const field    = args[1].toLowerCase();
  const value    = args.slice(2).join(' ');
  const existing = db.getDigiProducts();
  const product  = existing[sku];

  if (!product) {
    await sock.sendMessage(jid, {
      text: 'SKU `' + sku + '` tidak ditemukan.\nImport dulu dengan .getservice atau cek SKU dengan !pricelist'
    }, { quoted: msg });
    return;
  }

  switch (field) {
    case 'harga': {
      const harga = parseInt(value);
      if (isNaN(harga) || harga <= 0) {
        await sock.sendMessage(jid, { text: 'Harga tidak valid. Masukkan angka positif.' }, { quoted: msg });
        return;
      }
      const oldPrice = product.sellPrice || product.price || 0;
      const buyPrice = product.buyer_price || product.buyerPrice || 0;
      existing[sku].sellPrice    = harga;
      existing[sku]._customPrice = true;
      db.setDigiProducts(existing);
      await sock.sendMessage(jid, {
        text:
          '*Harga berhasil diubah!*\n\n' +
          'Produk     : ' + (product.product_name || product.name) + '\n' +
          'SKU        : ' + sku + '\n' +
          'Harga lama : ' + formatRupiah(oldPrice) + '\n' +
          'Harga baru : ' + formatRupiah(harga) + '\n' +
          'Harga beli : ' + formatRupiah(buyPrice) + '\n' +
          'Keuntungan : ' + formatRupiah(harga - buyPrice)
      }, { quoted: msg });
      break;
    }
    case 'status': {
      const aktif = value.toLowerCase() === 'aktif';
      existing[sku].active = aktif;
      db.setDigiProducts(existing);
      await sock.sendMessage(jid, {
        text: 'Status *' + (product.product_name || product.name) + '* diubah ke *' + (aktif ? 'AKTIF' : 'NONAKTIF') + '*'
      }, { quoted: msg });
      break;
    }
    case 'deskripsi': {
      existing[sku].description = value;
      db.setDigiProducts(existing);
      await sock.sendMessage(jid, {
        text: 'Deskripsi *' + (product.product_name || product.name) + '* berhasil diupdate.'
      }, { quoted: msg });
      break;
    }
    default:
      await sock.sendMessage(jid, {
        text: 'Field tidak dikenal: *' + field + '*\nField yang tersedia: harga, status, deskripsi'
      }, { quoted: msg });
  }
}

// =====================
// BROADCAST
// =====================

async function handleBroadcast(sock, msg, args) {
  const jid  = msg.key.remoteJid;
  const text = args.join(' ');
  if (!text) {
    await sock.sendMessage(jid, { text: 'Format: !broadcast <pesan>' }, { quoted: msg });
    return;
  }
  const users        = Object.values(db.get().users);
  let sent           = 0;
  const broadcastMsg = '*BROADCAST ADMIN*\n\n' + text;
  for (const user of users) {
    try {
      await sock.sendMessage(user.jid, { text: broadcastMsg });
      sent++;
      await new Promise(function(r) { setTimeout(r, 500); });
    } catch (_) {}
  }
  await sock.sendMessage(jid, {
    text: 'Broadcast terkirim ke ' + sent + '/' + users.length + ' user'
  }, { quoted: msg });
}

module.exports = {
  handleAddProduct, handleEditProduct, handleDeleteProduct, handleListProducts,
  handleBulkToggleDigi,
  handleAdminOrders, handleConfirmOrder, handleFailOrder,
  handleBanUser, handleUnbanUser, handleListUsers,
  handleSettings, handleRefreshPricelist, handleBalance,
  handleAdminMenu, handleBroadcast,
  handleGetService, handleEditDigiProduct
};
